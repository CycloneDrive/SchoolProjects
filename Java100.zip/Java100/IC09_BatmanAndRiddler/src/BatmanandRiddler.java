/*
Tran, Dan
CS A170
March  2, 2018 
*
IC #09#
*/
public class BatmanandRiddler {

	public static void main(String[] args) {

		for (int address = 1001; address <= 9999; address += 2) {
			int thousands = address / 1000;
			int hundreds = address % 1000 / 100;
			int tens = address % 100 / 10;
			int ones = address % 10;
			if (ones != tens && ones != hundreds && ones != thousands && tens != hundreds && tens != thousands
					&& hundreds != thousands) {
				if (thousands == 3 * tens)
					if (ones % 2 == 1) {
						if (ones + tens + hundreds + thousands == 27) {
						System.out.println("The Riddler intends to strike " + address + " Pennsylvania Avenue.");
						}
					}
			}

		}

	}

}
