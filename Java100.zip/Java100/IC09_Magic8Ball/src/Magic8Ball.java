/*
Tran, Dan
CS A170
March  2, 2018 
*
IC #09#
*/
import java.util.Random;
import java.util.Scanner;
public class Magic8Ball
{

    public static void main(String[] args)
    {
        String response;
        Scanner consoleScanner = new Scanner(System.in);
        int answer; // random number from 1 to 8
        Random rng = new Random();

        do
        {
            System.out.println("What question would you like to ask the Magic 8 ball?\n");
            consoleScanner.nextLine();

            // Generate a random number from 1 to 8
            answer = rng.nextInt(8) + 1;
            System.out.print("The answer is: ");

            switch (answer)
            {
                case 1:
                    System.out.println("It is certain");
                    break;
                case 2:
                    System.out.println("It is decidedly so");
                    break;
                case 3:
                    System.out.println("Most likely");
                    break;
                case 4:
                    System.out.println("Signs point to yes");
                    break;
                case 5:
                    System.out.println("Reply hazy, try again");
                    break;
                case 6:
                    System.out.println("Ask again later");
                    break;
                case 7:
                    System.out.println("Don't count on it");
                    break;
                case 8:
                    System.out.println("My sources say no");
                    break;
            }

            System.out.println("\nWould you like to ask another question (type Y or N)?");
            response = consoleScanner.nextLine().toUpperCase();
        }
        while (response.startsWith("Y"));
        consoleScanner.close();
        System.out.println("\nThank you for playing Magic 8 Ball.");
        // Automatically format (indent) your code: Ctrl + Shift + f
    }
}