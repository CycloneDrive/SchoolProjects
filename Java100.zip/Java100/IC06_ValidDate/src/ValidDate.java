import java.util.Scanner;

/*
Tran, Dan
CS A170
February  27, 2018 
*
IC #06#
*/
public class ValidDate {

	public static void main(String[] args) 
	{
		String Date;
		int month, day, year;
		Scanner consoleScanner = new Scanner (System.in);
		System.out.println("Please enter a date (format MM/DD/YYYY) and include the forward slashes:");
		Date = consoleScanner.next(); 
		
		String monthPart = Date.substring(0,2); 
		String dayPart = Date.substring(3,5);
		String yearPart = Date.substring(6);
		
		month = Integer.parseInt(monthPart); 
		day = Integer.parseInt(dayPart);
		year = Integer.parseInt(yearPart);
		
		switch (month)
		{
			//31 day months (1,3,5,7
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:	
				if(day<1||day>31)
					System.out.println("Invalid day");
				else
					System.out.println("Valid day");
			 break;
			//30 day months 
			case 4:
			case 6:
			case 9: 
			case 11:
				if(day<1||day>30)
					System.out.println("Invalid day");
				else
					System.out.println("Valid day");
			break;
			case 2:
			//28 days
				if(day<1||day>28)
					System.out.println("Invalid day");	
				else
					System.out.println("Valid day");
			break;
			default : System.out.println("Invalid month");
		}
		
		
		
	}
}
