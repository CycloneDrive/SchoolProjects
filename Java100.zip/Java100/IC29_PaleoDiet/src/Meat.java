/*
Tran, Dan
CS A170
*/
import java.io.Serializable;

public class Meat extends PaleoFood implements Serializable
{
    private int mCookingTemp;
    private int mType;
    //setters and getters for type
    public int getType()
    {
            return mType;
    }
    public void setType(int type) throws MysteryMeatException
    {
        if(type != 1 && type !=2)
        	throw new MysteryMeatException();
        else
        	mType = type;   
    }
    //setters and getters
    public int getCookingTemp()
    {
        return mCookingTemp;
    }
    public void setCookingTemp(int cookingTemp)
    {
        mCookingTemp = cookingTemp;
    }
    // contructor 4 paramenters
    public Meat(String name, int calories, int cookingTemp, int type) throws MysteryMeatException
    {
       // more efficient to setType instead of if else statement
       //if (mType == 1 | mType == 2)
       //{
       //    mName = name;
       //   mCalories = calories;
       //   mCarbohydrates = 0;
       //    mCookingTemp = cookingTemp;
       //     mType = type;
       // }
       // else
       // throw new MysteryMeatException();
        mName = name;
        mCalories = calories;
        mCarbohydrates = 0;
        mCookingTemp = cookingTemp;
        setType(type);
    }
    //equals() method
    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + mCookingTemp;
        result = prime * result + mType;
        return result;
    }
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (!super.equals(obj)) return false;
        if (getClass() != obj.getClass()) return false;
        Meat other = (Meat) obj;
        if (mCookingTemp != other.mCookingTemp) return false;
        if (mType != other.mType) return false;
        return true;
    }
    //to string
    @Override
    public String toString()
    {
        //If the type is 1 - animal
        if(mType==1)
        {
            return "Meat: " + mName + ", " + mCalories + " calories, " + mCarbohydrates + "g carbs, " +  + mCookingTemp + " degrees F";
        }
        else
        {
            return "Seafood: " + mName + ", " + mCalories + " calories, " + mCarbohydrates + "g carbs, " + mCookingTemp + " degrees F";
        }


    }

}
