/*
Tran, Dan
CS A170
*/
import java.io.Serializable;

public class Produce extends PaleoFood implements Serializable
{
    //Create instance variable for organic (boolean).  (true represents organic produce, false represents non-organic)
    private boolean mOrganic;
    //create accesor and mutator for organic
    public boolean isOrganic()
    {
        return mOrganic;
    }
    public void setOrganic(boolean organic)
    {
        mOrganic = organic;
    }
    // create constructor
    public Produce(String name, int calories, int carbohydrates, boolean organic)
    {
        mName = name;
        mCalories = calories;
        mCarbohydrates = carbohydrates;
        mOrganic = organic;
    }
    //Override the equals() method to compare all instance variables for equality.
    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + (mOrganic ? 1231 : 1237);
        return result;
    }
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (!super.equals(obj)) return false;
        if (getClass() != obj.getClass()) return false;
        Produce other = (Produce) obj;
        if (mOrganic != other.mOrganic) return false;
        return true;
    }
    //Override the toString() method that displays all fields in the following format:
    @Override
    public String toString()
    {
        if (mOrganic == true)
        {
          return "Organic Produce: " + mName + ", " + mCalories + " calories, " + mCarbohydrates + "g carbs";
        }
        else
        {
          return "Produce: " + mName + ", " + mCalories + " calories, " + mCarbohydrates + "g carbs";
        }
    }





}
