/*
Tran, Dan
CS A170
*/
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class FoodJournalDemo
{
    @SuppressWarnings("unchecked")
    public static void main(String[] args)
    {
        int option, calories, cookingtemp, carbohydrates, organic, meattype ; 
        String name; 
        Scanner consoleScanner = new Scanner(System.in);
        //array lis tto store all foods
        ArrayList<PaleoFood> foodsList = new ArrayList<>();
        //Step 1:  Reading bindary file int the array list
        File binaryFile = new File("FoodJournal.dat");
        System.out.println("~~~~~~~~~~~~Welcome to the Paleo Food Journal~~~~~~~~~~~~");
        //check to see if BINARY FILE EXISTS
        if (binaryFile.exists())
        {
            try
            {
                ObjectInputStream fileReader = new ObjectInputStream(new FileInputStream(binaryFile));
                foodsList = (ArrayList<PaleoFood>) fileReader.readObject();
                fileReader.close();
                for (PaleoFood f : foodsList)
                    System.out.println(f);
            }
            catch (IOException | ClassNotFoundException e)
            {
                System.out.println(e.getMessage());
            }
        }
        else
            System.out.println("[No food eaten. You must be hungry.]");
        
        //STEP 2: prompt the user to input new Paleo Foods
        // As long as input is not "3" keep looping
       do
       {
           //prompt user for type of food
           System.out.println("\n*******Options Menu*******");
           System.out.println("Enter (1) to record a meat");
           System.out.println("Enter (2) to record a produce");
           System.out.println("Enter (3) to quit");
           option = consoleScanner.nextInt();
           consoleScanner.nextLine();
           if (option == 3)
               break; 
           if (option == 1)
           {
               System.out.print("What is the name of the meat eaten? ");
               name = consoleScanner.nextLine();
               System.out.print("How many calories was it? ");
               calories = consoleScanner.nextInt();
               System.out.print("Enter (1) for animal or (2) for seafood: ");
               meattype = consoleScanner.nextInt();
               System.out.print("Enter the cooking temperature: ");
               cookingtemp = consoleScanner.nextInt();
                   try
                   {
                    foodsList.add(new Meat(name, calories, cookingtemp,meattype));
                   }
                   catch (MysteryMeatException e)
                   {
                    System.out.println(e.getMessage());
                   }

           }
         
           else if (option == 2)
           {
        	   System.out.print("What was the name of the produce eaten? ");
        	   name = consoleScanner.nextLine();
        	   System.out.print("How many calories was it? ");
        	   calories = consoleScanner.nextInt();
        	   System.out.print("How many carbohydrates? ");
        	   carbohydrates = consoleScanner.nextInt();
        	   System.out.print("Enter (1) for organic or (2) for non-organic: ");
        	   organic = consoleScanner.nextInt();
        	   if (organic == 1)
        		   foodsList.add(new Produce(name, calories, carbohydrates, true));
        	   else
        		   foodsList.add(new Produce(name, calories, carbohydrates, false));
           }
           System.out.println();
           for (PaleoFood f : foodsList)
               System.out.println(f);
           System.out.println("\nTotal Calories Eaten: " + totalCalories(foodsList));
           System.out.println("Number of organic fruits and veggies eaten: " + organicProduceConsumed(foodsList));
       }while(option!=3);
       //after the loop close the scanner
       consoleScanner.close();
       
       //Step 3: Write the binary
       try
       {
    	   ObjectOutputStream fileWriter = new ObjectOutputStream(new FileOutputStream(binaryFile));
    	   fileWriter.writeObject(foodsList);
    	   fileWriter.close();
       }
       catch (IOException e)
       {
    	   System.out.println(e.getMessage());
       }
       System.out.println("Eat healthy and enjoy your break!");
    }
    
    public static int totalCalories(ArrayList<PaleoFood> foodsList)
    {
        int total =0;
        for(PaleoFood p : foodsList)
            total+= p.getCalories();
        return total;
    }
    
    public static int organicProduceConsumed(ArrayList<PaleoFood> foodsList)
    {
    	int count = 0;
    	for(PaleoFood pf: foodsList)
    	{
    		if (pf instanceof Produce)
    		{
    			Produce p = (Produce) pf;
    			if(p.isOrganic())
    				count++;
    		}
    	}
    	return count;
    }
}
