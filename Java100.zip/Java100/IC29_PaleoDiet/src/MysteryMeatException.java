/*
Tran, Dan
CS A170
*/
public class MysteryMeatException extends Exception
{
    public MysteryMeatException()
    {
        super("Mystery meat don't eat that!");
    }
    public MysteryMeatException(String message)
    {
        super(message);
    }
}
