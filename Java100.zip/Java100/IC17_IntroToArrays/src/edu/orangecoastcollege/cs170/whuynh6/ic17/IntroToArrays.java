/*
Tran, Dan
CS A170
*/
import java.util.Arrays;
import java.util.Scanner;

public class IntroToArrays
{
    // Declare the size as a constanst before the main
    public static final int SIZE = 10;

    public static void main(String[] args)
    {
        // In the main, declare the array
        int[] values = new int[SIZE];
        int largest, smallest;
        double sum = 0.0, average;
        Scanner consoleScanner = new Scanner(System.in);

        for (int i = 0; i < values.length; i++)
        {
            System.out.print("Please enter value #" + (i + 1) + ": ");
            values[i] = consoleScanner.nextInt();
            sum += values[i];
        }
        consoleScanner.close();
        // calculate the average once after the loop
        //sort arrays( ascending: small to large)
        Arrays.sort(values);
        
        average = sum / values.length;
        largest = values[values.length - 1];
        smallest = values[0];          
                
        
        System.out.println("\nThe largest value in the array is : " + largest);
        System.out.println("The smallest value in the array is : " + smallest);
        System.out.println("The sum of values in the array is : " + sum);
        System.out.println("The average value in the array is : " + average);
    }

}
