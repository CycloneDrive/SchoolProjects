/*
Tran, Dan
CS A170
*/
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Scanner;

public class ISleepy {
	public static final int SIZE = 7;

	public static void main(String[] args)
    {
        // declare arrays and other variables
        double[] hoursSlept = new double[SIZE];
        // declare the days in the week (pre-known)
        String[] days = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
        // declare sum average;
        double sum = 0.0, average;
        int rec = 0, app = 0, notRec = 0;
        String overall;
        Scanner consoleScanner = new Scanner(System.in);
        DecimalFormat twoDps= new DecimalFormat ("0.00");
        for (int i = 0; i < hoursSlept.length; i++)
        {
            System.out.print("Enter number of hours on " + days[i] + ": ");
            hoursSlept[i] = consoleScanner.nextDouble();
            sum += hoursSlept[i];
            if (hoursSlept[i] <= 9 && hoursSlept[i] >= 7)
            {
                rec++;
            }
            else if (hoursSlept[i] < 6 || hoursSlept[i] > 11)
            {
                notRec++;
            }
            else
            {
                app++;
            }
        }
        consoleScanner.close();

        average = sum / hoursSlept.length;

        System.out.println("\nTotal number of hours slept last week   : " + twoDps.format(sum));
        System.out.println("Average number of hours slept per night : " + twoDps.format(average));

        System.out.println("\nAccording to the NSF, last week you slept:\n" + rec + " nights of \"recommended\" sleep.\n"
                + app + " nights of \"appropriate\" sleep.\n" + notRec + " nights of \"not recommended\" sleep.");
       if (average<= 9 && average >=7)
       {
    	overall = "\"Recommended\"";    
       }
       else if (average < 6 || average > 11)
       {
    	   overall = "\"Not Recommended\"";
    			   
       }
       else
       {
    	   overall = "\"May Be Appropriate\"";
       }
        System.out.println("Overall, your sleep health (on average) is " + overall);
    }

}
