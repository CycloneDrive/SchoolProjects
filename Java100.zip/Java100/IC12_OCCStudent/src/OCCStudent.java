/*
Tran, Dan
CS A170
March  26, 2018 
*
IC #10#
*/
public class OCCStudent
{
    // No main method because demo executes and this just stores
    // Start by defining the fields (data we want to store) in our database
    // All fields should be PRIVATE!
    // All fields should start witht the prefix "m" (member variable)
    private String mCNumber;
    private String mFullname;
    private int mAge;
    private String mUsername;
    private double mGPA;

    // Next we'll code the CONTRUCTOR = method that instantiates new objects
    // Contructor is PUBLIC to allow new entries to database.
    // Constructor has the same exact name as the class
    // List all the information needed to register (instantiate) a new student
    public OCCStudent(String cNumber, String fullname, int age, String username)
    {
        // Asasign all values into our fields (member variables)
        // Transfer the data from form into your databases
        // mCNumber is getting information from user input
        mCNumber = cNumber;
        mFullname = fullname;
        mAge = age;
        mUsername = username;
        mGPA = 0.0;
    }
    // Accessors - provide read access to fields
    public String getCNumber()
    {
        // Retrieve the value of C Number from database
        return mCNumber;
    }

    public String getfullname()
    {
        return mFullname;
    }

    public int getage()
    {
        return mAge;
    }

    public String getusername()
    {
        return mUsername;
    }

    public double getGPA()
    {
        return mGPA;
    }
    // 4) Mutators (stters) provide write access toa field in database
    public void setAge(int newAge)
    {
        // Update the database field with the enw age value
        mAge = newAge;
    }

    public void setFullName(String newName)
    {
        // Update the database field with the enw age value
        mFullname = newName;
    }

    public void setGPA(double newGPA)
    {
        mGPA = newGPA;
    }

    public void setUserName(String newUsername)
    {
        mUsername = newUsername;
    }
    // toString method converts an object into a String for display
    public String toString()
    {
        String output = "OCC Student[" + mCNumber + ", " + mUsername + ", " + mFullname + ", " + mAge + ", " + mGPA
                + "]";
        return output;
    }
    // comparing this student with another student
    public boolean equals(OCCStudent other)
    {
        // mCNumber = student 1 other = student 2
        if (mCNumber.equals(other.mCNumber) && mUsername.equals(other.mUsername) && mFullname.equals(other.mFullname)
                && mGPA == other.mGPA && mAge == other.mAge)
            return true;
        else
            return false;
    }
    // Miscellaneous methods - methods custom to the class itself
    public boolean isOlder(OCCStudent other)
    {
        if (mAge > other.mAge)
            return true;
        else 
            return false;
    }
    public boolean isSameAge(OCCStudent other)
    {
        if (mAge == other.mAge)
            return true;
        else 
            return false;
    }
    public boolean isYounger(OCCStudent other)
    {
        if (mAge < other.mAge)
            return true;
        else 
            return false;
    }
    
}
