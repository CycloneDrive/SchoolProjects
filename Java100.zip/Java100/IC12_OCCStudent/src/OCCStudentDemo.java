/*
Tran, Dan
CS A170
March  26, 2018 
*
IC #10#
*/

public class OCCStudentDemo
{
    public static void main(String[] args)
    {
        // Instantiate (create 2 new objects (OCCStudents))
        // Scanner consoleScannr= new Scanner(System.in);
        OCCStudent william = new OCCStudent("C02566304", "William Huynh", 19, "whuynh6");
        // ctrl + space   
        OCCStudent diane = new OCCStudent("C000015", "Diane Keaton", 63, "dkeaton");
        System.out.println(william);
        System.out.println(diane);
        
        System.out.println("\nUpdating GPAs");
        william.setGPA(3.5);
        diane.setGPA(2.0);
        System.out.println(william);
        System.out.println(diane);
        
        System.out.println("\nWilliam meets Diane");
        william.setFullName("William Keaton");
        System.out.println(william);
        System.out.println(diane);
        
        //Misc. Methods
        System.out.println("Is William older than Diane? " + william.isOlder(diane));
    }

}
