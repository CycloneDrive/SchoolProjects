/*
Tran, Dan
CS A170
*/
public class PointLineDemo
{

    public static void main(String[] args)
    {
        // Let's make a point at (3,4)
        Point p1 = new Point(3, 4);
        // Make a second Point by copying p1
        Point p2 = new Point(p1);
        // Make third point called origin (0,0)
        Point origin = new Point();
        // Print 3 points
        System.out.println(origin);
        System.out.println(p1);
        System.out.println(p2);
        // Let's change p2 to be (5,0)
        p2.setX(5);
        p2.setY(0);
        //
        System.out.println("");
        System.out.println(origin);
        System.out.println(p1);
        System.out.println(p2);
        System.out.println();
        // Let's make a new line from (0,0) to (5,0)
        Line l1 = new Line(0, 0, 5, 0);
        // Let's amke anew line using points
        Line l2 = new Line(origin, p2);
        // Let's make a new line using the copy constructor
        Line l3 = new Line(l1);
       
        System.out.println(l1 + "\n" + l2 + "\n" + l3 + "\n");
        System.out.println("Length of l1 = " + l1.length());
        System.out.println("Length of l2 = " + l2.length());
        System.out.println("Length of l3 = " + l3.length());
    }

}
