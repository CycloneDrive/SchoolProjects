/*
Tran, Dan
CS A170
*/
public class Line
{
    private Point mP1;
    private Point mP2;

    // Line from 2 x-values and 2 y-values (parameterized constuctor)
    public Line(int x1, int y1, int x2, int y2)
    {
        mP1 = new Point(x1, y1);
        mP2 = new Point(x2, y2);
    }

    // Line from 2 points (parameterized constructor)
    public Line(Point p1, Point p2)
    {
        super();
        mP1 = p1;
        mP2 = p2;
    }

    // Line from another line (copy constructor)
    public Line(Line other)
    {
        mP1 = other.mP1;
        mP2 = other.mP2;
    }

    // setters and getters
    public Point getP1()
    {
        return mP1;
    }

    public void setP1(Point p1)
    {
        mP1 = p1;
    }

    public Point getP2()
    {
        return mP2;
    }

    public void setP2(Point p2)
    {
        mP2 = p2;
    }

    public int getX1()
    {
        return mP1.getX();
    }

    public int getX2()
    {
        return mP2.getX();
    }

    public int getY1()
    {
        return mP1.getY();
    }

    public int getY2()
    {
        return mP2.getX();
    }

    public void setX1(int x1)
    {
        mP1.setX(x1);
    }

    public void setX2(int x2)
    {
        mP2.setX(x2);
    }

    public void setY1(int y1)
    {
        mP1.setY(y1);
    }

    public void setY2(int y2)
    {
        mP2.setY(y2);
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((mP1 == null) ? 0 : mP1.hashCode());
        result = prime * result + ((mP2 == null) ? 0 : mP2.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Line other = (Line) obj;
        if (mP1 == null)
        {
            if (other.mP1 != null) return false;
        }
        else if (!mP1.equals(other.mP1)) return false;
        if (mP2 == null)
        {
            if (other.mP2 != null) return false;
        }
        else if (!mP2.equals(other.mP2)) return false;
        return true;
    }

    @Override
    public String toString()
    {
        return "Line [mP1=" + mP1 + ", mP2=" + mP2 + "]";
    }
//misc method
   public double length()
   {
       //length of the line is the distane between its two points;
       return mP1.distanceTo(mP2);
   }
}
