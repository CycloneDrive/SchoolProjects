/*
Tran, Dan
CS A170
*/
public class Point
{
    // fields
    private int mX;
    private int mY;

    // 1) paramaterized constuctor creates a new object by providing all the
    // values of the field)
    public Point(int x, int y)
    {
        super();
        mX = x;
        mY = y;
    }

    // 2) copy constructor creates a new object by coping all values of existing
    // object
    public Point(Point other)
    {
        mX = other.mX;
        mY = other.mY;
    }

    // 3) Default Constructor creates a new object by providing defauly values
    // to each field *no parameters*
    public Point()
    {
        mX = 0;
        mY = 0;
    }

    // Setters and Getters
    public int getX()
    {
        return mX;
    }

    public void setX(int x)
    {
        mX = x;
    }

    public int getY()
    {
        return mY;
    }

    public void setY(int y)
    {
        mY = y;
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + mX;
        result = prime * result + mY;
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Point other = (Point) obj;
        if (mX != other.mX) return false;
        if (mY != other.mY) return false;
        return true;
    }

    @Override
    public String toString()
    {
        return "Point [X=" + mX + ", Y=" + mY + "]";
    }

    public double distanceTo(Point other)
    {
        double dX2 = Math.pow((other.mX - mX), 2);
        double dY2 = Math.pow((other.mY - mY), 2);
        return Math.sqrt(dX2 + dY2);

    }
}
