/*
Tran, Dan
CS A170
March  2, 2018 
*
IC #08#
*/
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ChangeMaker extends JFrame
{

    public static void main(String[] args)
    {

        int cents,centscopy,quarters, dimes, nickels, pennies;
        // User input: JOptionPane.showInputDialog
        //Use parseInt to convert the string "87" into int87
        cents = Integer.parseInt(JOptionPane.showInputDialog(null, "Please enter a number of cents between 1 and 99:"));
        centscopy= cents;
              
        
        // Change given in coins
        quarters = cents / 25;
        cents = cents % 25;
        dimes = cents / 10;
        cents = cents % 10;
        nickels = cents / 5;
        pennies = cents % 5; 
        // Left over after filtering out nickels is the amount of pennies

        JOptionPane.showMessageDialog(null, centscopy + " in coins can be given as:\n" +
        		  quarters + " quarter(s)\n" 
        		+ dimes + " dime(s)\n" 
        		+ nickels + " nickel(s)\n"
        		+ pennies + " penny(ies)");
        
    }

}
