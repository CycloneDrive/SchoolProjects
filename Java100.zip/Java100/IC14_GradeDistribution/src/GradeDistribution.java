/*
Tran, Dan
CS A170
*/
public class GradeDistribution {
	// 1) Fields
	private int mNumberAs;
	private int mNumberBs;
	private int mNumberCs;
	private int mNumberDs;
	private int mNumberFs;

	// 2) Constructors
	public GradeDistribution(int NumberAs, int NumberBs, int NumberCs, int NumberDs, int NumberFs) {
		mNumberAs = NumberAs;
		mNumberBs = NumberBs;
		mNumberCs = NumberCs;
		mNumberDs = NumberDs;
		mNumberFs = NumberFs;

	}

	public GradeDistribution(GradeDistribution other) {
		mNumberAs = other.mNumberAs;
		mNumberBs = other.mNumberBs;
		mNumberCs = other.mNumberCs;
		mNumberDs = other.mNumberDs;
		mNumberFs = other.mNumberFs;

	}

	public void setAllGrades(int NumberAs, int NumberBs, int NumberCs, int NumberDs, int NumberFs) {
		mNumberAs = NumberAs;
		mNumberBs = NumberBs;
		mNumberCs = NumberCs;
		mNumberDs = NumberDs;
		mNumberFs = NumberFs;
	}

	public void setNumberAs(int NumberAs) {
		mNumberAs = NumberAs;
	}

	public void setNumberBs(int NumberBs) {
		mNumberBs = NumberBs;
	}

	public void setNumberCs(int NumberCs) {
		mNumberCs = NumberCs;
	}

	public void setNumberDs(int NumberDs) {
		mNumberDs = NumberDs;
	}

	public void setNumberFs(int NumberFs) {
		mNumberFs = NumberFs;
	}

	public int getNumberGrades() {
		return mNumberAs + mNumberBs + mNumberCs + mNumberDs + mNumberFs;
	}

	public double getPercentAs() {
		return 100 * mNumberAs / (mNumberAs + mNumberBs + mNumberCs + mNumberDs + mNumberFs);
	}

	public double getPercentBs() {
		return 100* mNumberBs/ (mNumberAs + mNumberBs + mNumberCs + mNumberDs + mNumberFs);
	}

	public double getPercentCs() {
		return 100* mNumberCs / (mNumberAs + mNumberBs + mNumberCs + mNumberDs + mNumberFs);
	}

	public double getPercentDs() {
		return 100* mNumberDs / (mNumberAs + mNumberBs + mNumberCs + mNumberDs + mNumberFs);
	}

	public double getPercentFs() {
		return 100 * mNumberFs / (mNumberAs + mNumberBs + mNumberCs + mNumberDs + mNumberFs);
	}

	public boolean equals(GradeDistribution other) {
		if (mNumberAs == other.mNumberAs && mNumberBs == other.mNumberBs && mNumberCs == other.mNumberCs
				&& mNumberDs == other.mNumberDs && mNumberFs == other.mNumberFs)
			return true;
		else
			return false;
	}

	public String toString() {
		String output = "";
		System.out.println("***************************************************");
		for (int a = 0; a < mNumberAs; a++) {
			System.out.print("*");
		}
		System.out.println(" A");
		for (int b = 0; b < mNumberBs; b++) {
			System.out.print("*");
		}
		System.out.println(" B");
		for (int c = 0; c < mNumberCs; c++) {
			System.out.print("*");
		}
		System.out.println(" C");
		for (int d = 0; d < mNumberDs; d++) {
			System.out.print("*");
		}
		System.out.println(" D");
		for (int f = 0; f < mNumberFs; f++) {
			System.out.print("*");
		}
		System.out.println(" F");
		return output;
	}

}
