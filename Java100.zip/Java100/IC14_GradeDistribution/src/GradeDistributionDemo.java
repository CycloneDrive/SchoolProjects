/*
Tran, Dan
CS A170
*/
public class GradeDistributionDemo {

	public static void main(String[] args) {
		GradeDistribution Test1 = new GradeDistribution(4, 14, 21, 7, 4);
		GradeDistribution Test2 = new GradeDistribution(Test1);

		System.out.println(Test1);
		System.out.println(Test2);

		System.out.println("Checking if the grade distribution is the same...");
		if (Test1.equals(Test2))
			System.out.println("The grade distribution is the same.");
		else
			System.out.println("The grade distribution is different.");
		System.out.println();

		System.out.print("Getting the number of grades...\n");
		System.out.println(Test1.getNumberGrades());
		System.out.println();

		System.out.println("Getting the percents of A's, B's, C's, D's, and F's....");
		System.out.println("A's: " + Test1.getPercentAs() + "%");
		System.out.println("B's: " + Test1.getPercentBs() + "%");
		System.out.println("C's: " + Test1.getPercentCs() + "%");
		System.out.println("D's: " + Test1.getPercentDs() + "%");
		System.out.println("F's: " + Test1.getPercentFs() + "%");
		System.out.println("");
		
		System.out.println("Setting all the grades of Test 1 to 5 A's, 6 B's, 7 C's, 8 D's, 9 F's");
		Test1.setAllGrades(5, 6, 7, 8, 9);
		System.out.println(Test1);
		System.out.println();
	
		System.out.println("Setting number of A's to 2...");
		Test1.setNumberAs(2);
		System.out.println(Test1);
		System.out.println("Setting number of B's to 9...");
		Test1.setNumberBs(9);
		System.out.println(Test1);
		System.out.println("Setting number of C's to 3...");
		Test1.setNumberCs(3);
		System.out.println(Test1);
		System.out.println("Setting number of D's to 10...");
		Test1.setNumberDs(10);
		System.out.println(Test1);
		System.out.println("Setting number of F's to 4...");
		Test1.setNumberFs(4);
		System.out.println(Test1);
	}

}
