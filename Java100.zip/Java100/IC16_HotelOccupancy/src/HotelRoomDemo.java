/*
Tran, Dan
CS A170
*/
public class HotelRoomDemo
{
    public static void main(String[] args)
    {
        // Let's make two Hotel rooms (101, 4) and (102. 2)
        HotelRoom room101 = new HotelRoom(101, 4);
        HotelRoom room102 = new HotelRoom(102, 2);
        // Print out the rooms
        System.out.println(room101 + "\n" + room102);
        //Print out the total occupancy;
        System.out.println("Total Occupancy = " + HotelRoom.getTotalOccupancy());
        //Test misc methods: (add 2 people to rooms 101 and 102
        room101.addToRoom(2);
        room102.addToRoom(2);
        System.out.println("");
        System.out.println(room101 + "\n" + room102);
        System.out.println("Total Occupancy = " + HotelRoom.getTotalOccupancy());
        //Remove 4 people from 101 and remove 5 from 102
        room101.removeFromRoom(4);
        room102.removeFromRoom(5);
        System.out.println("");
        System.out.println(room101 + "\n" + room102);
        System.out.println("Total Occupancy = " + HotelRoom.getTotalOccupancy());
    }

}
