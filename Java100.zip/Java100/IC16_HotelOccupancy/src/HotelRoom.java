/*
Tran, Dan
CS A170
*/
public class HotelRoom
{
    // Member Variables (fields) = each object has it's own copy
    private int mRoomNumber;
    private int mPeople;
    // static variable (only 1 copy for the whole class (all objects share it)
    private static int sTotalOccupancy = 0;

    // constructor
    public HotelRoom(int roomNumber, int people)
    {
        mRoomNumber = roomNumber;
        mPeople = people;
        // Add to total ocupany:
        sTotalOccupancy += people;
    }

    // setters and getters
    public int getRoomNumber()
    {
        return mRoomNumber;
    }

    public int getPeople()
    {
        return mPeople;
    }

    public static int getTotalOccupancy()
    {
        return sTotalOccupancy;
    }

    // equals
    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + mPeople;
        result = prime * result + mRoomNumber;
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        HotelRoom other = (HotelRoom) obj;
        if (mPeople != other.mPeople) return false;
        if (mRoomNumber != other.mRoomNumber) return false;
        return true;
    }

    // string
    @Override
    public String toString()
    {
        return "HotelRoom [RoomNumber=" + mRoomNumber + ", People=" + mPeople + "]";
    }

    // misc
    public boolean addToRoom(int numberOfPeople)
    {
        if (mPeople + numberOfPeople <= 4)
        {
            mPeople += numberOfPeople;
            sTotalOccupancy += numberOfPeople;
            return true;
        }
        else
            return false;
    }

    public boolean removeFromRoom(int numberOfPeople)
    {
        if (mPeople - numberOfPeople >= 0)
        {
            mPeople -= numberOfPeople;
            sTotalOccupancy -= numberOfPeople;
            return true;
        }
        else
            return false;
    }
}
