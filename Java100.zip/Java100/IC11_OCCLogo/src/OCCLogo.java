/*
Tran, Dan
CS A170
March  21, 2018 
*
IC #10#
*/
import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JApplet;

public class OCCLogo extends JApplet
{

    public void init()
    {
        setSize(1100, 900);
    }

    public void paint(Graphics canvas)
    {
        Color occOrange = new Color(245, 146, 69);
        Color occBlue = new Color(0, 80, 160);

        // Let's Loop rhough 5 logos going across
        for (int x = 0; x < 1050; x += 220)
        {
            for (int y = 0; y < 860; y += 240)
            {
                canvas.setColor(occOrange);
            canvas.fillOval(x + 10, y + 10, 200, 200);

            canvas.setColor(Color.WHITE);
            canvas.fillOval(x + 20, y + 20, 180, 180);

            canvas.setColor(occBlue);
            canvas.fillArc(x + 25, y + 25, 170, 170, 70, 275);

            canvas.setColor(Color.WHITE);
            canvas.fillOval(x + 40, y + 39, 156, 150);

            canvas.setColor(occBlue);
            canvas.fillArc(x + 45, y + 45, 140, 140, 79, 290);

            canvas.setColor(Color.WHITE);
            canvas.fillOval(x + 59, y + 55, 130, 125);

            canvas.setColor(occBlue);
            canvas.drawString("Orange Coast College", x + 45, y + 230);
            }
        }

    }

}
