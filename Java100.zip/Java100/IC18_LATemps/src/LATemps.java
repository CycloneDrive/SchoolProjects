/*
Tran, Dan
CS A170
*/
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Scanner;

public class LATemps
{
    public static final int SIZE = 5;

    public static void main(String[] args)
    {
        // in main
        int[] temps = new int[SIZE];
        int[] freqs;
        int maxFreq = 0;
        int mode = 0;
        int largest;
        double average, sum = 0.0;
        Scanner consoleScanner = new Scanner(System.in);
        DecimalFormat twoDigits = new DecimalFormat("00");

        for (int i = 0; i < temps.length; i++)
        {
            System.out.print("Please enter daily high for October " + twoDigits.format((i + 1)) + ": ");
            temps[i] = consoleScanner.nextInt();
            sum += temps[i];
        }
        consoleScanner.close();
        
        average = sum / temps.length;
        Arrays.sort(temps);
        largest = temps[temps.length - 1];
        
        //declare the freqs array to store all the temperature accounts
        freqs = new int[largest + 1];
        
        // loop through the temps array and keep a count (frequency) of each temp:
        //for (              : name of collection)
        for (int temp :temps)
        {
           // look up that frequency of that temperature and add 1 to the count  
           freqs[temp]++;
        }
        // loop thruogh the freqs array
        for (int i = 0; i < freqs.length; i++)
        {
          //determine max freq
            if(freqs [i] > maxFreq)
            {
                maxFreq = freqs[i];
                mode = i;
            }
           
        }
        
        System.out.println("\n~~~~~~~~~~Temperature Statistics~~~~~~~~~~");
        System.out.println("October's highest daily temperature was: " + largest);
        System.out.println("October's average high temperature was: " + average);
        System.out.println("October's most frequent high temp was: " + mode);
    }
}
