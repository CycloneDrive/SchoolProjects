/*
Tran, Dan
CS A170
March  2, 2018 
*
IC #07#
*/
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class AgeVerificationGUI extends JFrame
{

    public static void main(String[] args)
    {
        int choice; 
        // all code goes here
        // choice is assigned a value from dialog (0=YES, 1=NO,-1=X)
        choice = JOptionPane.showConfirmDialog(null,"Are you 21 years of age or older?","Age Verification",JOptionPane.YES_NO_OPTION);
        switch (choice)
        {
            case JOptionPane.YES_OPTION:
                //Yes option 
                JOptionPane.showMessageDialog(null,"Proceed on, adult!","You are an adult", JOptionPane.INFORMATION_MESSAGE);
                break;
            case JOptionPane.NO_OPTION:
                //NO option
                JOptionPane.showMessageDialog(null, "You shall not pass!","Minor Detected", JOptionPane.ERROR_MESSAGE);
                break;
            case JOptionPane.DEFAULT_OPTION:
                //x out (default option)
                JOptionPane.showMessageDialog(null, "You must answer the question.","Aversion Detected", JOptionPane.ERROR_MESSAGE);

                break;
      
        }
    }

}
