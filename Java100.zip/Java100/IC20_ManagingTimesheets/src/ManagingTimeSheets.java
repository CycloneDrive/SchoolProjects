/*
Tran, Dan
CS A170
*/
import java.text.DecimalFormat;
import java.util.Scanner;

public class ManagingTimeSheets
{
    // before main create constants
    public static final int ROWS = 3;
    public static final int COLS = 5;

    public static void main(String[] args)
    {
        // In main, declare array(s)
        double[][] timesheets = new double[ROWS][COLS];
        double[] totals = new double[ROWS];
        double[] average = new double[ROWS];
        String[] days = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" };
        Scanner consoleScanner = new Scanner(System.in);
        DecimalFormat oneDPs = new DecimalFormat("0.0");
        // loop through array to allow user input of hours worked
        // alt+shift+ r
        for (int e = 0; e < ROWS; e++)
        {
            for (int d = 0; d < COLS; d++)
            {
                System.out.print("Please enter hours worked for employee #" + (e + 1) + " on " + days[d] + ": ");
                timesheets[e][d] = consoleScanner.nextDouble();
                
                totals[e] += timesheets[e][d];
                average[e] = totals[e] / COLS;
            }
            System.out.println("");
        }
        consoleScanner.close();
        // loop for statistics (total + average)
        for (int e = 0; e < ROWS; e++)
        {
            System.out.println("\nTotal hours worked for employee #" + (e + 1) + " : " + oneDPs.format(totals[e]));
            System.out.println("Average hours worked for employee #" + (e + 1) + " : " + oneDPs.format(average[e]));
        }

    }

}
