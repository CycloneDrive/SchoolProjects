/*
Tran, Dan
CS A170
*/

import java.text.NumberFormat;

public class Doctor extends Employee
{
    private double mOfficeFee;
    private String mSpeciality;

    public Doctor(String honorific, String name, double annualsalary, String id, int yearhired, double officefee,
            String speciality)
    {
        super(honorific, name, annualsalary, id, yearhired);
        mOfficeFee = officefee;
        mSpeciality = speciality;
    }

    public Doctor()
    {
        super();
        mOfficeFee = 0.0;
        mSpeciality = "N/A";
    }

    public Doctor(Doctor other)
    {
        super(other);
        mOfficeFee = other.mOfficeFee;
        mSpeciality = other.mSpeciality;
    }

    public double getOfficeFee()
    {
        return mOfficeFee;
    }

    public void setOfficeFee(double officeFee)
    {
        mOfficeFee = officeFee;
    }

    public String getSpeciality()
    {
        return mSpeciality;
    }

    public void setSpeciality(String speciality)
    {
        mSpeciality = speciality;
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = super.hashCode();
        long temp;
        temp = Double.doubleToLongBits(mOfficeFee);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((mSpeciality == null) ? 0 : mSpeciality.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (!super.equals(obj)) return false;
        if (getClass() != obj.getClass()) return false;
        Doctor other = (Doctor) obj;
        if (Double.doubleToLongBits(mOfficeFee) != Double.doubleToLongBits(other.mOfficeFee)) return false;
        if (mSpeciality == null)
        {
            if (other.mSpeciality != null) return false;
        }
        else if (!mSpeciality.equals(other.mSpeciality)) return false;
        return true;
    }

    @Override
    public String toString()
    {
    	NumberFormat currency = NumberFormat.getCurrencyInstance();
        return "Doctor [" + mHonorific + mName +  ", Annual Salary = "  + currency.format(mAnnualSalary) +
                 ", Year Hired= " + mYearHired +  ", ID = " + mId + ", Office Fee = " + currency.format(mOfficeFee) + ", Speciality = " + mSpeciality + "]";
    }

}
