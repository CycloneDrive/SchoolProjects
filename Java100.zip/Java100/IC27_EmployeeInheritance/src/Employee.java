/*
Tran, Dan
CS A170
*/

import java.text.NumberFormat;

public class Employee extends Person
{
    protected double mAnnualSalary;
    protected String mId;
    protected int mYearHired;

    //with honorific
    public Employee(String honorific, String name, double annualsalary, String id, int yearhired)
    {
        super(honorific, name);
        mAnnualSalary = annualsalary;
        mId = id;
        mYearHired = yearhired;
    }
    
    //without honorific
    public Employee(String name, double annualsalary, String id, int yearhired)
    {
        this("", name, annualsalary, id, yearhired);// better way to do constructor
    }
    
    public Employee(Employee other)
    {
        this(other.mHonorific, other.mName, other.mAnnualSalary, other.mId, other.mYearHired);
    }
    
    public Employee()
    {
        super();
        mAnnualSalary = 0.0;
        mId = "";
        mYearHired = 0000;
    }
 
    public double getAnnualSalary()
    {
        return mAnnualSalary;
    }
    public void setAnnualSalary(double annualSalary)
    {
        mAnnualSalary = annualSalary;
    }
    public String getId()
    {
        return mId;
    }
    public void setId(String id)
    {
        mId = id;
    }
    public int getYearHired()
    {
        return mYearHired;
    }
    public void setYearHired(int yearHired)
    {
        mYearHired = yearHired;
    }
    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = super.hashCode();
        long temp;
        temp = Double.doubleToLongBits(mAnnualSalary);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((mId == null) ? 0 : mId.hashCode());
        result = prime * result + mYearHired;
        return result;
    }
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (!super.equals(obj)) return false;
        if (getClass() != obj.getClass()) return false;
        Employee other = (Employee) obj;
        if (Double.doubleToLongBits(mAnnualSalary) != Double.doubleToLongBits(other.mAnnualSalary)) return false;
        if (mId == null)
        {
            if (other.mId != null) return false;
        }
        else if (!mId.equals(other.mId)) return false;
        if (mYearHired != other.mYearHired) return false;
        return true;
    }
    @Override
    public String toString()
    {
    	NumberFormat currency = NumberFormat.getCurrencyInstance();
        return "Employee [" + mHonorific + mName + ", Annual Salary = " + currency.format(mAnnualSalary)
                + ", Year Hired = " + mYearHired + ", ID = " + mId + "]";
    }
   




}
