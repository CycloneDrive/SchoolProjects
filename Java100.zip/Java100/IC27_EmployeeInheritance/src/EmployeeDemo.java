/*
Tran, Dan
CS A170
*/

import java.util.ArrayList;

public class EmployeeDemo {

	public static void main(String[] args) 
	{
		Person Robert = new Person("Mr.", "Robert Khan");
		Employee Cynthia = new Employee("Mrs. ", "Cynthia Nguyen", 80000 , "C01234567", 1997);
		Doctor Tam = new Doctor("Ms. ", "Tam Nguyen", 200000, "C01234555", 2016, 20, "Pediatrician");
		Person Copy1 = new Person(Robert);
		Employee Copy2 = new Employee(Cynthia);
		Doctor Copy3 = new Doctor(Tam);		
		
		ArrayList<Person> employeesList = new ArrayList<>();
		employeesList.add(Robert);
		employeesList.add(Cynthia);
		employeesList.add(Tam);
		employeesList.add(Copy1);
		employeesList.add(Copy2);
		employeesList.add(Copy3);
	
		System.out.println("Printing out employees and copies...");
		for (Person p: employeesList)
			System.out.println(p);
		
				
		
	}

}
