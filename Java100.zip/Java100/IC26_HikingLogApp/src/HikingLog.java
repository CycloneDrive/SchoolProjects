/*
Tran, Dan
CS A170
*/
import java.util.HashMap;
import java.util.Scanner;

public class HikingLog {

	public static void main(String[] args) 
	{
		String hikeName, date;
        int value;
        Scanner consoleScanner = new Scanner(System.in);
        HashMap<String, Integer> hikingLog = new HashMap<>();
        System.out.println("~~~~~~~~~~~~~~~~~Welcome to the Hiking Log~~~~~~~~~~~~~~~~~");
        do
        {
            System.out.println("\nPlease enter name of hike completed (or \"quit\" to exit):");
            hikeName = consoleScanner.nextLine();
            if (hikeName.equalsIgnoreCase("quit")) 
                break;
            System.out.println("Please enter the date of completion (MM/DD/YYYY)   :");
            date = consoleScanner.nextLine();
            // if hash map already has the key(hike name), it already exists
            // get the value, add 1 to it, put back in hashmap
            if(hikingLog.containsKey(hikeName))
            {
                value = hikingLog.get(hikeName) + 1;
                hikingLog.put(hikeName, value);
            }
            // else put it with the value 1
            else
            {
                hikingLog.put(hikeName, 1);
            }
        }
        while (!hikeName.equalsIgnoreCase("quit"));
        consoleScanner.close();
       // Display Stats 
        System.out.println("~~~~~~~~~~~~~~~~~~~~~Hiking Statistics~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("Unique Hike Completed: " + hikingLog.size());
        // Loop through all the values
        int total =0;
        for (int v: hikingLog.values() )
        
            total +=v;
        
        System.out.println("Total Hikes Completed: " + total);
         // To find the most frequent hike
        int max = 0;
        String mostFrequent = "";
        for (String key:hikingLog.keySet())
        {
            if (hikingLog.get(key) > max)
            {
                max = hikingLog.get(key);
                mostFrequent = key;
            }
            
        }
        System.out.println("Most Frequent Hike   :" + mostFrequent);
	}

}
