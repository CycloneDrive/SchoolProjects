import java.text.DecimalFormat;
import java.util.Scanner;

/*
Huynh, William 
CS A170
February  02, 2018 
*
IC #02#
*/

public class Averageofthree
{

    public static void main(String[] args)
    {
        // Step 1) Declare any Variables needed 
        // Control + Alt-+ down arrow
        int number1, number2, number3;
        double average;
        
        //to read user input from console we need a Scanner
        Scanner consoleScanner = new Scanner (System.in); 
    	DecimalFormat oneDPs = new DecimalFormat("0.0"); 

        
        // Step 2) Get input from user
        //sysout ctrl + space
        System.out.print("Please enter number 1: ");
        // we need to read a value from the Scanner (User) 
        number1 = consoleScanner.nextInt();
        System.out.print("Please enter number 2: ");
        number2 = consoleScanner.nextInt();
        System.out.print("Please enter number 3: ");
        number3 = consoleScanner.nextInt();
        System.out.println("   ");
        
        //Step 3) Perform any needed calculations
        average = (number1 + number2 + number3) / 3.0;
       //Step 4) Output the result 
    
       System.out.print ("The average of the three numbers is: " + oneDPs.format(average));
       consoleScanner.close();

     
    }

}
