/*
Tran, Dan
CS A170
*/
public enum PlaneType
{
AIRBUS_320,
BOEING_737
}
