/*
Tran, Dan
CS A170
*/
public class Flight
{
    // 1) fields
    private String mCarrier;
    private int mNumber;
    private double mDuration;
    private PlaneType mPlaneType;
    private int mPassengers;

    // 2)Constructors (Instantiates new objects into the code) Has to be public
    // PARAMETERIZED CONSTRUCTOR
    public Flight(String Carrier, int Number, double Duration, PlaneType PlaneType, int Passengers)
    {
        // Asasign all values into our fields (member variables)
        // Transfer the data from form into your databases
        // mCNumber is getting information from user input
        mCarrier = Carrier;
        mNumber = Number;
        mDuration = Duration;
        mPlaneType = PlaneType;
        mPassengers = Passengers;
    }

    // COPY Constructor = instantiates a new object by copying all fields of
    // existing object
    public Flight(Flight other)
    {
        mCarrier = other.mCarrier;
        mNumber = other.mNumber;
        mDuration = other.mDuration;
        mPlaneType = other.mPlaneType;
        mPassengers = other.mPassengers;

    }

    // Accessors - provide read access to fields
    public String getCarrier()
    {
        return mCarrier;
    }

    public int getNumber()
    {
        return mNumber;
    }

    public double getDuration()
    {
        return mDuration;
    }

    public PlaneType getPlaneType()
    {
        return mPlaneType;
    }

    public int getPassengers()
    {
        return mPassengers;
    }

    // Mutators - allows us to write access ina field
    public void setCarrier(String Carrier)
    {
         mCarrier = Carrier;
    }

    public void setNumber(int Number)
    {
         mNumber = Number;
    }

    public void setDuration(double Duration)
    {
        mDuration=Duration;
    }

    public void setPlaneType(PlaneType PlaneType)
    {
        mPlaneType=PlaneType;
    }

    // comparing this flight with another flight
    public boolean equals(Flight other)
    {
        if (mCarrier.equals(other.mCarrier) && mNumber == (other.mNumber) && mDuration == (other.mDuration)
                && mPlaneType == (other.mPlaneType) && mPassengers == other.mPassengers)
            return true;
        else
            return false;
    }

    // toString method converts an object into a String for display
    public String toString()
    {
        String output = "[Carrier = " + mCarrier + ", Number = " + mNumber + ", Duration = " + mDuration
                + ", Plane Type = " + mPlaneType + ", Passengers = " + mPassengers + "]";
        return output;
    }

    // mPassengers = 100 //
    public boolean addPassengers(int amount)
    {
        if (mPlaneType == PlaneType.AIRBUS_320 && mPassengers + amount <= 150)
        {
            // Add amount to the passengers
            mPassengers += amount;
            return true;
        }
        else if (mPlaneType == PlaneType.BOEING_737 && mPassengers + amount <= 200)
        {
            mPassengers += amount;
            return true;
        }
        else
            return false;
    }

    public boolean removePassengers(int amount)
    {
        if (mPassengers - amount >= 0)
        {
            mPassengers -= amount;
            return true;
        }
        else
            return false;
    }

}
