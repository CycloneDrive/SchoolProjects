/*
Tran, Dan
CS A170
*/
public class TimeDemo
{

    public static void main(String[] args)
    {
        // Let's make 3 different times (1:40pm), (1:40pm) and midnight
        Time t1 = new Time(13, 40);
        Time t2 = new Time(t1);
        Time midnight = new Time();

        // Let's print out all 3 times
        System.out.println(t1 + "\n" + t2 + "\n" + midnight);

        // Let's compare t1 and t2 for equality
        System.out.println(t1.equals(t2) ? "The times are the same." : "The times are different." );
       
        //Let's compare t2 and midnight
        System.out.println(t2.equals(midnight) ? "The times are the same." : "The times are the different.");
    }

}
