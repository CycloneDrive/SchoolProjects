/*
Tran, Dan
CS A170
*/
import java.text.DecimalFormat;

public class Time
{
    // fields
    private int mHour;
    private int mMinute;

    // parameterized constructor
    public Time(int hour, int minute)
    {
        // validate hour and mintue before it goes into our database
        if (isValid(hour, minute))
        {
            mHour = hour;
            mMinute = minute;
        }
        // Alert user that input is invalid (throw it bak to them with error
        // message!)
        // Use illegalArgumentException built into Java
        else
        {
            throw new IllegalArgumentException(
                    "Invalid time. Hour must be between 0 and 23, Minute must be between 0 and 59.");
        }
    }

    // copy constructor
    public Time(Time other)
    {
        // call another constructor with the keyword "this"
        this(other.mHour, other.mMinute);
    }

    // default constructor
    public Time()
    {
        this(0, 0);
    }

    // setters and getters
    public int getHour()
    {
        return mHour;
    }

    public void setHour(int hour)
    {
        mHour = hour;
    }

    public int getMinute()
    {
        return mMinute;
    }

    public void setMinute(int minute)
    {
        mMinute = minute;
    }

    public void setTime(int hour, int minute)
    {
        mHour = hour;
        mMinute = minute;
    }

    // isAM
    private boolean isAM()
    {
        return (mHour < 12);
    }

    // isValid
    private boolean isValid(int hour, int minute)
    {
        return (hour >= 0 && hour <= 24 && minute >= 0 && minute <= 60);
    }

    // equals
    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + mHour;
        result = prime * result + mMinute;
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Time other = (Time) obj;
        if (mHour != other.mHour) return false;
        if (mMinute != other.mMinute) return false;
        return true;
    }

    // string
    @Override
    public String toString()
    {
        DecimalFormat twoDigits = new DecimalFormat("00");
        return "Time [" + twoDigits.format(mHour) + ":" + twoDigits.format(mMinute) + (isAM() ? " AM]" : " PM]");

    }

}
