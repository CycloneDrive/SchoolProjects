/*
Tran, Dan
CS A170
*/
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class TaskListDemo {

	@SuppressWarnings({ "resource", "unchecked" })
	public static void main(String[] args) 
	{
		String taskName = "";
		String deadline, duedate;
		int priority;

		Scanner consoleScanner = new Scanner(System.in);
		//array to atore all the tasks
		ArrayList<Task> tasksList = new ArrayList<>();
		File binaryFile = new File("Tasks.dat");
		
		//step 1: reading binary file in the array list
		System.out.println("Previously saved Tasks from binary file:");
		if (binaryFile.exists())
		{
			try
			{
				ObjectInputStream fileReader = new ObjectInputStream(new FileInputStream(binaryFile));
				tasksList = (ArrayList<Task>) fileReader.readObject();
				fileReader.close();
				for (Task theTask : tasksList)
					System.out.println(theTask);
			}
			catch (IOException | ClassNotFoundException e)
			{
				System.out.println(e.getMessage());
			}
		}
		else
			System.out.println("[None, please enter new Tasks]");
		
		//step 2: prompt user to input tasks
		///ass long as task ins''t quit keep looping
		
		do
		{
            System.out.println("********************************************");
			System.out.print("Please enter task name (or \"quit\" to exit): ");	
			taskName = consoleScanner.nextLine();
			
			if (taskName.equals("quit")) 
				break;
			
			System.out.print("Please enter due date (in form MM/DD/YYYY): ");
			duedate = consoleScanner.nextLine();
			
			System.out.print("Please enter deadline  : ");
			deadline = consoleScanner.nextLine();
			
			System.out.print("Please enter priority: ");
			priority = consoleScanner.nextInt();
			//clear console scanner
			consoleScanner.nextLine();
			
			//create new task object
			// add it to array list
			tasksList.add(new Task(deadline, duedate, taskName, priority));
			
		}while (!taskName.equals("quit"));
		
		//after the loop close scanner
		consoleScanner.close();
		
		//step 3: writing the binbary file
		try
		{
			 ObjectOutputStream fileWriter = new ObjectOutputStream(new FileOutputStream(binaryFile));
			 fileWriter.writeObject(tasksList);
			 fileWriter.close();
		}
		catch (IOException e)
		{
			System.out.println(e.getMessage());
		}
		
		
		
		
		
	}

}
