/*
Tran, Dan
CS A170
March  2, 2018 
*
IC #08#
*/
import java.text.DecimalFormat;
import java.util.Scanner;

public class BasicCalculator {

	public static void main(String[] args) {
		String Symbol;
		double Op1, Op2, Answer;
		Scanner consoleScanner = new Scanner(System.in);
		DecimalFormat twoDPs = new DecimalFormat("0.00");

		System.out.println(
				"********************************************************************************************************************");
		System.out.println(
				"**                                                                                                                **");
		System.out.println(
				"**                                    WELCOME TO BILL's BASIC CALCULATOR                                          **");
		System.out.println(
				"**                                                                                                                **");
		System.out.println(
				"********************************************************************************************************************");
		System.out.println("Type one of the following operators:");
		System.out.println("+ (for adding numbers)");
		System.out.println("- (for subtracting numbers)");
		System.out.println("* (for multiplying numbers)");
		System.out.println("/ (for dividing numbers)");
		System.out.println("% (for finding the remainder when two numbers are divided)");
		System.out.println("^ (for expotentiation - one number raised to the power of the other)");
		System.out.println(
				"********************************************************************************************************************");

		Symbol = consoleScanner.next();
		System.out.print("Enter an operand (number): ");
		Op1 = consoleScanner.nextInt();
		System.out.print("Enter an operand (number): ");
		Op2 = consoleScanner.nextInt();
		consoleScanner.close();

		switch (Symbol) 
		{
			case "+": 
				{
					Answer = Op1 + Op2;
					System.out.print("" + Op1 + " + " + Op2 + " = " + twoDPs.format(Answer));
					break;
				}
			case "-":
				{
					Answer = Op1 - Op2;
					System.out.print("" + Op1 + " - " + Op2 + " = " + twoDPs.format(Answer));
					break;
				}
			case "*":
				{
					Answer= Op1 * Op2;
					System.out.print("" + Op1 + " * " + Op2 + " = " + twoDPs.format(Answer));
					break;		
				}
			case "/":
				{
					Answer= Op1 / Op2;
					System.out.print("" + Op1 + " / " + Op2 + " = " + twoDPs.format(Answer));
					break;		
				}
			case"%":
				{
					Answer= Op1 / Op2;
					System.out.print("" + Op1 + " / " + Op2 + " = " + twoDPs.format(Answer));
					break;	
				}
			case"^":
				{
					Answer= Math.pow(Op1, Op2);
					System.out.print("" + Op1 + " ^ " + Op2 + " = " + twoDPs.format(Answer));
					break;	
				}
			default: System.out.println("Error!  Operator undefined in this version of the calculator.");	
		}
		
	}

}
