/*
Tran, Dan 
CS A170
February  23, 2018 
*
IC #05#
*/
import java.util.Scanner;

public class IsDivisible
{

    public static void main(String[] args)
    {   int x, y;
        Scanner consoleScanner = new Scanner(System.in);
        // ctrl + shift + o auto import
        System.out.print("Please enter a number for x: ");
        x = consoleScanner.nextInt();
        System.out.print("Please enter a number for y: ");
        y = consoleScanner.nextInt();
        // close console scanner ASAP whenever you dont need it anymore
        consoleScanner.close();
        // Decision : if/else statement 
        if(x%y==0)
 //block of code
        { // True part (code to execute if true)
            System.out.print("\n" + x + " is divisble by " + y);
        }
        else
        { // flase part (code to execute if false)
            System.out.print("\n" + x + " is not divisble by " + y);
        }
    }

}
