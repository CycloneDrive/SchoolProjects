/*
Tran, Dan
CS A170
February  27, 2018 
*
IC #06#
*/

import java.text.DecimalFormat;
import java.util.Scanner;

public class BasalMetabolicRate
{
    public static final double CHOCOLATE_BAR_CALORIES=230;
    public static void main(String[] args)
    {
       // Step1) Declare any needed variables
        double weight, height, age, bmr, bars;
        String gender;
        int activity; 
       // ctrl + shift + o 
        Scanner consoleScanner = new Scanner(System.in);
        
        
        DecimalFormat oneDPs = new DecimalFormat("0.0");
        DecimalFormat noDPs = new DecimalFormat("0");
  
       // Step 2) Prompt the user for input
        System.out.println("Please enter your weight (lb): ");
        weight = consoleScanner.nextDouble();
        // ctrl + alt + down
        System.out.println("Please enter your height (in): ");
        height = consoleScanner.nextDouble();
        System.out.println("Please enter your age: ");
        age = consoleScanner.nextDouble();
        System.out.println("Please enter Male or Female: ");
        // Forces the gender to be all cap: Male=>MALE 
        gender = consoleScanner.next().toUpperCase();
        System.out.println("Please enter the number corresponding with your activity factor:"
                + "\n1.Sedentary\n2.Somewhat active (exercise ocassionally)\n3.Active(exercise 3-4 times per week)\n4.Highly Active (exercise every day)");
        activity = consoleScanner.nextInt();
        consoleScanner.close();
        //Step 3) perform calcs
        if (gender.startsWith("F"))
        bmr= 655 + (4.35 * weight) + (4.7 * height) - (4.7 * age);
        else
        bmr= 66 + (6.23 * weight) + (12.7 * height) - (6.8 * age);
        //More calcs
        if(activity==1) //Sedentary increased by 20%(120%)
            bmr*=1.2; // shorthand operator, does bmr*1.2 in one   
        else if(activity==2)//Somwhat active increases by 30%
            bmr*=1.3;
        else if(activity==3)//Active increased by 40%
            bmr*=1.4;
        else//Highly active increases 50%
            bmr*=1.5;
        //Decide their activity level 

        // divide calories by 230
      bars = bmr / CHOCOLATE_BAR_CALORIES; 
        System.out.println("As a " + gender + " your BMR x Acitvity factor is " + noDPs.format(bmr) + " and you need to eat " + oneDPs.format(bars) + " chocolate bars to maintain this amount of calories.");

}
}
