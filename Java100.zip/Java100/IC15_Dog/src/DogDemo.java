/*
Tran, Dan
CS A170
*/
public class DogDemo
{

    public static void main(String[] args)
    {
        Dog scooby = new Dog("Scooby", "Great Dane", 7);
        Dog myDog = new Dog(scooby);
        System.out.println(scooby);
        System.out.println(myDog);
        System.out.println("");
        System.out.println("Are the dogs equal?");
        if (scooby.equals(myDog))
            System.out.println("Both dogs are the same");
        else
            System.out.println("The dogs are different");
        System.out.println("");
        System.out.println("Changing myDog...");
        myDog.setAge(2);
        myDog.setBreed("Terrier");
        myDog.setName("Toby");
        System.out.println(scooby);
        System.out.println(myDog);
        System.out.println("");
        System.out.println("Are the dogs equal now?");
        if (scooby.equals(myDog))
            System.out.println("Both dogs are the same");
        else
            System.out.println("The dogs are different");
        System.out.println("");
    }

}
