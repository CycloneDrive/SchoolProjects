/*
Tran, Dan
CS A170
*/

public class Truck extends Vehicle
{
	private double mLoadCapacity;
	private double mTowingCapacity;

	public Truck(String manufacturerName, int numberCylinder, double horsePower, String owner, double loadCapacity, double towingCapacity) 
	{
		super(manufacturerName, numberCylinder, horsePower, owner);
		mLoadCapacity = loadCapacity;
		mTowingCapacity = towingCapacity;
	}
	
	public Truck(Truck other)
	{
		 super(other);
			mLoadCapacity = other.mLoadCapacity;
			mTowingCapacity = other.mTowingCapacity;
	}

	public double getLoadCapacity() {
		return mLoadCapacity;
	}

	public void setLoadCapacity(double loadCapacity) {
		mLoadCapacity = loadCapacity;
	}

	public double getTowingCapacity() {
		return mTowingCapacity;
	}

	public void setTowingCapacity(double towingCapacity) {
		mTowingCapacity = towingCapacity;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		long temp;
		temp = Double.doubleToLongBits(mLoadCapacity);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(mTowingCapacity);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Truck other = (Truck) obj;
		if (Double.doubleToLongBits(mLoadCapacity) != Double.doubleToLongBits(other.mLoadCapacity))
			return false;
		if (Double.doubleToLongBits(mTowingCapacity) != Double.doubleToLongBits(other.mTowingCapacity))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Truck [Manufacturer Name = " + mManufacturerName + ", Number of Cylinders = " + mNumberCylinder
				+ ", HorsePower = " + mHorsePower + ", Owner = " + mOwner + ", Load Capacity = " + mLoadCapacity
				+ ", Towing Capacity = " + mTowingCapacity + "]";
	}
	
	
	
}
