/*
Tran, Dan
CS A170
*/
public class Vehicle 
{
	protected String mManufacturerName;
	protected int mNumberCylinder;
	protected double mHorsePower;
	protected String mOwner;
	
	public Vehicle(String manufacturerName, int numberCylinder, double horsePower, String owner) 
	{
		mManufacturerName = manufacturerName;
		mNumberCylinder = numberCylinder;
		mHorsePower = horsePower;
		mOwner = owner;
	}
	
	public Vehicle (Vehicle other)
	{
		mManufacturerName = other.mManufacturerName;
		mNumberCylinder = other.mNumberCylinder;
		mHorsePower = other.mHorsePower;
		mOwner = other.mOwner;
	}

	public String getManufacturerName() {
		return mManufacturerName;
	}

	public void setManufacturerName(String manufacturerName) {
		mManufacturerName = manufacturerName;
	}

	public int getNumberCylinder() {
		return mNumberCylinder;
	}

	public void setNumberCylinder(int numberCylinder) {
		mNumberCylinder = numberCylinder;
	}

	public double getHorsePower() {
		return mHorsePower;
	}

	public void setHorsePower(double horsePower) {
		mHorsePower = horsePower;
	}

	public String getOwner() {
		return mOwner;
	}

	public void setOwner(String owner) {
		mOwner = owner;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(mHorsePower);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((mManufacturerName == null) ? 0 : mManufacturerName.hashCode());
		result = prime * result + mNumberCylinder;
		result = prime * result + ((mOwner == null) ? 0 : mOwner.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vehicle other = (Vehicle) obj;
		if (Double.doubleToLongBits(mHorsePower) != Double.doubleToLongBits(other.mHorsePower))
			return false;
		if (mManufacturerName == null) {
			if (other.mManufacturerName != null)
				return false;
		} else if (!mManufacturerName.equals(other.mManufacturerName))
			return false;
		if (mNumberCylinder != other.mNumberCylinder)
			return false;
		if (mOwner == null) {
			if (other.mOwner != null)
				return false;
		} else if (!mOwner.equals(other.mOwner))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Vehicle [Manufacturer Name = " + mManufacturerName + ", Number of Cylinders = " + mNumberCylinder
				+ ", HorsePower = " + mHorsePower + ", Owner = " + mOwner + "]";
	}
	
	
}
