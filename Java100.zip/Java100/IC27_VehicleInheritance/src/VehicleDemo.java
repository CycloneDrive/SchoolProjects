/*
Tran, Dan
CS A170
*/

import java.util.ArrayList;

import edu.orangecoastcollege.cs170.whuynh6.ic27.Vehicle;

public class VehicleDemo {

	public static void main(String[] args) 
	{
		Vehicle Camry = new Vehicle("Toyota", 4, 301, "Captain Jack");
		Truck F150 = new Truck("Ford", 8, 450, "Tom", 2311.10, 8000.0 );
		Vehicle Copy1 = new Vehicle(Camry);
		Truck Copy2 = new Truck(F150);
		
		ArrayList<Vehicle> vehiclesList = new ArrayList<>();
		vehiclesList.add(Camry);
		vehiclesList.add(F150);
		vehiclesList.add(Copy1);
		vehiclesList.add(Copy2);
		
		System.out.println("Printing out vehicles and copies...");
		for (Vehicle v: vehiclesList)
			System.out.println(v);

	}

}
