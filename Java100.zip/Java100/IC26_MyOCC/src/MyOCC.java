/*
Tran, Dan
CS A170
*/
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class MyOCC 
{

	public static void main(String[] args) 
	{
		String username, course;
		ArrayList<String> coursesList = new ArrayList<>(20);
		Scanner consoleScanner = new Scanner(System.in);
		
		HashMap<String, ArrayList<String>> MyOCC = new HashMap<String, ArrayList<String>>( );
		System.out.println("~~~~~~~~~~~~~~~~~Welcome to the MyOCC~~~~~~~~~~~~~~~~~");
		  do
	        {
	            System.out.print("\nPlease enter student username (or \"quit\" to exit): ");
	            username = consoleScanner.nextLine();
	            if (username.equalsIgnoreCase("quit")) break;

	            System.out.print("Please enter course to enroll in: ");
	            course = consoleScanner.nextLine();
	            // If the username is already in my occ, add the new
	            if (MyOCC.containsKey(username))
	            {
	                // Get the old list of courses
	                coursesList = MyOCC.get(username);
	            }
	            
	            // Else, create a new ArrayList, add the new course and put in myOcc
	            else
	            {
	                coursesList = new ArrayList<>(20);
	                // Add the new one
	                // Put the list back into hashmap
	               
	            } coursesList.add(course);
	                MyOCC.put(username, coursesList);
	        }while (!username.equalsIgnoreCase("quit"));
	        consoleScanner.close();
	        
	        System.out.println("~~~~~~~~~~~~~~~Spring 2017 Enrollment~~~~~~~~~~~~~~~");
	        for (String student : MyOCC.keySet())
	        {
	        System.out.println("\nStudent: " + student);
	        System.out.println("Courses: " + MyOCC.get(student));
	        }
	        
	        System.out.println("\nTotal students enrolled:: " + MyOCC.size());
	        
	         int total = 0;
	         
	        // Let's loop through the values
	        for (ArrayList<String> courses : MyOCC.values())
	        {
	            total += courses.size();
	        }
	        System.out.println("Total courses enrolled: " + total);
	        
	        String mostFrequent ="";
	        int maxCount = 0;
	        for (String name : MyOCC.keySet())
	        {
	            ArrayList<String> value = MyOCC.get(name);
	            if (value.size() > maxCount)
	            {
	                maxCount = value.size();
	                mostFrequent = name;
	            }
	        }
	        System.out.println("Student with most courses: " + mostFrequent);
	}	
}
