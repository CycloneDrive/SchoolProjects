/*
Tran, Dan
CS A170
March  2, 2018 
*
IC #08#
*/
import java.text.DecimalFormat;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class BasalMetabolicRate extends JFrame
{
    public static final int CHOCOLATE_BAR_CALORIES = 230;

    public static void main(String[] args)
    {
        double weight, height, age, bmr, bars;
        int gender;
        
        // Use scanner for user input
        DecimalFormat noDP = new DecimalFormat("0");
        DecimalFormat oneDP = new DecimalFormat("0.0");

        // User input
        weight = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter your weight (lb): "));
        height = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter your height (in): "));
        age = Double.parseDouble(JOptionPane.showInputDialog(null,"Please enter your age: "));
        
        //Array = collection of values (several)
        //String Array = Collection of Strings
        String[] buttons= {"Female", "Male"};        
        gender = JOptionPane.showOptionDialog( null, "Calculate BMR for Female or Male","Identify Gender", 
                                                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null , buttons, buttons[1]);
        // Let's make a decision to determine gender 
        // BMR calculation with Harris-Benedict equation 
        
       if (gender==0)
            bmr = 655 + (4.35 * weight) + (4.7 * height) - (4.7 * age);
        else
            bmr = 66 + (6.23 * weight) + (12.7 * height) - (6.8 * age);
       String[] possibleValues = {"Sedentary","Somewhat active","Active","Highly Active"};
       Object selectedValue=
              JOptionPane.showInputDialog(null, "Select activity level:","BMR Activity Level",JOptionPane.INFORMATION_MESSAGE, null, possibleValues, possibleValues[3]);
     String selectedActivity = selectedValue.toString();
     
        switch (selectedActivity)
        {
            case "Sedentary": // Sedentary, increase bmr by 20%
                bmr *= 1.2;
                break;
            case "Somewhat active": // Somewhat active, increase by 30%
                bmr *= 1.3;
                break;
            case "Active": // Active, increase by 40%
                bmr *= 1.4;
                break;
            default:// Highly Active, increase by 50%
                bmr *= 1.5;

        }

        // Number of chocolate bars needed to maintain BMR
        bars = bmr / CHOCOLATE_BAR_CALORIES;
        JOptionPane.showMessageDialog(null, "As a " + buttons[gender] + " your BMR x Activity Factor is " + noDP.format(bmr) + " and you need to eat "
                        + oneDP.format(bars) + " chocolate bars to maintain this amount of calories.");
        // Display output to the user
       
    }

}
