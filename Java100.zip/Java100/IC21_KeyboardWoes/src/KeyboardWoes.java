/*
Tran, Dan
CS A170
*/
import java.util.InputMismatchException;
import java.util.Scanner;

public class KeyboardWoes
{

    public static void main(String[] args)
    {
        double number;
        Scanner consoleScanner = new Scanner(System.in);
        // keep track if an error occurs or not
        //intially it is false
        boolean error = false;
        
        do{
            try{    
            System.out.print("Please enter a number: ");
            number = consoleScanner.nextDouble();
            System.out.println("The number you entered is " + number);
            error = false;
            }
            catch (InputMismatchException e)
            {
                error = true;
                System.out.println("Input was not numeric, please try again.");
                //Let's get rid of the string on the consolescanner ("NO!")
                consoleScanner.nextLine();
            }  
        } while(error);  
        consoleScanner.close();
    }
    

}
