/*
Tran, Dan
CS A170
*/
public class Time
{
    private int mHour;
    private int mMinute;
    private String mMeridiem;
    
    // constructor
    public Time(int hour, int minute, String meridiem) throws InvalidHourException, InvalidMinuteException, InvalidMeridiemException
    {
       setHour(hour);
       setMinute(minute);
       setMeridiem(meridiem);
    }
    
    //setters and getters
    public int getHour()
    {
        return mHour;
    }

    public void setHour(int hour) throws InvalidHourException
    {
        if(hour > 12 || hour < 1)
            throw new InvalidHourException();
        
        mHour = hour;
    }

    public int getMinute()
    {
        return mMinute;
    }

    public void setMinute(int minute) throws InvalidMinuteException
    {
        if (minute > 59 || minute < 0)
            throw new InvalidMinuteException();
            
        mMinute = minute;
    }

    public String getMeridiem()
    {
        return mMeridiem;
    }

    public void setMeridiem(String meridiem) throws InvalidMeridiemException
    {
        //NOT ("AM" or "PM")
        //(NOT "AM" and NOT "PM")
        
        // IF YOUR USER TYPED in "PM"
        if (!meridiem.equalsIgnoreCase("AM") && !meridiem.equalsIgnoreCase("PM"))
           //(!meridiem.equals("AM") || !meridiem.equals("PM")
            throw new InvalidMeridiemException();
        
            mMeridiem = meridiem;
    }

    //tostring
    @Override
    public String toString()
    {
        if (mHour>=9)
            return "Time [" + 0 + mHour + ":"+ mMinute + " " + mMeridiem.toUpperCase() + "]";
        else
            return "Time [" + mHour + ":"+ mMinute + " " + mMeridiem.toUpperCase() + "]";
    }

    
    //equals
    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + mHour;
        result = prime * result + ((mMeridiem == null) ? 0 : mMeridiem.hashCode());
        result = prime * result + mMinute;
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Time other = (Time) obj;
        if (mHour != other.mHour) return false;
        if (mMeridiem == null)
        {
            if (other.mMeridiem != null) return false;
        }
        else if (!mMeridiem.equals(other.mMeridiem)) return false;
        if (mMinute != other.mMinute) return false;
        return true;
    }
    
    
}
