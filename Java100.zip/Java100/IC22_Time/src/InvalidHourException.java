package edu.orangecoastcollege.cs170.whuynh6.ic22;

public class InvalidHourException extends Exception
{
    //impleent 2 constructors (default and parameterized)
    public InvalidHourException()
    {
        //provides a default message to parent (exception)
        //Super refers tot he parent c;ass (exception)
        super("Hour cannot be less than 0 or greater than 12");
    }
    
    public InvalidHourException(String customMessage)
    {
        super(customMessage);
    }

}
