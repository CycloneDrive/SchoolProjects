/*
Tran, Dan
CS A170
*/
public class InvalidMinuteException extends Exception
{
    // implement 2 constructors (parameterized and default)
    public InvalidMinuteException()
    {
        // provides a default emssage to parent (exception)
        // super refers to the parent class (exception)
        super ("Minutes cannot be less than 0 or exceed 59");
    }
    
    public InvalidMinuteException(String customMessage)
    {
        super(customMessage);
    }
}
