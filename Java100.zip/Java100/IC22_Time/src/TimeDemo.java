/*
Tran, Dan
CS A170
*/
public class TimeDemo
{

    public static void main(String[] args)
    {
            Time t1;
            try
            {
                t1 = new Time(1,25, "PM");
                System.out.println(t1);
                Time t2 = new Time(13, 25, "pM");
                System.out.println(t2);
                Time t3 = new Time (1, 65, "PM");
                System.out.println(t3);
            }
            catch (InvalidHourException | InvalidMinuteException | InvalidMeridiemException e)
            {
                // TODO Auto-generated catch block
                System.out.println(e.getMessage());
            }
    }

}
