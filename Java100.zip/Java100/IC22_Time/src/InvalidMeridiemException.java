/*
Tran, Dan
CS A170
*/
public class InvalidMeridiemException extends Exception
{
    //implements 2 constructors (default and parameterized)
    public InvalidMeridiemException()
    {
        //provides a default message to parent (exception)
        //super refers to the parent classs (exception)
        super("The Meridiem must be AM or PM.");
    }
    
    public InvalidMeridiemException(String customMessage)
    {
        super(customMessage);
    }

}
