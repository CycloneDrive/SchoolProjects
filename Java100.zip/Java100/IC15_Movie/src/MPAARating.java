/*
Tran, Dan
CS A170
*/
public enum MPAARating {
G,
PG,
PG_13,
R,
NC_17
}
