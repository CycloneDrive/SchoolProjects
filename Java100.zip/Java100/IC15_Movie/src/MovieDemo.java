/*
Tran, Dan
CS A170
*/
public class MovieDemo {

	public static void main(String[] args) {
	Movie lotr = new Movie("Lord of The Rings", "Peter Jackson", MPAARating.PG_13, 5, 0, 6, 6, 136);
	Movie m1 = new Movie(lotr);
	System.out.println(lotr + "\n" + m1);
	System.out.println("");
	
	System.out.println("Checking is the two movies are the same...");
	System.out.println(lotr.equals(m1));
	System.out.println("");

	System.out.println("Checking a movie with no ratings..");
	Movie na = new Movie("N/A", "N/A", MPAARating.G, 0, 0, 0 ,0 ,0);
	System.out.println(na);
	System.out.println("");
	
	System.out.println("Changing the copy...");
	m1.setDirector("Tim Miller");
	m1.setMPAARating(MPAARating.R);
	m1.setName("Deadpool");
	System.out.println(lotr);
	System.out.println(m1);
	System.out.println("");
	
	System.out.println("Let's see if you can add ratings....");
	System.out.println("Can you add 6 as a rating?");
	System.out.println(na.addRating(6)+ "\n" + na);
	System.out.println("How about 5?");
	System.out.println(na.addRating(5)+ "\n" + na);
	System.out.println("How about 4?");
	System.out.println(na.addRating(4)+ "\n" + na);
	System.out.println("How about 3?");
	System.out.println(na.addRating(3)+ "\n" + na);
	System.out.println("How about 2?");
	System.out.println(na.addRating(2)+ "\n" + na);
	System.out.println("How about 1?");
	System.out.println(na.addRating(1)+ "\n" + na);
	System.out.println("");
	
	System.out.println("Let's see if you can subtract ratings....");
	System.out.println("Can you subtract 6?");
	System.out.println(na.removeRating(6) + "\n" + na);
	System.out.println("Can you subtract 5?");
	System.out.println(na.removeRating(5) + "\n" + na);
	System.out.println("Can you subtract 4?");
	System.out.println(na.removeRating(4) + "\n" + na);
	System.out.println("Can you subtract 3?");
	System.out.println(na.removeRating(3) + "\n" + na);
	System.out.println("Can you subtract 2?");
	System.out.println(na.removeRating(2) + "\n" + na);
	System.out.println("Can you subtract 1?");
	System.out.println(na.removeRating(1) + "\n" + na);
	}

}
