/*
Tran, Dan
CS A170
*/
import java.text.DecimalFormat;

public class Movie {
	// fields
	private String mName;
	private String mDirector;
	private MPAARating mMPAARating;
	private int mTerribleNumber;
	private int mBadNumber;
	private int mOkNumber;
	private int mGoodNumber;
	private int mExcellentNumber;

	// constructor
	public Movie(String name, String director, MPAARating MPAARating, int terribleNumber, int badNumber, int okNumber,
			int goodNumber, int excellentNumber) {
		mName = name;
		mDirector = director;
		mMPAARating = MPAARating;
		mTerribleNumber = terribleNumber;
		mBadNumber = badNumber;
		mOkNumber = okNumber;
		mGoodNumber = goodNumber;
		mExcellentNumber = excellentNumber;
	}

	// copy constructor
	public Movie(Movie other) {
		mName = other.mName;
		mDirector = other.mDirector;
		mMPAARating = other.mMPAARating;
		mTerribleNumber = other.mTerribleNumber;
		mBadNumber = other.mBadNumber;
		mOkNumber = other.mOkNumber;
		mGoodNumber = other.mGoodNumber;
		mExcellentNumber = other.mExcellentNumber;
	}
	
	// accessors/mutators for:movie name, director name, MPAA Rating
	public String getName() {
		return mName;
	}

	public void setName(String name) {
		mName = name;
	}

	public String getDirector() {
		return mDirector;
	}

	public void setDirector(String director) {
		mDirector = director;
	}

	public MPAARating getMPAARating() {
		return mMPAARating;
	}

	public void setMPAARating(MPAARating mPAARating) {
		mMPAARating = mPAARating;
	}

	//accesssors for tnumber,bnumber,onumber,gnumber,enumber
	public int getTerribleNumber() {
		return mTerribleNumber;
	}

	public int getBadNumber() {
		return mBadNumber;
	}

	public int getOkNumber() {
		return mOkNumber;
	}

	public int getGoodNumber() {
		return mGoodNumber;
	}

	public int getExcellentNumber() {
		return mExcellentNumber;
	}
	// calculateAverageRating- calculates and returns the average rating by multiplying the number of terrible ratings * 1, bad ratings * 2, ok ratings * 3, good ratings * 4, excellent ratings * 5 and dividing by the total number of ratings.  If there are no ratings for the movie yet, return 0.0
	public double calculateAverageRating()
	{
		double total = (mTerribleNumber + mBadNumber + mOkNumber + mGoodNumber + mExcellentNumber);
		double average = (mTerribleNumber + mBadNumber*2 + mOkNumber*3 + mGoodNumber*4 + mExcellentNumber*5)/total; 
		if(average >=0)
			return average;
		else
		return 0.0;
	}
	//addRating(int rating) - adds a rating for the movie, returns true if rating is between 1-5, false otherwise.
	public boolean addRating(int rating)
	{
		if (rating<1 || rating >5)
			return false;
		else if (rating==1)
			mTerribleNumber = mTerribleNumber + 1;
		else if (rating ==2)
			mBadNumber = mBadNumber + 1;
		else if (rating == 3)
			mOkNumber = mBadNumber + 1;
		else if (rating == 4)
			mGoodNumber = mGoodNumber + 1;
		else if (rating == 5)
			mExcellentNumber = mExcellentNumber + 1;
		return true;
	}
	//removeRating(int rating) - removes a rating for a movie.  Returns true if rating is between 1-5 and there is at least one rating to remove, false otherwise
	public boolean removeRating(int rating)
	{
		if (rating<1 || rating >5)
			return false;
		else if (rating==1)
			mTerribleNumber = mTerribleNumber - 1;
		else if (rating ==2)
			mBadNumber = mBadNumber - 1;
		else if (rating == 3)
			mOkNumber = mBadNumber - 1;
		else if (rating == 4)
			mGoodNumber = mGoodNumber - 1;
		else if (rating == 5)
			mExcellentNumber = mExcellentNumber - 1;
		return true;
	}
	//equals
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + mBadNumber;
		result = prime * result + ((mDirector == null) ? 0 : mDirector.hashCode());
		result = prime * result + mExcellentNumber;
		result = prime * result + mGoodNumber;
		result = prime * result + ((mMPAARating == null) ? 0 : mMPAARating.hashCode());
		result = prime * result + ((mName == null) ? 0 : mName.hashCode());
		result = prime * result + mOkNumber;
		result = prime * result + mTerribleNumber;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		if (mBadNumber != other.mBadNumber)
			return false;
		if (mDirector == null) {
			if (other.mDirector != null)
				return false;
		} else if (!mDirector.equals(other.mDirector))
			return false;
		if (mExcellentNumber != other.mExcellentNumber)
			return false;
		if (mGoodNumber != other.mGoodNumber)
			return false;
		if (mMPAARating != other.mMPAARating)
			return false;
		if (mName == null) {
			if (other.mName != null)
				return false;
		} else if (!mName.equals(other.mName))
			return false;
		if (mOkNumber != other.mOkNumber)
			return false;
		if (mTerribleNumber != other.mTerribleNumber)
			return false;
		return true;
	}

	//toString
	@Override
	public String toString() 
	{
		DecimalFormat twoDPs = new DecimalFormat("0.00"); 
		return "Movie [Name=" + mName + ", Director=" + mDirector + ", MPAARating=" + mMPAARating
				+ ", Average Rating=" + twoDPs.format(calculateAverageRating()) + "]";
	}

	

}
