/*
Tran, Dan
CS A170
*/

public class TimeInUseException extends Exception
{
	public TimeInUseException()
	{
		
	}
	
	public TimeInUseException(String message)
	{
		super(message);
	}

}
