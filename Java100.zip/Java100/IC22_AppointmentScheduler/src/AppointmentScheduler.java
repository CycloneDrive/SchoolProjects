/*
Tran, Dan
CS A170
*/
import java.util.InputMismatchException;
import java.util.Scanner;

public class AppointmentScheduler {
	 
	public static void main(String[] args)
	    {
			String[] names = new String[6];
			int time=0 , count = 0;
			Scanner consoleScanner = new Scanner(System.in);
			boolean error = false;
			for (int i=0; i < names.length; i++)
			{
				names[i]="No one";
			}
			
			do 
			{
				try 
				{
					System.out.print("What time would you like to schedule (PM) : ");
					time = consoleScanner.nextInt();
					consoleScanner.nextLine();
					if(time > 6 || time < 1)
						throw new InvalidTimeException("Please enter a valid time! 1-6");
					System.out.print("Please enter your name: ");
					String inputName = consoleScanner.nextLine();
					if(names[time].equalsIgnoreCase("No one"))
					{
					 names[time] = inputName; 
				     count++;
					}
					else
					{
						throw new TimeInUseException("This time is taken...");
					}			
				}
				
				catch(InputMismatchException e1)
				{
					System.out.println("Please eneter a valid number. EX) 1, 2, 3, 4, 5, 6");
					error = true;
					consoleScanner.nextLine();
				}
				
				catch(TimeInUseException e2)
				{
					System.out.println(e2.getMessage());
					error = true;
				}
				
				catch(InvalidTimeException e3)
				{
					System.out.println(e3.getMessage());
					error = true;
				}
				
				if(count<names.length)
				{
					System.out.println("Would you like to make another appointment? (Y for yes or N for no): ");
					String redo = consoleScanner.next();
					if(redo.equalsIgnoreCase("Y"))
					{
						error = true;
					}
					else if(redo.equalsIgnoreCase("N"))
					{
						error = false;
					}
						
				}			
				
			}while(error);
			consoleScanner.close();
			int hour= 0;
			System.out.println("\nHere is all the times scheduled: ");
			for (int i=0; i < names.length; i++)
			{
				hour++;
				System.out.println(names[i] + " has an appointment at " + hour);
			}
		 
	    }
}
