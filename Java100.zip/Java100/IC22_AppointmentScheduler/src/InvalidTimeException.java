/*
Tran, Dan
CS A170
*/

public class InvalidTimeException extends Exception
{
	public InvalidTimeException()
		{
			
		}
	public InvalidTimeException(String message)
	{
		super(message);
	}
	
}
