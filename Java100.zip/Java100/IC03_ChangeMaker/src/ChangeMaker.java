/*
Tran, Dan 
CS A170
February  14, 2018 
*
IC #03#
*/
import java.util.Scanner;

public class ChangeMaker {

	public static void main(String[] args) {
		int cents, quarters, dimes, nickels, pennies;
		
		Scanner consoleScanner = new Scanner (System.in);
		
		System.out.println("Enter a whole number from 1 to 99.\nI will find a combination of coins equal that amount of change.");
		cents = consoleScanner.nextInt(); 
		
		quarters = cents/25;
		cents=cents%25;
		dimes=cents/10;
		cents=cents%10;
		nickels=cents/5;
		cents=cents%5;
		pennies=cents/1; 
		
		System.out.println("\n" + cents + " cents in coins can be given as:\n" 
							+ quarters +" quarter(s)\n" + dimes +" dime(s)\n" +
							nickels +" nickel(s)\n" + pennies + " penny(ies)");
		
        consoleScanner.close();

	}

}
