/*
Tran, Dan
CS A170
March  14, 2018 
*
IC #10#
*/
public class NestedShapes {
	public static void main(String[] args) {
		for (int row = 1; row <= 4; row++) 
		{
			// Nested loop for columns
			for (int col = 1; col <= 4; col++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();
		for (int row = 1; row <= 4; row++) 
		{
			// Nested loop for columns
			for (int col = 1; col <= 4; col++) {
				System.out.print(row);
			}
			System.out.println();
		}
		System.out.println();
		for (int row = 1; row <= 4; row ++)
		{
			for (int col = 1; col <= row; col++)
			{
			System.out.print("*");	
			}
			System.out.println();
		}
		System.out.println();
		for (int row = 1; row <= 4; row ++)
		{
			for (int col = 1; col <= row; col++)
			{
				System.out.print(row);	
			}
			System.out.println();
		}
	}
}