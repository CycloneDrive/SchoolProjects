/*
Tran, Dan
CS A170
February  23, 2018 
*
IC #05#
*/
import java.text.DecimalFormat;
import java.util.Scanner;

public class BloodAlcoholContent
{
    public static final double OUNCES_ALCHOHOL= 1.5;
    public static final double BAC_LIMIT= 0.08;
    public static void main(String[] args)
    {   int drinks, weight; 
        double bac;
        
        DecimalFormat threeDPs= new DecimalFormat("0.000");
        Scanner consoleScanner = new Scanner(System.in);
        
        System.out.print("Enter the number of alcoholic drinks consumed: ");
        drinks = consoleScanner.nextInt();
        System.out.print("Please enter your weight in lbs: ");
        weight = consoleScanner.nextInt();
        consoleScanner.close();
        
        bac = (4.136 *(drinks*OUNCES_ALCHOHOL)/weight);
        System.out.println("\nYour BAC is " + threeDPs.format(bac));
        if(bac>= BAC_LIMIT)
        {
            System.out.print("According to the state of California, you are intoxicated. Do not drive!");
        }
        else
        {
            System.out.print("According to the state of California, you are not intoxicated. Please consider others and do not drink and drive!");
        }
            
        
    }

}
