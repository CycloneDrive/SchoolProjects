/*
Tran, Dan
CS A170
March  2, 2018 
*
IC #07#
*/
import java.util.Scanner;

public class LexicographicOrdering
{
    public static void main(String[] args)
    {
        String s1,s2,s3;
        Scanner consoleScanner= new Scanner(System.in);
       
        System.out.println("Please enter three separate strings (in any order):");
        s1= consoleScanner.next();
        s2= consoleScanner.next();
        s3= consoleScanner.next();
        consoleScanner.close();
        System.out.println("\nIn lexicographic ordering, the strings you entered are:");
        if (s1.compareTo(s2)<=0&& s2.compareTo(s3)<=0)
            System.out.println(s1 + "\n" + s2 + "\n" + s3);
        else if (s1.compareTo(s3)<=0&& s3.compareTo(s2)<=0)
            System.out.println(s1 + "\n" + s3 + "\n" + s2);
        else if (s2.compareTo(s1)<=0&& s1.compareTo(s3)<=0)
            System.out.println(s2 + "\n" + s1 + "\n" + s3);
        else if (s2.compareTo(s3)<=0&& s3.compareTo(s1)<=0)
            System.out.println(s2 + "\n" + s3 + "\n" + s1);
        else if (s3.compareTo(s1)<=0&& s1.compareTo(s2)<=0)
            System.out.println(s3 + "\n" + s1 + "\n" + s2);
        else 
            System.out.println(s3 + "\n" + s2 + "\n" + s1);

    }
}
