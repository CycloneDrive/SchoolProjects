/*
Huynh, William 
CS A170
February  14, 2018 
*
IC #03#
*/

import java.text.NumberFormat;
import java.util.Scanner;

public class MortgagePayment {

	public static void main(String[] args) {
		double mpayment, mbalance, interest, principal;
		
		Scanner consoleScanner= new Scanner(System.in); 
		NumberFormat currency = NumberFormat.getCurrencyInstance();
		
		System.out.print("Please enter your mortgage payment: $");
		mpayment = consoleScanner.nextDouble();
		System.out.print("Please enter outstanding balance on mortgage: $");
		mbalance = consoleScanner.nextDouble();
		interest = (mbalance*0.04)/12;
		principal =	mpayment - interest;
		
		System.out.print("\nOf your $2,500 mortgage payment:\n" + currency.format(interest) + " goes to interest\n" + currency.format(principal) + " goes to principal");
		
        consoleScanner.close();

	}

}
