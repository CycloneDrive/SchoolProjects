/*
Tran, Dan
CS A170
*/
public class Rational
{
    //fields
    private int mNumerator;
    private int mDenominator;
    
    //constructor
    public Rational(int numerator, int denominator) throws ZeroDenominatorException
    {
        mNumerator = numerator;
        setDenominator(denominator);
    }

    //getters and setters
    public int getNumerator()
    {
        return mNumerator;
    }

    public void setNumerator(int numerator)
    {
        mNumerator = numerator;
    }

    public int getDenominator()
    {
        return mDenominator;
    }

    //to alert other programmeres that this method "may" generate an exception
    // add the keyword "throws"
    // data class (rational) "throws" the exception
    // the demo class (rationaldemo) "catch" the exception 
    public void setDenominator(int denominator) throws ZeroDenominatorException
    {
        //protext against zero as denominator
        // if denominator is 0, generate a new ZeroDenominatoreException
        if(denominator == 0)
            //generate an exception: use "throw" keyword
            throw new ZeroDenominatorException();
        
        mDenominator = denominator;
    }

    //equals
    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + mDenominator;
        result = prime * result + mNumerator;
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Rational other = (Rational) obj;
        if (mDenominator != other.mDenominator) return false;
        if (mNumerator != other.mNumerator) return false;
        return true;
    }

    //to string
    @Override
    public String toString()
    {
        //TODO: Normalize the fration (e.g. 1/-2 => -1/2)
        // (e.g. -1/-2=> 1/2
        if (mDenominator < 0)
        {
            mNumerator *= -1;
            mDenominator *= -1;
        }
        return mNumerator + "/" + mDenominator;
    }
    //cstom exception ( new class)
    
    
}
