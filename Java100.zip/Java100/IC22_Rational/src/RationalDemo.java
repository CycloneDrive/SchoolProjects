/*
Tran, Dan
CS A170
*/
public class RationalDemo
{

    public static void main(String[] args)
    {
        // let's create 4 rational numbers (1/2 , 1/-2 , -1/-2 ,1/0)
        try
        {
            Rational r1 = new Rational(1,2);
            System.out.println(r1);
            Rational r2 = new Rational (1,-2);
            System.out.println(r2);
            Rational r3 = new Rational(-1,-2);
            System.out.println(r3);
            Rational r4 = new Rational (1,0);
            System.out.println(r4);
        }
        catch (ZeroDenominatorException e)
        {
            // TODO Auto-generated catch block
            System.out.println(e.getMessage());
        }
    }

}
