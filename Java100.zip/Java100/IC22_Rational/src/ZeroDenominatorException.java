/*
Tran, Dan
CS A170
*/
public class ZeroDenominatorException extends Exception
{
    // implements 2 constructors (default and parameterized)
    public ZeroDenominatorException()
    {
        // provides a default message to parent (exeception)
        // super refers to the parent class (exception)
        super("Denominator cannot be zero.");        
    }
    
    public ZeroDenominatorException(String customMessage)
    {
        super(customMessage);
    }
}
