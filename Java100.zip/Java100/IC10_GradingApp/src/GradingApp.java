/*
Tran, Dan
CS A170
March  14, 2018 
*
IC #10#
*/
import java.text.DecimalFormat;
import java.util.Scanner;

public class GradingApp
{

    public static void main(String[] args)
    {
        // Declare variables needed
        double grade, low = Double.MAX_VALUE, average, high = Double.MIN_VALUE, sum = 0;
        int numberGrades = 0, numberAs = 0, numberBs = 0, numberCs = 0, numberDs = 0, numberFs = 0;
        Scanner consoleScanner = new Scanner(System.in);
        DecimalFormat oneDp = new DecimalFormat("0.0");
        // Prompt user for input:
        System.out.println("Please input grades one per line (or type -1 to quit):");
        do
        {
            grade = consoleScanner.nextDouble();
            // Add 1 to number of grades
            if (grade != -1)
            {
                numberGrades++;
                // Add the grade to the sum
                sum += grade;
                // Make a decision to see what the letter grade is
                if (grade >= 90)
                    numberAs++;
                else if (grade >= 80)
                    numberBs++;
                else if (grade >= 70)
                    numberCs++;
                else if (grade >= 60)
                    numberDs++;
                else
                    numberFs++;
                // Make a decision to see if the grade is the new low
                if (grade < low) low = grade;
                if (grade > high) high = grade;
                // Calculate average ONLY once AFTER THE LOOT
            }
        }
        while (grade != -1);
        consoleScanner.close();
        average = sum / numberGrades;
        System.out.println("Total number of grades = " + numberGrades + "\nNumbers of A's = " + numberAs
                + "\nNumber of B's = " + numberBs + "\nNumber of Cs = " + numberCs + "\nNumber of D's = " + numberDs
                + "\nNumberof F's = " + numberFs + "\nLow Grade = " + low +"%"+ "\nClass Average = " + oneDp.format(average) +"%"
                + "\nHigh Grade = " + high +"%");

    }

}
