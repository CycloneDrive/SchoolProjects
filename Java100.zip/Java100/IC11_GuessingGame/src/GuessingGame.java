/*
Tran, Dan
CS A170
March  14, 2018 
*
IC #10#
*/

import java.util.Random;
import java.util.Scanner;

public class GuessingGame
{
    public static void main(String[] args)
    {
        int answer, guess, numberCorrect = 0, sumCorrect=0;
        Scanner consoleScanner = new Scanner(System.in);
        Random rng = new Random();

        // Generate a random answer between 10000 and 99999 (subtract and then
        // add 1 to the difference)
        answer = rng.nextInt(90000) + 10000;

        int a1 = answer / 10000;
        int a2 = answer % 10000 / 1000;
        int a3 = answer % 1000 / 100;
        int a4 = answer % 100 / 10;
        int a5 = answer % 10;

        System.out.println("Cheat code = " + answer);
        do
        {
            System.out.print("Please enter a 5-digit code (your guess):");
            guess = consoleScanner.nextInt();
            // Extract all 5 digits from guess

            int g1 = guess / 10000;
            int g2 = guess % 10000 / 1000;
            int g3 = guess % 1000 / 100;
            int g4 = guess % 100 / 10;
            int g5 = guess % 10;

            if (g1 == a1)
            {
                numberCorrect++;
                sumCorrect += a1;
            }
            if (g2 == a2)
            {
                numberCorrect++;
                sumCorrect += a2;
            }
            if (g3 == a3)
            {
                numberCorrect++;
                sumCorrect += a3;
            }
            if (g4 == a4)
            {
                numberCorrect++;
                sumCorrect += a4;
            }
            if (g5 == a5)
            {
                numberCorrect++;
                sumCorrect += a5;
            }
            System.out.println("Number of Digits Correct: " + numberCorrect);
            System.out.println("Sum of Digits Correct: " + sumCorrect);
            numberCorrect = 0;
            sumCorrect = 0; 
            // reset the number and sum to 0 after the guess
        }
        while (guess != answer);
        System.out.println("****HOORAY! You solved it. You are so smart****");
        consoleScanner.close();
    }
}
