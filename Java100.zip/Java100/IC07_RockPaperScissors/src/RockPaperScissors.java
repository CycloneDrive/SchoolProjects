import java.util.Scanner;

/*
Tran, Dan
CS A170
March  2, 2018 
*
IC #07#
*/
public class RockPaperScissors
{
	 public static void main(String[] args)
	 {
		 String P1,P2;
		 
		 Scanner consoleScanner = new Scanner(System.in);
		 
		 System.out.print("Player 1 (enter R for rock, P for paper, S for scissors): ");
		 P1 = consoleScanner.next().toUpperCase(); 
		 System.out.print("Player 2 (enter R for rock, P for paper, S for scissors): ");
		 P2 = consoleScanner.next().toUpperCase(); 
		 consoleScanner.close();
		 switch (P1)
		 {
			 case "P":
				 switch (P2) 
				 {	
				 		case "R":
				 		System.out.print("Player 1 wins! Paper beats rock.");
				 		break;
				 		case "P":
				 		System.out.print("It's a draw!");
				 		break;
				 		case "S":
				 		System.out.print("Player 2 wins! Scissors beats paper.");
				 		break;
				 }	
				 break;
			case "R":
				switch (P2)
				{
					case "R":
						System.out.print("It's a draw!");
						break;
					case "P":
						System.out.print("Player 2 wins! Paper beats rock.");
						break;
					case "S":
		 				System.out.print("Player 1 wins! Rock beats scissors.");
		 		break;
				}
				break;
			 case "S":
					switch (P2)
					{
						case "R":
							System.out.print("Player 2 wins! Rock beats scissors.");
							break;
						case "P":
							System.out.print("Player 1 wins! Scissors beats paper.");
							break;
						case "S":
			 				System.out.print("It's a draw!");
			 		break;
					}
					
		 }
	 }
}
	    