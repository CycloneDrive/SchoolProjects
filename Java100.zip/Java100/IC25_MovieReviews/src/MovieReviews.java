/*
Tran, Dan
CS A170
*/
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class MovieReviews
{

    public static void main(String[] args)
    {
        DecimalFormat oneDps = new DecimalFormat("0.0");
        double review, sum = 0.0;
        ArrayList<Double> reviewsList = new ArrayList<>();
        
        try
        {
            Scanner fileScanner = new Scanner(new File("MovieReviews.txt"));
            while (fileScanner.hasNextDouble())
            {
                review = fileScanner.nextDouble();
                // add the review to the array list
                reviewsList.add(review);
                //add review to the sum
                sum += review; 
            }
            //close Scanner
            fileScanner.close();
            //print stats
            System.out.println("The number of movie reviews is " + reviewsList.size());
            System.out.println("The average review is " + oneDps.format((sum/reviewsList.size())));
        }
        catch (IOException e)
        {
            System.out.println(e.getMessage());
        }


    }

}
