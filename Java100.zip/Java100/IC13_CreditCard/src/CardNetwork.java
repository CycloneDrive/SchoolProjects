/*
Tran, Dan
CS A170
March  28, 2018 
*
IC #10#
*/
public enum CardNetwork
{
AMEX,
DISCOVER,
MASTER_CARD,
VISA
}
