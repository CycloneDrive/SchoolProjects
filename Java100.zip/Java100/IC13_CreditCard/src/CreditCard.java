/*
Tran, Dan
CS A170
March  28, 2018 
*
IC #10#
*/
public class CreditCard {
	// 1)Fields
	private String mCardHolder;
	private String mExpirationDate;
	private CardNetwork mNetwork;
	private int mNumber;
	private int mSecurityCode;

	// 2)Constructors
	public CreditCard(CardNetwork Network, String CardHolder, int Number, String ExpirationDate, int SecurityCode) {
		mNetwork = Network;
		mCardHolder = CardHolder;
		mNumber = Number;
		mExpirationDate = ExpirationDate;
		mSecurityCode = SecurityCode;
	}

	// 3) Accessors
	public CardNetwork getCardNetwork() {
		return mNetwork;
	}

	public String getCardHolder() {
		return mCardHolder;
	}

	public int getNumber() {
		return mNumber;
	}

	public String getExpirationDate() {
		return mExpirationDate;
	}

	// 4) Mutator
	public void setCardHolder(String newCardHolder) {
		mCardHolder = newCardHolder;
	}

	// 5) Equals
	public boolean equals(CreditCard other)
    {
    if ( mNetwork.equals(other.mNetwork) && mCardHolder.equals(other.mCardHolder) && mNumber==(other.mNumber) &&  mExpirationDate.equals(other.mExpirationDate) && mSecurityCode ==other.mSecurityCode)
    	return true;
    else
    	return false;
    }
	
	public String toString()
	{
		int FourDigits = mNumber % 10000;
		String output = "Credit Card [" + mNetwork + ", ************" +  FourDigits + ", " + mCardHolder + ", " +mExpirationDate + "]";
		return output;
	}

}