/*
Tran, Dan
CS A170
*/
public class CreditCardDemo {

	public static void main(String[] args) 
	{
	CreditCard Credit1 = new CreditCard(CardNetwork.VISA, "Michael Paulding", 123456789, "12/2019", 123);
	CreditCard Credit2 = new CreditCard(CardNetwork.VISA, "Michael Paulding", 123456789, "12/2019", 123);
	System.out.println(Credit1);
	System.out.println(Credit2);
	System.out.println();
	System.out.println("Are the two cards the same?");
	System.out.println(Credit2.equals(Credit1));
	System.out.println();
	System.out.println("Changing Cardholder name....");
	Credit2.setCardHolder("William Huynh");
	System.out.println(Credit2);
	System.out.println();
	System.out.println("Are they the same now?");
	System.out.println(Credit2.equals(Credit1));
	
	}

}
