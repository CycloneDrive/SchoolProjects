/*
Tran, Dan
CS A170
*/

import java.awt.Color;

//add unimplemented method
public class Rectangle extends Shape2D
{
    //member variables
    private int mWidth;
    private int mHeight;
    //constrcutors
    public Rectangle( int x, int y, Color color,int width, int height)
    {
        mX= x;
        mY = y;
        mColor = color;
        mWidth = width;
        mHeight = height;
    }
    //setters and getters
    @Override
    public double calculateArea()
    {
        return (mWidth * mHeight * 1.0);
    }

    public int getWidth()
    {
        return mWidth;
    }

    public void setWidth(int width)
    {
        mWidth = width;
    }

    public int getHeight()
    {
        return mHeight;
    }

    public void setHeight(int height)
    {
        mHeight = height;
    }
    //equals and hash
    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + mHeight;
        result = prime * result + mWidth;
        return result;
    }
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (!super.equals(obj)) return false;
        if (getClass() != obj.getClass()) return false;
        Rectangle other = (Rectangle) obj;
        if (mHeight != other.mHeight) return false;
        if (mWidth != other.mWidth) return false;
        return true;
    }
    //toString
    @Override
    public String toString()
    {
        String output = "";
        //nested for loopt o got rhough rows and cols
        for (int i = 0; i < mHeight; i++)
        {
            for (int j = 0; j <mWidth; j++)
            {
               output+="*";
            }
            output+= "\n";
        }
        output+= "The area of this rectangle is " + calculateArea() + " square units." ;
        return output;
    }
}
