/*
Tran, Dan
CS A170
*/

import java.awt.Color;
import java.util.ArrayList;

public class ShapeDemo
{

    public static void main(String[] args)
    {
        // instantiate and add them to arraylist recatngle, triangle, and paralellogram
        ArrayList<Shape2D> shape2DList = new ArrayList<>();
        shape2DList.add(new Rectangle(0, 0,Color.BLACK, 5, 4));
        shape2DList.add(new Triangle(0,0,Color.DARK_GRAY,5,5));
        shape2DList.add(new Parallelogram(0,0,Color.yellow,10,40));

        for(Shape2D s: shape2DList)
            System.out.println(s+"\n");

    }

}
