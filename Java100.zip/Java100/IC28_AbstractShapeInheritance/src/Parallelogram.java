/*
Tran, Dan
CS A170
*/

import java.awt.Color;

public class Parallelogram extends Shape2D
{
    // fields
    private int mHeight;
    private int mPBase;
    //calculated area
    @Override
    public double calculateArea()
    {
        return (mHeight * mPBase * 1.0);
    }
    //constructor
    public Parallelogram(int x, int y, Color color, int height, int pBase)
    {
        mX = x;
        mY = y;
        mColor = color;
        mHeight = height;
        mPBase = pBase;
    }
    //setters and getters
    public int getHeight()
    {
        return mHeight;
    }
    public void setHeight(int height)
    {
        mHeight = height;
    }
    public int getPBase()
    {
        return mPBase;
    }
    public void setPBase(int pBase)
    {
        mPBase = pBase;
    }
    //equals and hash
    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + mHeight;
        result = prime * result + mPBase;
        return result;
    }
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (!super.equals(obj)) return false;
        if (getClass() != obj.getClass()) return false;
        Parallelogram other = (Parallelogram) obj;
        if (mHeight != other.mHeight) return false;
        if (mPBase != other.mPBase) return false;
        return true;
    }
    //tostring
    @Override
    public String toString()
    {
        String output = "";
        //nested for loopt o got rhough rows and cols
        for (int i = 0; i < mHeight; i++)
        {
        	for (int k = 0; k < i ; k++)
        	{
        		output+=" ";
        	}
            for (int j = 0; j <mPBase; j++)
            {
              output+="*";
            }
            output+="\n";

        }
        output+= "The area of this parallelogram is " + calculateArea() + " square units." ;
        return output;
    }




}
