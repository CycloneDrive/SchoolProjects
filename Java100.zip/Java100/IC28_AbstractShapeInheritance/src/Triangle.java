/*
Tran, Dan
CS A170
*/

import java.awt.Color;

public class Triangle extends Shape2D
{
    //fields
    private int mHeight;
    private int mTBase;
    //constructor
    public Triangle(int x, int y, Color color, int height, int tBase)
    {
        mX = x;
        mY = y;
        mColor = color;
        mHeight = height;
        mTBase = tBase;
    }
    //implemented methods
    @Override
    public double calculateArea()
    {
        return (mHeight * mTBase * 1/2 * 1.0);
    }
    //setters and getters
    public int getHeight()
    {
        return mHeight;
    }

    public void setHeight(int height)
    {
        mHeight = height;
    }

    public int getTBase()
    {
        return mTBase;
    }

    public void setTBase(int tBase)
    {
        mTBase = tBase;
    }
    //hash code and equals
    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + mHeight;
        result = prime * result + mTBase;
        return result;
    }
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (!super.equals(obj)) return false;
        if (getClass() != obj.getClass()) return false;
        Triangle other = (Triangle) obj;
        if (mHeight != other.mHeight) return false;
        if (mTBase != other.mTBase) return false;
        return true;
    }
    //to string **********
    @Override
    public String toString()
    {
        String output = "";
        //nested for loopt o got rhough rows and cols
        for (int i = 0; i < mHeight; i++)
        {
            for (int j = 0; j <= i; j++)
            {
               output+="*";
            }
            output+= "\n";
        }
        output+= "The area of this triangle is " + calculateArea() + " square units." ;
        return output;
    }

}
