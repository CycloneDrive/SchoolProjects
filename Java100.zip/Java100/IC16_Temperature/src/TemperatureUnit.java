/*
Tran, Dan
CS A170
*/
public enum TemperatureUnit {
CELSIUS,
FAHRENHEIT
}
