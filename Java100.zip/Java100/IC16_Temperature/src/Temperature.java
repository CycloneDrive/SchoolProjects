/*
Tran, Dan
CS A170
*/
import javax.print.attribute.standard.MediaSize.Other;

public class Temperature {
	// fields
	private double mDegrees;
	private TemperatureUnit mUnit;

	// constructors
	public Temperature(double degrees, TemperatureUnit unit) {
		mDegrees = degrees;
		mUnit = unit;
	}

	public Temperature() {
		mDegrees = 0.0;
		mUnit = TemperatureUnit.CELSIUS;
	}

	public Temperature(Temperature other) {
		mDegrees = other.mDegrees;
		mUnit = other.mUnit;
	}

	// getters setters
	public double getDegrees() {
		return mDegrees;
	}

	public void setDegrees(double degrees) {
		mDegrees = degrees;
	}

	public TemperatureUnit getUnit() {
		return mUnit;
	}

	public void setUnit(TemperatureUnit unit) {
		mUnit = unit;
	}

	// toString
	@Override
	public String toString() {
		return "Temperature [" + mDegrees + " degrees " + mUnit + "]";
	}

	// convertTo(TemperatureUnit otherUnit) - this method will convert a degree in
	// one unit to a degree in another (e.g. Fahrenheit to Celsius) and returns true
	// if a conversion was made, false otherwise (the only way a conversion is not
	// made is if the units are the same (e.g. Fahrenheit to Fahrenheit)
	public boolean convertTo(TemperatureUnit otherUnit) {
		boolean isConvereted= true;
		if (mUnit.equals(otherUnit)) {
			isConvereted = false;
			return isConvereted;
		}

		if (TemperatureUnit.CELSIUS == mUnit && TemperatureUnit.FAHRENHEIT == otherUnit) {
			mDegrees = (mDegrees * 1.8) + 32;
			mUnit = TemperatureUnit.FAHRENHEIT;
		}

		else if(TemperatureUnit.FAHRENHEIT == mUnit && TemperatureUnit.CELSIUS == otherUnit)
		{
			mDegrees = (mDegrees - 32) * 1.8;
			mUnit = TemperatureUnit.CELSIUS;
		}
		return isConvereted;
	}

	// inOtherUnit(TemperatureUnit otherUnit) - this method will return a new
	// Temperature object in the otherUnit, without changing the current object.
	public Temperature inOtherUnit(TemperatureUnit otherUnit) {
		Temperature temp = new Temperature();
		if (otherUnit.equals(TemperatureUnit.CELSIUS)) {
			temp.setDegrees((1.8 * this.mDegrees) + 32);
			temp.setUnit(TemperatureUnit.FAHRENHEIT);
		} else if (otherUnit.equals(TemperatureUnit.FAHRENHEIT)) {
			temp.setDegrees((this.mDegrees - 32) * 1.8);
			temp.setUnit(TemperatureUnit.CELSIUS);
		}
		return temp;
	}

	// equals
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(mDegrees);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((mUnit == null) ? 0 : mUnit.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (((Temperature) obj).getUnit().equals(this.getUnit())) {
			return ((Temperature) obj).getDegrees() == this.getDegrees();
		} else {
			if (((Temperature) obj).getUnit().equals(TemperatureUnit.CELSIUS)) {
				((Temperature) obj).convertTo(TemperatureUnit.FAHRENHEIT);
			} else {
				((Temperature) obj).convertTo(TemperatureUnit.FAHRENHEIT);
			}

			return ((Temperature) obj).getDegrees() == this.getDegrees();
		}
	}
}
