/*
Tran, Dan
CS A170
*/
import javax.print.attribute.standard.MediaSize.Other;

public class TemperatureDemo {

	public static void main(String[] args) {
		Temperature temp1 = new Temperature(129.2,TemperatureUnit.FAHRENHEIT);
		Temperature temp2 = new Temperature(54.0,TemperatureUnit.CELSIUS);
		Temperature temp3 = new Temperature(32.0, TemperatureUnit.FAHRENHEIT);
		Temperature default1 = new Temperature();
		Temperature copy = new Temperature(temp1);
		
		
		System.out.println(temp1 + "\n" + temp2 + "\n" + temp3 + "\n" + default1 + "\n" + copy + "\n");
		
		System.out.println("Checking if the copy is the same as the one it copied...");
		System.out.println(temp1.equals(copy));
		
		System.out.println("Checking if temp1 is the same as temp2...");
		System.out.println(temp1.equals(temp2));
		
		System.out.println("Checking if default1 is the same as temp3...");
		System.out.println(default1.equals(temp3));
		
		System.out.println("\nConverting the default to fahrenheit...");
		System.out.println(default1.convertTo(TemperatureUnit.FAHRENHEIT));
		System.out.println(default1);
		System.out.println("\nConverting it back to celcius...");
		System.out.println(default1.convertTo(TemperatureUnit.CELSIUS));
		System.out.println(default1);
	}

}
