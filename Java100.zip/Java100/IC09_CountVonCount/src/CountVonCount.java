/*
Tran, Dan
CS A170
March  2, 2018 
*
IC #09#
*/
import java.util.Scanner;

public class CountVonCount
{

    public static void main(String[] args)
    {
        int magicnumber;
        Scanner consoleScanner = new Scanner(System.in);
      
        System.out.println("Count von Count: What is the magic number of the day?");
        magicnumber = consoleScanner.nextInt();
        consoleScanner.close();
        // Loop through all numbers from 1 to the magic number
        // check for invalid input
        if (magicnumber<1)
            {
                // For error messages: Use System.err.println()
               System.err.println("I'm sorry, but the Count von Count only counts positive numbers!  Muhahahaha");
               // to exit code immdiately, use System.exit
               System.exit(0);
            }
       for (int i=1; i<magicnumber; i++)
            {
            System.out.print(i + ", ");
            }
            System.out.print(magicnumber + "\n");
            System.out.println(magicnumber + "! " + magicnumber + " is the magic number of the day. " + magicnumber + " dancing vegetables are here to celebrate with me!  I love dancing vegetables!");

    }

}
