/*
Tran, Dan
CS A170
February  14, 2018 
*
IC #04#
*/
import java.util.Scanner;

public class DateFormat {

	public static void main(String[] args) {
		String todaysDate;
		Scanner consoleScanner = new Scanner(System.in); 
		
		System.out.println("Please enter the date (format MM/DD/YYYY) and include the forward slashes:");
		todaysDate = consoleScanner.nextLine(); 
		
		String month = todaysDate.substring(0,2); 
		String day = todaysDate.substring(3,5);
		String year = todaysDate.substring(6);
		
		
		System.out.println("\nIn the European format, DD.MM.YYYY,this date is:\n" + day + "." + month + "." + year);
        consoleScanner.close();


	}

}
