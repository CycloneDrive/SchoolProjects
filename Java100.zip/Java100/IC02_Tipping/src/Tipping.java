import java.text.DecimalFormat;
import java.util.Scanner;

/*
Tran, Dan
CS A170
February  02, 2018 
*
IC #02#
*/

public class Tipping {

	public static void main(String[] args) {
	double bill, tip, taxamount, tipamount, total;
	
	Scanner consoleScanner = new Scanner (System.in);
	
	DecimalFormat twoDPs = new DecimalFormat("0.00"); 
	
	System.out.print("Please enter amount of resaurant bill $");
	bill = consoleScanner.nextDouble();
	System.out.print("Please enter the tip percentage (%)");
	tip = consoleScanner.nextDouble();
	taxamount = (bill * 0.08);
	System.out.println("\nThe total taxes are $" + twoDPs.format(taxamount));
	tipamount = ((tip/100) * (bill + taxamount));
	System.out.println("The tip amount is $" + twoDPs.format(tipamount));
	total = (tipamount + taxamount + bill);
	System.out.println("     ");
	System.out.println("The total amount to pay is $" + twoDPs.format(total));
    consoleScanner.close();

	}
}
