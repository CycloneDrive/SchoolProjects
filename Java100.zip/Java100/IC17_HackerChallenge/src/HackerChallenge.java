/*
Tran, Dan
CS A170
*/
import java.text.DecimalFormat;
import java.util.Scanner;

public class HackerChallenge {

	public static final int SIZE = 7;

	public static void main(String[] args) {
		// declare arrays and other variables
		double[] hoursSlept = new double[SIZE];
		// declare the days in the week (pre-known)
		String[] days = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
		// declare sum average;
		double sum = 0.0, average;
		int rec = 0, app = 0, notRec = 0;
		String overall, age;
		Scanner consoleScanner = new Scanner(System.in);
		DecimalFormat twoDps = new DecimalFormat("0.00");

		System.out.print("Please enter your age group: ");
		age = consoleScanner.nextLine().toUpperCase();

		switch (age) 
		{
		
			case "NEWBORNS": 
			{
				for (int i = 0; i < hoursSlept.length; i++) 
				{
					System.out.print("Enter number of hours on " + days[i] + ": ");
					hoursSlept[i] = consoleScanner.nextDouble();
					sum += hoursSlept[i];
					if (hoursSlept[i] <= 17 && hoursSlept[i] >= 14) 
					{
						rec++;
					} else if (hoursSlept[i] < 12 || hoursSlept[i] > 19) 
					{
						notRec++;
					} else {
						app++;
					}
				}
				 consoleScanner.close();
			     average = sum / hoursSlept.length;
			     System.out.println("\nTotal number of hours slept last week   : " + twoDps.format(sum));
			     System.out.println("Average number of hours slept per night : " + twoDps.format(average));
			     System.out.println("\nAccording to the NSF, last week you slept:\n" + rec + " nights of \"recommended\" sleep.\n"
			                + app + " nights of \"appropriate\" sleep.\n" + notRec + " nights of \"not recommended\" sleep.");
			     if (average<= 17 && average >=14)
			       {
			    	overall = "\"Recommended\"";    
			       }
			       else if (average < 12 || average > 19)
			       {
			    	   overall = "\"Not Recommended\"";
			    			   
			       }
			       else
			       {
			    	   overall = "\"May Be Appropriate\"";
			       }
			        System.out.println("Overall, your sleep health (on average) is " + overall);
			}
				break; 
				
			case "INFANTS":
				for (int i = 0; i <hoursSlept.length; i++)
				{
					System.out.print("Enter number of hours on " + days[i] + ": ");
					hoursSlept[i] = consoleScanner.nextDouble();
					sum += hoursSlept[i];
					if (hoursSlept[i] <= 17 && hoursSlept[i] >= 12) 
					{
						rec++;
					} 
					else if (hoursSlept[i] < 10 || hoursSlept[i] > 18) 
					{
						notRec++;
					} 
					else {
						app++;
					}
				}
				 consoleScanner.close();
			     average = sum / hoursSlept.length;
			     System.out.println("\nTotal number of hours slept last week   : " + twoDps.format(sum));
			     System.out.println("Average number of hours slept per night : " + twoDps.format(average));
			     System.out.println("\nAccording to the NSF, last week you slept:\n" + rec + " nights of \"recommended\" sleep.\n"
			                + app + " nights of \"appropriate\" sleep.\n" + notRec + " nights of \"not recommended\" sleep.");
			     if (average<= 17 && average >=12)
			       {
			    	overall = "\"Recommended\"";    
			       }
			       else if (average < 10 || average > 18)
			       {
			    	   overall = "\"Not Recommended\"";
			    			   
			       }
			       else
			       {
			    	   overall = "\"May Be Appropriate\"";
			       }
			        System.out.println("Overall, your sleep health (on average) is " + overall);
				break;
				
			case "TODDLERS":
				for (int i = 0; i <hoursSlept.length; i++)
				{
					System.out.print("Enter number of hours on " + days[i] + ": ");
					hoursSlept[i] = consoleScanner.nextDouble();
					sum += hoursSlept[i];
					if (hoursSlept[i] <= 14 && hoursSlept[i] >= 11) 
					{
						rec++;
					} 
					else if (hoursSlept[i] < 9 || hoursSlept[i] > 16) 
					{
						notRec++;
					} 
					else 
					{
						app++;
					}
				}
				 consoleScanner.close();
			     average = sum / hoursSlept.length;
			     System.out.println("\nTotal number of hours slept last week   : " + twoDps.format(sum));
			     System.out.println("Average number of hours slept per night : " + twoDps.format(average));
			     System.out.println("\nAccording to the NSF, last week you slept:\n" + rec + " nights of \"recommended\" sleep.\n"
			                + app + " nights of \"appropriate\" sleep.\n" + notRec + " nights of \"not recommended\" sleep.");
			     if (average<= 14 && average >=11)
			       {
			    	overall = "\"Recommended\"";    
			       }
			       else if (average < 9 || average > 16)
			       {
			    	   overall = "\"Not Recommended\"";
			    			   
			       }
			       else
			       {
			    	   overall = "\"May Be Appropriate\"";
			       }
			        System.out.println("Overall, your sleep health (on average) is " + overall);
				break;
				
			case "PRESCHOOLERS":
				for (int i = 0; i <hoursSlept.length; i++)
				{
					System.out.print("Enter number of hours on " + days[i] + ": ");
					hoursSlept[i] = consoleScanner.nextDouble();
					sum += hoursSlept[i];
					if (hoursSlept[i] <= 13 && hoursSlept[i] >= 10) 
					{
						rec++;
					} 
					else if (hoursSlept[i] < 8 || hoursSlept[i] > 14) 
					{
						notRec++;
					} 
					else 
					{
						app++;
					}
				}
				consoleScanner.close();
			     average = sum / hoursSlept.length;
			     System.out.println("\nTotal number of hours slept last week   : " + twoDps.format(sum));
			     System.out.println("Average number of hours slept per night : " + twoDps.format(average));
			     System.out.println("\nAccording to the NSF, last week you slept:\n" + rec + " nights of \"recommended\" sleep.\n"
			                + app + " nights of \"appropriate\" sleep.\n" + notRec + " nights of \"not recommended\" sleep.");
			     if (average<= 13 && average >=10)
			       {
			    	overall = "\"Recommended\"";    
			       }
			       else if (average < 8 || average > 14)
			       {
			    	   overall = "\"Not Recommended\"";
			    			   
			       }
			       else
			       {
			    	   overall = "\"May Be Appropriate\"";
			       }
			        System.out.println("Overall, your sleep health (on average) is " + overall);
				break;
				
			case "SCHOOL-AGED CHILDREN":
				for (int i = 0; i <hoursSlept.length; i++)
				{
					System.out.print("Enter number of hours on " + days[i] + ": ");
					hoursSlept[i] = consoleScanner.nextDouble();
					sum += hoursSlept[i];
					if (hoursSlept[i] <= 11 && hoursSlept[i] >= 9) 
					{
						rec++;
					} 
					else if (hoursSlept[i] < 7 || hoursSlept[i] > 12) 
					{
						notRec++;
					} 
					else 
					{
						app++;
					}
				}
				consoleScanner.close();
			     average = sum / hoursSlept.length;
			     System.out.println("\nTotal number of hours slept last week   : " + twoDps.format(sum));
			     System.out.println("Average number of hours slept per night : " + twoDps.format(average));
			     System.out.println("\nAccording to the NSF, last week you slept:\n" + rec + " nights of \"recommended\" sleep.\n"
			                + app + " nights of \"appropriate\" sleep.\n" + notRec + " nights of \"not recommended\" sleep.");
			     if (average<= 11 && average >=9)
			       {
			    	overall = "\"Recommended\"";    
			       }
			       else if (average < 7 || average > 12)
			       {
			    	   overall = "\"Not Recommended\"";
			    			   
			       }
			       else
			       {
			    	   overall = "\"May Be Appropriate\"";
			       }
			        System.out.println("Overall, your sleep health (on average) is " + overall);
				break;
				
			case "TEENAGERS":
				for (int i = 0; i <hoursSlept.length; i++)
				{
					System.out.print("Enter number of hours on " + days[i] + ": ");
					hoursSlept[i] = consoleScanner.nextDouble();
					sum += hoursSlept[i];
					if (hoursSlept[i] <= 10 && hoursSlept[i] >= 8) 
					{
						rec++;
					} 
					else if (hoursSlept[i] < 7 || hoursSlept[i] > 11) 
					{
						notRec++;
					} 
					else 
					{
						app++;
					}
				}
				consoleScanner.close();
			     average = sum / hoursSlept.length;
			     System.out.println("\nTotal number of hours slept last week   : " + twoDps.format(sum));
			     System.out.println("Average number of hours slept per night : " + twoDps.format(average));
			     System.out.println("\nAccording to the NSF, last week you slept:\n" + rec + " nights of \"recommended\" sleep.\n"
			                + app + " nights of \"appropriate\" sleep.\n" + notRec + " nights of \"not recommended\" sleep.");
			     if (average<= 10 && average >=8)
			       {
			    	overall = "\"Recommended\"";    
			       }
			       else if (average < 7 || average > 11)
			       {
			    	   overall = "\"Not Recommended\"";
			    			   
			       }
			       else
			       {
			    	   overall = "\"May Be Appropriate\"";
			       }
			        System.out.println("Overall, your sleep health (on average) is " + overall);
				break;
				
			case "YOUNG ADULTS":
				for (int i = 0; i <hoursSlept.length; i++)
				{
					System.out.print("Enter number of hours on " + days[i] + ": ");
					hoursSlept[i] = consoleScanner.nextDouble();
					sum += hoursSlept[i];
					if (hoursSlept[i] <= 9 && hoursSlept[i] >= 7) 
					{
						rec++;
					} 
					else if (hoursSlept[i] < 6 || hoursSlept[i] > 11) 
					{
						notRec++;
					} 
					else 
					{
						app++;
					}
				}
				consoleScanner.close();
			     average = sum / hoursSlept.length;
			     System.out.println("\nTotal number of hours slept last week   : " + twoDps.format(sum));
			     System.out.println("Average number of hours slept per night : " + twoDps.format(average));
			     System.out.println("\nAccording to the NSF, last week you slept:\n" + rec + " nights of \"recommended\" sleep.\n"
			                + app + " nights of \"appropriate\" sleep.\n" + notRec + " nights of \"not recommended\" sleep.");
			     if (average<= 9 && average >=7)
			       {
			    	overall = "\"Recommended\"";    
			       }
			       else if (average < 6 || average > 11)
			       {
			    	   overall = "\"Not Recommended\"";
			    			   
			       }
			       else
			       {
			    	   overall = "\"May Be Appropriate\"";
			       }
			        System.out.println("Overall, your sleep health (on average) is " + overall);
				break;
				
			case "ADULTS":
				for (int i = 0; i <hoursSlept.length; i++)
				{
					System.out.print("Enter number of hours on " + days[i] + ": ");
					hoursSlept[i] = consoleScanner.nextDouble();
					sum += hoursSlept[i];
					if (hoursSlept[i] <= 9 && hoursSlept[i] >= 7) 
					{
						rec++;
					} 
					else if (hoursSlept[i] < 6 || hoursSlept[i] > 10) 
					{
						notRec++;
					} 
					else 
					{
						app++;
					}
				}
				consoleScanner.close();
			     average = sum / hoursSlept.length;
			     System.out.println("\nTotal number of hours slept last week   : " + twoDps.format(sum));
			     System.out.println("Average number of hours slept per night : " + twoDps.format(average));
			     System.out.println("\nAccording to the NSF, last week you slept:\n" + rec + " nights of \"recommended\" sleep.\n"
			                + app + " nights of \"appropriate\" sleep.\n" + notRec + " nights of \"not recommended\" sleep.");
			     if (average<= 9 && average >=7)
			       {
			    	overall = "\"Recommended\"";    
			       }
			       else if (average < 6 || average > 10)
			       {
			    	   overall = "\"Not Recommended\"";
			    			   
			       }
			       else
			       {
			    	   overall = "\"May Be Appropriate\"";
			       }
			        System.out.println("Overall, your sleep health (on average) is " + overall);
				break;
				
			case "OLDER ADULTS":
				for (int i = 0; i <hoursSlept.length; i++)
				{
					System.out.print("Enter number of hours on " + days[i] + ": ");
					hoursSlept[i] = consoleScanner.nextDouble();
					sum += hoursSlept[i];
					if (hoursSlept[i] <= 8 && hoursSlept[i] >= 7) 
					{
						rec++;
					} 
					else if (hoursSlept[i] < 5 || hoursSlept[i] > 9) 
					{
						notRec++;
					} 
					else 
					{
						app++;
					}
				}
				consoleScanner.close();
			     average = sum / hoursSlept.length;
			     System.out.println("\nTotal number of hours slept last week   : " + twoDps.format(sum));
			     System.out.println("Average number of hours slept per night : " + twoDps.format(average));
			     System.out.println("\nAccording to the NSF, last week you slept:\n" + rec + " nights of \"recommended\" sleep.\n"
			                + app + " nights of \"appropriate\" sleep.\n" + notRec + " nights of \"not recommended\" sleep.");
			     if (average<= 8 && average >=7)
			       {
			    	overall = "\"Recommended\"";    
			       }
			       else if (average < 5 || average > 9)
			       {
			    	   overall = "\"Not Recommended\"";
			    			   
			       }
			       else
			       {
			    	   overall = "\"May Be Appropriate\"";
			       }
			        System.out.println("Overall, your sleep health (on average) is " + overall);
				break;
				
			default:
				System.out.println("Please choose one of the following age groups and try again: Newborns, Toddlers, Preschoolers, School-Aged Children, Teenagers, Young Adults, Adults, or Older Adults");
			}
	}
}