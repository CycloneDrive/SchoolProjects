/*
Tran, Dan
CS A170
*/
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class FrontToBack
{

    public static void main(String[] args)
    {
        String line;
        String[] words;
        
        try
        {
            //Read file with Scanner
            Scanner fileScanner = new Scanner(new File("Input.txt"));
            //to write a file, use PrintWriter
            PrintWriter fileWriter = new PrintWriter("Output.txt");
            // do while executes at least once and whiles don't 
            //while loop for files since they might be empty
            //As long as the file scanner has a line to read
            while (fileScanner.hasNextLine())
            {
                // read one line from the file:
                line = fileScanner.nextLine();
                //for testing purposes: print the line
                //System.out.println(line);
              
                //split the line into words (whereever thereis a "")
                words = line.split(" ");
                //words = {"watch", "this", "rock}
                //Storer words[0] temporarily
                String temp = words[0]; //"watch"
                words[0] = words[words.length-1];
                words[words.length-1] = temp;
                //let's print out the new array
                for (int i = 0; i < words.length; i++)
                {
                    fileWriter.print(words[i] + " ");
                }
                fileWriter.println();
            }
            
            //after loop, close the file scanner
            fileScanner.close();
            fileWriter.close();
        }
        
        catch (IOException e)
        {
            System.out.println("File not found");
        }
    }

}
