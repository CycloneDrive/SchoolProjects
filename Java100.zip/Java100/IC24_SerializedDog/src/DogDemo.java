/*
Tran, Dan
CS A170
*/
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class DogDemo
{

    @SuppressWarnings("unchecked")
    public static void main(String[] args)
    {
        String name, breed;
        double age;
        Scanner consoleScanner = new Scanner(System.in);
        // Let's make an array list to store all the dogs
        ArrayList<Dog> dogsList = new ArrayList<>();
        // STEP 1: Reading binary file int the array list
        File binaryFile = new File("Dogs.dat");
        // CHECK TO SEE IF THE BINARY FILE EXISTS
        // Open the binary file for reading objects (Dogs) if it EXISTS
        System.out.println("Previously saved Dogs from binary file: ");
        if (binaryFile.exists())
        {
            try
            {
                ObjectInputStream fileReader = new ObjectInputStream(new FileInputStream(binaryFile));
                // Load the array list (dogsList) from the binary file
                dogsList = (ArrayList<Dog>) fileReader.readObject();
                // All dogs have been loaded
                fileReader.close();
                // print out the existing dogs:
                for (Dog theDog : dogsList)
                    System.out.println(theDog);
            }
            catch (IOException | ClassNotFoundException e)
            {
                System.out.println(e.getMessage());
                ;
            }
        }
        else
            System.out.println("[None, please enter new dog data]");

        // STEP 2: Prompt user to inpu new dogs (done!)
        // As long as the name not equal to "-1", keep looping
        do
        {
            // prompt user for name, breed and age
            System.out.println("********************************************");
            System.out.print("Please enter dog's name or -1 to exit: ");
            name = consoleScanner.nextLine();

            // Check name for -1
            if (name.equals("-1")) break;

            System.out.print("Please enter dog's breed: ");
            breed = consoleScanner.nextLine();

            System.out.print("Please enter dog's age: ");
            age = consoleScanner.nextDouble();

            // After age, clear console scanner to get rid of \n
            consoleScanner.nextLine();

            // Create a new Dog object
            // Add the dog to the ArrayList
            dogsList.add(new Dog(name, breed, age));

        }
        while (!name.equals("-1"));

        // After loop, close console scanner
        consoleScanner.close();
        
        //STEP 3: wriring the binary file
        try
        {
            ObjectOutputStream fileWriter = new ObjectOutputStream(new FileOutputStream(binaryFile));
            //Write the dogs list to the binary file
            fileWriter.writeObject(dogsList);
            //close filewriter
            fileWriter.close();
        }
        catch (IOException e)
        {
            System.out.println(e.getMessage());;
        }

    }

}
