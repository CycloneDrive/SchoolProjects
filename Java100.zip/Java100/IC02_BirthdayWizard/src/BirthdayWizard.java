import java.util.Scanner;

/*
Tran, Dan 
CS A170
February  02, 2018 
*
IC #02
*/

public class BirthdayWizard {

	public static void main(String[] args) {
		int birthyear, futureage, sum, newyear1; 
		
		
		
		Scanner consoleScanner = new Scanner (System.in);
		
	    System.out.println("Please enter your birth year...");
	    birthyear = consoleScanner.nextInt();
	    sum = (2018 - birthyear);
	    System.out.println("You are " + sum + " years old. \n");
	    System.out.println("Now please enter your future age... " );
	    futureage = consoleScanner.nextInt();
	    newyear1 = (birthyear + futureage);
	    System.out.print("You will be " + futureage + " in the year " + newyear1);
        consoleScanner.close();

	}
	

}
