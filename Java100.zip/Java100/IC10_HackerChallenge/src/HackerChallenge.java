/*
Tran, Dan
CS A170
March  14, 2018 
*
IC #10#
*/
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JApplet;

public class HackerChallenge extends JApplet {
	public void init() {
		setSize(750, 750);
	}

	public void paint(Graphics canvas) {
		int x = 25, y = 5, w = 70, h = 70;
		for (int j = 1; j <= 10; j++) {
			for (int i = 1; i <= 10; i++) {
				if (i % 2 == 0) {
					canvas.setColor(Color.BLUE);
				} else {
					canvas.setColor(Color.ORANGE);
				}
				canvas.fillOval(x, y, w, h);
				canvas.setColor(Color.BLACK);
				canvas.fillOval(x + 20, y + 15, 5, 10); // eye1
				canvas.fillOval(x + 45, y + 15, 5, 10); // eye 2
				canvas.fillOval(x + 32, y + 30, 5, 5); // nose
				canvas.drawArc(x + 15, y + 40, 40, 20, 180, 180); // smile
				x += 70;
			}
			y += 70;
			x=25;
		}
	}

}