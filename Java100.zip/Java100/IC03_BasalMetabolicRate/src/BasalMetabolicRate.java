/*
Tran, Dan
CS A170
February  14, 2018 
*
IC #03#
*/

import java.text.DecimalFormat;
import java.util.Scanner;

public class BasalMetabolicRate
{

    public static void main(String[] args)
    {
       // Step1) Declare any needed variables
        double weight, height, age, fcal, mcal, fchoc, mchoc;
       // ctrl + shift + o 
        Scanner consoleScanner = new Scanner(System.in);
        
        DecimalFormat noDPs = new DecimalFormat("0");
        DecimalFormat oneDPs = new DecimalFormat("0.0");

  
       // Step 2) Prompt the user for input
        System.out.print("Please enter your weight (lb): ");
        weight = consoleScanner.nextDouble();
        // ctrl + alt + down
        System.out.print("Please enter your height (in): ");
        height = consoleScanner.nextDouble();
        System.out.print("Please enter your age: ");
        age = consoleScanner.nextDouble();
        // Step 3) Perform Calc
        fcal= 655 + (4.35 * weight) + (4.7 * height) - (4.7 * age);
        mcal= 66 + (6.23 * weight) + (12.7 * height) - (6.8 * age);
        
        System.out.println("\nBMR (female): " + noDPs.format(fcal) + " calories");
        System.out.println("BMR (male)  : " + noDPs.format(mcal) + " calories");
        // divide calories by 230
        fchoc = fcal / 230;
        mchoc = mcal / 230;
        System.out.println("\nIf you are a female, you need to consume " + oneDPs.format(fchoc) + " chocolate bars to maintain weight.");
        System.out.println("If you are a male, you need to consume " + oneDPs.format(mchoc) + " chocolate bars to maintain weight.");
        // Remember to close your scanner!
        consoleScanner.close();

    }

}
