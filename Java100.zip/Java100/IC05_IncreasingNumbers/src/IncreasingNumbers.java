/*
Tran, Dan
CS A170
February  23, 2018 
*
IC #05#
*/
import java.util.Scanner;

public class IncreasingNumbers
{

    public static void main(String[] args)
    {   int x,y,z; 
        // TODO Auto-generated method stub
        Scanner consoleScanner = new Scanner(System.in);
        System.out.print("Please enter a non-negative number: ");
        x = consoleScanner.nextInt();
        System.out.print("Please enter a non-negative number: ");
        y = consoleScanner.nextInt();
        System.out.print("Please enter a non-negative number: ");
        z = consoleScanner.nextInt();
        consoleScanner.close();
        System.out.println("\nThe numbers you entered in increasing order are:");
        
        if (x<=y&&y<=z)
        {
            System.out.println(x+"\n"+y+"\n"+z);
        }
        else if(x<=z&&z<=y)
        {
        	System.out.println(x+"\n"+z+"\n"+y);
        }
        else if(y<=x&&x<=z)
        {
        	System.out.println(y+"\n"+x+"\n"+z);
        }
        else if(y<=z&&z<=x)
        {
        	System.out.println(y+"\n"+z+"\n"+x);
        }
        else if(z<=x&&x<=y)
        {
        	System.out.println(z+"\n"+x+"\n"+y);
        }
        else
        {
        	System.out.println(z+"\n"+y+"\n"+x);
        }

    }

}
