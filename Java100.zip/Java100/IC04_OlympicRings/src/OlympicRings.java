/*
Tran, Dan
CS A170
February  14, 2018 
*
IC #04#
*/

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JApplet;

//Step 1) we have to tell java we're creating an applet (instead of console)
public class OlympicRings extends JApplet
{

    public void init()
    {
     //set the size of canvas to 300 by 300 
        setSize(300, 300);
        
    }
    
    public void paint(Graphics canvas)
    {
           Graphics2D canvas2D = (Graphics2D) canvas;
           canvas2D.setStroke(new BasicStroke(5));
           // All 2D graphics are drawn here
           // blue (8,123,194 ; orange(251,177,50);green(28,139,60);red(237,51,78)
        canvas.setColor(new Color(8,123,194));
        canvas.drawOval(10,10,85,85);
        canvas.setColor(new Color(251,177,50));
        canvas.drawOval(60, 60, 85,85);
        canvas.setColor(Color.BLACK);
        canvas.drawOval(110,10,85,85);
        canvas.setColor(new Color(28,139,60));
        canvas.drawOval(160, 60, 85, 85);
        canvas.setColor(new Color(237,51,78));
        canvas.drawOval(210, 10, 85, 85);



    }
}
