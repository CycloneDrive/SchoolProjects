/*
Tran, Dan
CS A170
*/

public class Car extends Vehicle
{
    // Member varaibles
    private int mNumberofDoors;
    //constructor
    // with abstract class, have to add the fields manually
    public Car(int numberofDoors, int year, String manufacturer)
    {
        mNumberofDoors = numberofDoors;
        mManufacturer = manufacturer;
        mYear=year;
    }
    //getters and setters
    public int getNumberofDoors()
    {
        return mNumberofDoors;
    }
    public void setNumberofDoors(int numberofDoors)
    {
        mNumberofDoors = numberofDoors;
    }
    //equals and hashcode
    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + mNumberofDoors;
        return result;
    }
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (!super.equals(obj)) return false;
        if (getClass() != obj.getClass()) return false;
        Car other = (Car) obj;
        if (mNumberofDoors != other.mNumberofDoors) return false;
        return true;
    }
    //toString
    @Override
    public String toString()
    {
        return "Car [" + mManufacturer + ", " + mYear + ", " + mNumberofDoors + " doors]";
    }
    
    
    
}
