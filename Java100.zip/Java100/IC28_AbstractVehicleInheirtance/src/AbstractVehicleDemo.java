/*
Tran, Dan
CS A170
*/
import java.util.ArrayList;

public class AbstractVehicleDemo
{
    public static void main(String[] args)
    {
        // let's make two (car and boat)
        //Car subaru = new Car(4, 2019, "Subaru STI Hatch");
        //Boat titanic = new Boat(137, 1912, "Titanic Cruise Lines");
        
        //Let's add them to an array list
        ArrayList<Vehicle> vehiclesList = new ArrayList<>();
        vehiclesList.add(new Car(4, 2019, "Subaru STI Hatch"));
        vehiclesList.add(new Boat(137, 1912, "Titanic Cruise Lines"));
        vehiclesList.add(new Car(2, 2020, "Mercedes-Benz C250 "));
        vehiclesList.add(new Boat(4, 2000, "Sea Ray 185 Sport"));
        //Loop through the array list and print em out
        for (Vehicle v:vehiclesList)
            System.out.println(v);
    }

}
