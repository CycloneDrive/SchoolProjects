/*
Tran, Dan
CS A170
*/

public class Boat extends Vehicle
{
    //member variables
    private int mNumberofCabins;
    //constructor
    //with abstract class you ahve to enter parent calss fields automatically
    public Boat(int numberofCabins,int year, String manufacturer)
    {
        mYear = year;
        mNumberofCabins = numberofCabins;
        mManufacturer = manufacturer;
    }
    //setters and getters
    public int getNumberofCabins()
    {
        return mNumberofCabins;
    }
    public void setNumberofCabins(int numberofCabins)
    {
        mNumberofCabins = numberofCabins;
    }
    //equals and hashcode
    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + mNumberofCabins;
        return result;
    }
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (!super.equals(obj)) return false;
        if (getClass() != obj.getClass()) return false;
        Boat other = (Boat) obj;
        if (mNumberofCabins != other.mNumberofCabins) return false;
        return true;
    }
    //toString
    @Override
    public String toString()
    {
        return "Boat [" + mManufacturer + ", " + mYear + ", " + mNumberofCabins
                + " cabins]";
    }
    
}
