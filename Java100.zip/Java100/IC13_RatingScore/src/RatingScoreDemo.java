/*
Tran, Dan
CS A170
*/
public class RatingScoreDemo {

	public static void main(String[] args) {
		//Instantiate (create 2 new object ((Rating))
		//Scanner consoleScanner = new Scanner(System.in);
		Rating lotrtfotr = new Rating("Lord of the Rings: The Fellowship of the Ring", 4.5, 5.0, "First of the trilogy");
		Rating lotrttt = new Rating("Lord of the Rings: The Two Towers", 4.6, 5.0, "Second of the trilogy");
		System.out.println(lotrtfotr);
		System.out.println(lotrttt);
		
		System.out.println("\nUpdating scores");
		lotrtfotr.setScore(4.5);
		lotrttt.setScore(4.7);
		System.out.println(lotrtfotr);
		System.out.println(lotrttt);
		
		System.out.println("\nSetting max scores");
		lotrtfotr.setMaxScore(5.0);
		lotrttt.setMaxScore(5.0);
		System.out.println(lotrtfotr);
		System.out.println(lotrttt);
	
		System.out.println("\nGetting new movies");
		lotrtfotr.setDescription("Dredd");
		lotrttt.setDescription("Blade Runner 2049");
		lotrtfotr.setComments("Join the judge as he delievers justice");
		lotrttt.setComments("Welcome to the future");
		System.out.println(lotrtfotr);
		System.out.println(lotrttt);
		
		System.out.println("\nAre the two ratings the same?");
		System.out.println(lotrtfotr.equals(lotrttt));
		
		
	
	}

}
