/*
Tran, Dan
CS A170
*/
public class Rating {
	private String mComments;
	private String mDescription;
	private double mMaxscore;
	private double mScore;

	public Rating(String description, double mScore, double mMaxscore, String comments) {
		mComments = comments;
		mDescription = description;
		mMaxscore = 5.0;
		mScore = 0.0;
	}

	// accessors aka getter - provides read access to a field in a database.
	// Allows outside world to access data, is public
	public String getComments() {
		// retrieve comment from database
		return mComments;
	}

	public String getDescription() {
		return mDescription;
	}

	public double getMaxScore() {
		return mMaxscore;
	}

	public double getScore() {
		return mScore;
	}

	// mutator (setters)- allows write access to a field in a data base. outside
	// world modifies data
	public void setComments(String comments) 
	{
		mComments = comments;
	}

	public void setDescription(String description) 
	{
		mDescription = description;
	}

	public void setMaxScore(double newMaxscore) 
	{
		mMaxscore = newMaxscore;
	}

	public void setScore(double newScore) 
	{
		mScore = newScore;
	}

	public String toString() 
	{
		String output = "Rating [" + mDescription + " , " + mScore + " , " +  mMaxscore + " , " + mComments + ".]";
		return output;
	}
	public boolean equals(Rating other)
	{
		if (mScore==(other.mScore))
			return true;
		else
			return false;
	}
}