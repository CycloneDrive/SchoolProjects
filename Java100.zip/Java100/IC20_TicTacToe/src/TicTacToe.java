/*
Tran, Dan
CS A170
*/
import java.util.Scanner;

public class TicTacToe
{
    public static final int ROWS = 3;
    public static final int COLS = 3;
    
    public static void main(String[] args)
    {
        int moves = 0,row,col;
        Scanner consoleScanner= new Scanner(System.in);
        //in main declare array
     char[][] board =    
         {
           {'*','*','*'},
           {'*','*','*'},
           {'*','*','*'}           
         };
     // at the start of the game print the board:
     System.out.println("Welcome to Tic-Tac-Toe!");
         do
         {
             printBoard(board);
             System.out.print("Please enter row: ");
             row = consoleScanner.nextInt() - 1;
             System.out.print("Please enter col: ");
             col = consoleScanner.nextInt() - 1;
             //put either an x or an o in the board
             if (board[row][col]=='*')
             {
	             if (moves % 2 == 0)
	                 board[row][col] = 'X';
	             else
	                 board[row][col] = 'O';
	             moves++;
             }
             else
             {
            	 System.out.println("Invalid input, please try again.\n");
             }
             //keep playing the game as long as the game is not won or moves <9
         }while (moves < 9 && !gameisWon(board));
         //print the board after game is over
         printBoard(board);
         //print either player x has won or player o has won, or its a tie
         if(gameisWon(board)==true)
        	 System.out.println((moves%2==0?"Congrats to the winner O!":"Congrats to the winner X!"));
         else
        	 System.out.println("It's a tie!");	 
        
         //x= odd move o == even
    }
    
    // create method to print board (w/ chrome)
    public static void printBoard(char[][] anyBoard)
    {
        for (int i = 0; i < ROWS; i++)
        {   //#1
            System.out.println("-------------");
            for (int j = 0; j < COLS;j++)
            {//#2
                System.out.print("| " + anyBoard[i][j]+ " ");
                
            }
            //#3
            System.out.println("|");
        }
        //#4
        System.out.println("-------------");
    }
    //Make a method to determine if the game is won
    public static boolean gameisWon(char[][] anyBoard)
    {
        //row 0
        if (anyBoard[0][0] == anyBoard[0][1] && anyBoard[0][1] == anyBoard[0][2] && anyBoard[0][0] != '*')
            return true;
        //TODO: finish the other 7 ways
        //row 1
        else if (anyBoard[1][0] == anyBoard[1][1] && anyBoard[1][1] == anyBoard[1][2] && anyBoard[1][0] != '*')
            return true;
        //row 2
        else if (anyBoard[2][0] == anyBoard[2][1] && anyBoard[2][1] == anyBoard[2][2] && anyBoard[2][0] != '*')
            return true;
        //col 0
        else if (anyBoard[0][0] == anyBoard[1][0] && anyBoard[1][0] == anyBoard[2][0] && anyBoard[0][0] != '*')
            return true;
        //col 1
        else if (anyBoard[0][1] == anyBoard[1][1] && anyBoard[1][1] == anyBoard[2][1] && anyBoard[0][1] != '*')
            return true;
        //col 2
        else if (anyBoard[0][2] == anyBoard[1][2] && anyBoard[1][2] == anyBoard[2][2] && anyBoard[0][2] != '*')
            return true;
        //diagonal 1
        else if (anyBoard[0][0] == anyBoard[1][1] && anyBoard[1][1] == anyBoard[2][2] && anyBoard[0][0] != '*')
            return true;
        //diagonal 2 
        else if (anyBoard[0][2] == anyBoard[1][1] && anyBoard[1][1] == anyBoard[2][0] && anyBoard[0][2] != '*')
            return true;
        else
            return false;
    }

}
