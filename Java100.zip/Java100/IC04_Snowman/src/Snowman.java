
/*
Tran, Dan
CS A170
February  14, 2018 
*
IC #04#
*/
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JApplet;


public class Snowman extends JApplet
{
	 public void init()
	    {
		 setSize (300, 300);
		 
	    }
	 
		 public void paint(Graphics canvas)
		 {
			 	Graphics2D canvas2D = (Graphics2D) canvas;
			 	canvas2D.setStroke(new BasicStroke(5));
			 	
			 	canvas.setColor(Color.BLACK);
			 	canvas.drawOval(108,175,100,100);
			 	canvas.drawOval(120,100, 75, 75);
			 	canvas.drawOval(132,50, 50, 50);
			 	canvas.fillOval(145, 65, 10, 10);
			 	canvas.fillOval(160, 65, 10, 10);
			 	canvas.drawArc(145,65,25,25,180,180);
			 	
			 
		 }
}