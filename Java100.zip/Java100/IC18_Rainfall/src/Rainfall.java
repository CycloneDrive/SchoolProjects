package edu.orangecoastcollege.cs170.whuynh6.ic18;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Scanner;

public class Rainfall
{
    private static final int SIZE = 12;
    
    public static void main(String[] args)
    {
        
        Scanner consoleScanner = new Scanner(System.in);
        double sum = 0.0, average, largest, smallest;
        DecimalFormat twoDps = new DecimalFormat("0.00");
        String[] months = { "January", "February", "March", "April", "May", "June", "July", "August", "September",
                "October", "November", "December" };
        double[] rainfall = new double[SIZE];
        // Parallel Arrays - two or more arrays, same size, used together to
        // solve a problem
        for (int i = 0; i < rainfall.length; i++)
        {
            System.out.print("Enter rainfall amount (in inches) for " + months[i] + " >> ");
            rainfall[i] = consoleScanner.nextDouble();
            // check for negatices
            if (rainfall[i] < 0)
            {
                System.out.println("Rainfall must be at least 0.0 inches.");
                i--;
                continue;// starts loop again with different value of i
            }
                sum += rainfall[i];
        }
        
        consoleScanner.close();
        average = sum / rainfall.length;
        Arrays.sort(rainfall);
        largest = rainfall[rainfall.length - 1];
        smallest = rainfall[0];

        System.out.println("\nTotal Rainfall for the Year (in inches): " + twoDps.format(sum));
        System.out.println("Average rainfall for the Year (in inches): " + twoDps.format(average));
        System.out.println("Minimum Monthly Rainfall (in inches): " + twoDps.format(smallest));
        System.out.println("Maximum Monthly Rainfall (in inches): " + twoDps.format(largest));
    }

}
