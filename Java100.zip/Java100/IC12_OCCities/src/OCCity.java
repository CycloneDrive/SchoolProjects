/*
Tran, Dan
CS A170
March  26, 2018 
*
IC #10#
*/

public enum OCCity
{
    // list all 34 cities within Orange County:
    ALISO_VIEJO, 
    ANAHEIM, 
    BREA,
    BUENA_PARK, 
    COSTA_MESA, 
    CYPRESS, 
    DANA_POINT,
    FOUNTAIN_VALLEY, 
    FULLERTON,
    GARDEN_GROVE,
    HUNINGTON_BEACH,
    IRVINE,
    LA_HABRA,
    LA_PALMA,
    LAGUNA_BEACH,
    LAGUNA_HILLS,
    LAGUNA_NIGUEL,
    LAGUNA_WOODS,
    LAKE_FOREST,
    LOS_ALAMITOS,
    MISSION_VIEJO,
    NEWPORT_BEACH,
    ORANGE,
    PLACENTIA,
    RANCHO_SANTA_MARGARITA,
    SAN_CLEMENTE,
    SAN_JUAN_CAPISTRANO,
    SANTA_ANA,
    SEAL_BEACH,
    STANTON,
    TUSTIN,
    VILLA_PARK,
    WESTMINSTER,
    YORBA_LINDA
}
