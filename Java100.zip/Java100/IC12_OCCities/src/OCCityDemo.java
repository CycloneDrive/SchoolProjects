/*
Tran, Dan
CS A170
March  26, 2018 
*
IC #10#
*/
import java.util.Scanner;

public class OCCityDemo
{
    public static void main(String[] args)
    {
        String home;
        Scanner consoleScanner = new Scanner(System.in);

        System.out.print("In what city do you live?\n>> ");
        // "Costa Mesa" => "COSTA MESA" => "COSTA_MESA"
        // Define a boolean to keep track if we have found a match

        home = consoleScanner.nextLine().toUpperCase().replaceAll(" ", "_");
        consoleScanner.close();
        boolean foundMatch = false;

        for (OCCity city : OCCity.values())
        {
            if (home.equals(city.toString()))
            {
                foundMatch = true;
                System.out.println("Horray! You live in Orange County!");
                break; // stop the loop
            }
        }
        if (foundMatch==false)
        System.out.println("I'm so sorry you have a cold winter :(");
    }
}
