/*
Tran, Dan
CS A170
*/
import java.util.Scanner;

public class Sudoku
{
    // declare constants
    public static final int ROWS = 9;
    public static final int COLS = 9;

    public static final int[][] initialPuzzle = { { 9, 0, 0, 8, 0, 5, 0, 0, 6 }, { 1, 0, 3, 0, 0, 0, 5, 0, 4 },
            { 0, 6, 0, 0, 2, 0, 0, 7, 0 }, { 0, 0, 7, 1, 0, 8, 6, 0, 0 }, { 4, 0, 0, 0, 0, 0, 0, 0, 9 },
            { 0, 0, 9, 7, 0, 3, 1, 0, 0 }, { 0, 9, 0, 0, 1, 0, 0, 6, 0 }, { 3, 0, 2, 0, 0, 0, 4, 0, 7 },
            { 5, 0, 0, 3, 0, 2, 0, 0, 1 } };

    public static final int[][] solvedPuzzle = { { 9, 7, 4, 8, 3, 5, 2, 1, 6 }, { 1, 2, 3, 9, 6, 7, 5, 8, 4 },
            { 8, 6, 5, 4, 2, 1, 9, 7, 3 }, { 2, 3, 7, 1, 9, 8, 6, 4, 5 }, { 4, 8, 1, 2, 5, 6, 7, 3, 9 },
            { 6, 5, 9, 7, 4, 3, 1, 2, 8 }, { 7, 9, 8, 5, 1, 4, 3, 6, 2 }, { 3, 1, 2, 6, 8, 9, 4, 5, 7 },
            { 5, 4, 6, 3, 7, 2, 8, 9, 1 } };

    public static void main(String[] args)
    {
        // declare working puzzle array
        int[][] workingPuzzle = new int[ROWS][COLS];
        Scanner consoleScanner = new Scanner(System.in);
        String p1; 
        int row, col;
        //initialize the working puzzle
        resetPuzzle(workingPuzzle);
        //Loop as long as the game is not won
        do
        {
           printPuzzle(workingPuzzle);
           //TODO: 1) ask user for input (S set square, R reset, Q quit )
           //      2)Console Scanner
           //      3) Make a switch statement with 3 cases ("S", "R", or "Q")
           System.out.println("What would you like to do?\nSet a square (S), Reset Puzzle(R), or Quit(Q)");
           p1 = consoleScanner.nextLine().toUpperCase();
           switch (p1)
           {
	           case "R":
	           {
	        	   resetPuzzle(workingPuzzle);
	           }   
	           break;
	           case "S":
	           {
	        	   System.out.println("Which row (1-9) and column (1-9) do you want to change?");
	        	   row = consoleScanner.nextInt() - 1;
	        	   col = consoleScanner.nextInt() - 1;
	        	   System.out.println("Which should the value (1-9) be?");
	        	   workingPuzzle[row][col] = consoleScanner.nextInt();
	           }
	           break;
	           case "Q":
	           {
	        	   System.exit(0);
	           }
	           break;
           }
        }while(!gameIsWon(workingPuzzle));
        consoleScanner.close();
        System.out.println("\n\n\nCongrats on the wom!");
    }

    // intialize the workingPuzzle to intial puzzle
    public static void resetPuzzle(int[][] anyPuzzle)
    {
        for(int i = 0; i<ROWS;i++)
        {
            for (int j = 0; j<COLS;j++)
            {
                anyPuzzle[i][j] = initialPuzzle[i][j];
            }
        }
    }
    
    //print the puzzle (formatted)
    public static void printPuzzle(int[][] workingPuzzle)
    {
        //first two lines are always the same
        System.out.println(" C 1 2 3 4 5 6 7 8 9");
        System.out.println("R  -----------------");
        
        //loop through all the values in the working puzzle and print them out!
        for (int i = 0; i<ROWS ; i++)
        {
            System.out.print((i+1) + " |");
            for(int j=0; j<COLS; j++)
            {
                if(workingPuzzle[i][j]==0)
                {
                    System.out.print(". ");
                }
                else
                System.out.print(workingPuzzle[i][j] + " ");
            }
            System.out.println("");            
        }   
    }
    
    //
    public static boolean gameIsWon(int[][] workingPuzzle)
    {
        //use nested loops to determine if the working puzzle is exactly thte same as the solvedPuzzle
            for(int i = 0; i<ROWS;i++)
            {
                for (int j = 0; j<COLS;j++)
                {
                 // if they're different return false
                    if (workingPuzzle[i][j] != solvedPuzzle[i][j])
                        return false;
                }
            }
            //if it makes it through all 81 values, they are the same
            return true;
    }
}
