/*
Tran, Dan

CS A250
February 6, 2019

Lab 2
*/

#include "Ferrari.h"

using namespace std;

int main()
{
	// Default Constructor testing
	Ferrari f1;
	
	// Parameterized/Overloaded Constructor tesing
	Ferrari fCustom("Ferrari 812 Superfast", 2017);

	// getModel testing
	cout << "Model of fCustom is: " << fCustom.getModel() << endl;

	cout << endl;

	// getYear testing
	cout << "Year of fCustom is: " << fCustom.getYear() << endl;

	cout << endl;

	// print function testing
	fCustom.print();

	cout << endl << endl;

	// sameCar function testing
	cout << "Calling sameCar function on f1 and fCustom, result is: "
		<< boolalpha << f1.sameCar(fCustom) << endl;

	cout << boolalpha << f1.sameCar(fCustom) << endl;

	system("pause");
	return 0;
}