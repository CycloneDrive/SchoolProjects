/*
Tran, Dan

CS A250
February 6, 2019

Lab 2
*/

#include "Ferrari.h"
#include <string>

Ferrari::Ferrari()
{
	model = "250 Eurpoa GT";
	year = 1954;
}

Ferrari::Ferrari(const std::string& model_, int year_)
{
	model = model_;
	year = year_;
}

std::string Ferrari::getModel() const
{
	return model;
}

void Ferrari::setModel(std::string newModel)
{
	model = newModel;
}

int Ferrari::getYear() const
{
	return year;
}

void Ferrari::setYear(int newYear)
{
	year = newYear;
}

void Ferrari::print() const
{
	std::cout << model << "(" << year << ")";
}

bool Ferrari::sameCar(const Ferrari& FerrariObj) const
{
	return (model == FerrariObj.model && year == FerrariObj.year);
}