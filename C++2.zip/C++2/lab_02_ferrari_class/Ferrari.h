/*
Tran, Dan

CS A250
February 6, 2019

Lab 2
*/

#ifndef Ferrari_H
#define Ferrari_H

#include <iostream>
#include <string>

class Ferrari
{ 
	public:
		Ferrari();
		Ferrari(const std::string& model_, int year_);
		std::string getModel() const;
		void setModel(std::string newModel);
		int getYear() const;
		void setYear(int newYear);
		void print() const;
		~Ferrari() = default;
		bool sameCar(const Ferrari& FerrariObject) const;
	private:
		std::string model;
		int year;
};

#endif