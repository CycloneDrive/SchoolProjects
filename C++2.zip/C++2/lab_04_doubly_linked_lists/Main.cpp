/*
	Tran, Dan

	CS A250
	February 17, 2019

	Lab 4
*/

/***********************************************

	Class DoublyList

************************************************/

#include "DoublyList.h"

#include <iostream>
using namespace std;

int main()
{
	DoublyList intList;
	
	intList.insertInOrder(8);
	intList.insertInOrder(5);
	intList.insertInOrder(37);
	intList.insertInOrder(53);
	intList.insertInOrder(21);
	intList.insertInOrder(18);
	intList.insertInOrder(73);
	intList.insertInOrder(49);
	
	cout << "TESTING: insertInOrder() and print()" 
		<< "\n\nEXPECTED OUTPUT: "
		<< "\nList: 5 8 18 21 37 49 53 73\n";
	cout << "\nACTUAL OUTPUT:";
	cout << "\nList: ";
	intList.print();

	cout << "\n\n-----------------------------------------------------\n";
	cout << "TESTING: printReverse()" 
		<< "\n\nEXPECTED OUTPUT: "
		<< "\nList (reversed): 73 53 49 37 21 18 8 5\n";
	cout << "\nACTUAL OUTPUT:";
	cout << "\nList (reversed): ";
	intList.reversePrint();

	cout << "\n\n-----------------------------------------------------\n";
	cout << "TESTING: Check first and last nodes" 
		<< "\n\nEXPECTED OUTPUT: "
		<< "\nFirst node data: 5"
		<< "\nLast node data: 73\n";
	cout << "\nACTUAL OUTPUT:";
	cout << "\nFirst node data: "
		<< intList.front()
		<< "\nLast node data: "
		<< intList.back();

	cout << "\n\n-----------------------------------------------------\n";
	cout << "FINAL TESTING" << endl;
	cout << "\nEmpty the list and insert 100...\n";
	intList.destroyList();		
	intList.insertInOrder(100);
	cout << "List: ";
	intList.print();
	cout << "\nReversed list: ";
	intList.reversePrint();

	cout << "\n\nYour testing cases...\n";
	// TEST function copyToList

	// Create two lists, list1 and list2.
	DoublyList list1, list2, list4, list5;
	cout << "~~Creating and Printing list1 (empty) and list2 (empty)~~\n";
	list1.print();
	list2.print();

	// Copy list1 (empty) into list2 (empty).
	cout << "\n~~Copying list1 (empty) INTO list2 (empty)~~\n";
	list1.copyToList(list2);

	list1.insertInOrder(5);
	list1.insertInOrder(4);
	list1.insertInOrder(3);
	list1.insertInOrder(2);
	list1.insertInOrder(1);

	list1.print();
	cout << endl;
	
	//new list 4
	list4.insertFront(6);
	list4.insertFront(7);
	list4.insertFront(8);
	list4.insertFront(9);
	list4.insertFront(10);
	cout << "\n\n~~New List 4~~" << endl;
	list4.print(); 

	//new list 5
	list5.insertFront(20);
	list5.insertFront(19);
	list5.insertFront(17);
	list5.insertFront(16);
	list5.insertFront(14);
	list5.insertFront(13);
	cout << "\n\n~~New List 5~~" << endl;
	list5.print();

	// Create list list3.
	DoublyList list3;

	// Copy list1 (non-empty) into list3 (empty).
	cout << "\n\n~~Copying list1 (non-empty) INTO list3 (empty)~~\n";
	list1.copyToList(list3);

	list1.print();

	cout << "\n\n"; 

	list3.print(); // This is copying backwards..?

	//Copy list4 (5 elements) into list 1 (5 elements) SAME ELEMENTS
	cout << "\n\n~~Copying list4 (5 elements) INTO list1 (5 elements)~~\n";
	list4.copyToList(list1);

	list1.print();

	cout << "\n\n";

	//Copy list1 (10 elements) into list 4 (5 elements) MORE ELEMENTS
	cout << "\n\n~~Copying list1 (10 elements) INTO list4 (5 elements)~~\n";
	list1.copyToList(list4);

	list4.print();

	cout << "\n\n";

	//Copy list5 (6 elements) into list 1 (10 elements) LESS ELEMENTS
	cout << "\n\n~~Copying list5 (6 elements) INTO list1 (10 elements)~~\n";
	list5.copyToList(list1);

	list1.print();

	cout << "\n\n";

	cout << endl << endl;
	system("Pause");
	return 0;
}
