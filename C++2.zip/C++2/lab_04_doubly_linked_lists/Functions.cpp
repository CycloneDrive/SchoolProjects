/*
	Tran, Dan

	CS A250
	February 17, 2019

	Lab 4
*/

#include "DoublyList.h"

// Definition function print
void DoublyList::print() const
{
	Node *current = first;
	while (current != nullptr)
	{
		cout << current->getData() << " ";
		current = current->getNext();
	}
}

// Definition function reversePrint
void DoublyList::reversePrint() const
{
	Node *current = last;
	while (current != nullptr)
	{
		cout << current->getData() << " ";
		current = current->getPrev();
	}
}

// Definition function front
int DoublyList::front() const
{
	return first->getData();
}

// Definition function back
int DoublyList::back() const
{
	return last->getData();
}

// Definition function copyToList
void DoublyList::copyToList(DoublyList& newList)
{
	Node* current = last;
	while (current != nullptr)
	{
		newList.insertFront(current->getData());
		current = current->getPrev();
	}
}

// Definition function insertInOrder (from right to left)
void DoublyList::insertInOrder(int value)
{
	// Empty Case
	if (first == nullptr)
		insertFront(value);
	else
	{
		Node* current = last->getPrev();
		Node* trailing = last;
		Node* newNode = new Node(value, nullptr, nullptr);

		// Insert at the very end
		if (value > trailing->getData())
		{
			newNode->setPrev(last);
			last->setNext(newNode);
			last = newNode;
			++count;
		}

		// Insert at the very front
		else if (value < first->getData())
		{
			insertFront(value);
		}

		//Insert at the middle
		else
		{
			bool flag = false;
			while (!flag && current != nullptr)
			{
				if (value > current->getData())
				{
					newNode->setPrev(current);
					newNode->setNext(trailing);

					// Changing old Nodes pointers
					current->setNext(newNode);
					trailing->setPrev(newNode);
					++count;
					flag = true;
				}

				current = current->getPrev();
				trailing = trailing->getPrev();
			}
		}
	}
}