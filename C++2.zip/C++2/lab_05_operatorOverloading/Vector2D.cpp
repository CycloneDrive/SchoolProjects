/*
	Tran, Dan

	CS A250
	February 28, 2019

	Lab 5
*/


#include "Vector2D.h"

int Vector2D::operator*(const Vector2D& other) const
{
	return ((x * other.x) + (y * other.y));
}

bool Vector2D::operator==(const Vector2D& right) const
{
	return (x == right.x && y == right.y);
}

ostream& operator<<(ostream& out, const Vector2D obj)
{
	out << "<" << obj.x << "," <<  obj.y << ">";
	return out;
}