/*
	Tran, Dan

	CS A250
	February 28, 2019

	Lab 5
*/


#ifndef VECTOR2D_H
#define VECTOR2D_H

#include <string>
#include <iostream>

using namespace std;

class Vector2D
{
	friend ostream& operator<<(ostream& out, const Vector2D obj);

	public:
		Vector2D() : x(0), y(0) {}
		Vector2D(int newX, int newY) : x(newX), y(newY) {}

		int operator*(const Vector2D& right) const;
		bool operator==(const Vector2D& right) const;

		~Vector2D() {}
	private:
		int x;
		int y;
};

#endif