/*
	Tran, Dan

	CS A250
	February 13, 2019

	Lab 3
*/

#include "AnyList.h"

//Definition function getNumOfItems

int AnyList::getNumOfItems() const
{
	return count;
}

//Definition of function insertBack
void AnyList::insertBack(int newItem)
{
	if (count == 0) // or (ptrToFirst == nullptr)
		ptrToFirst = new Node(newItem, nullptr);
	else // there is at least one node in the list
	{
		Node *current = ptrToFirst;
		while (current->getPtrToNext() != nullptr)
			current = current->getPtrToNext();

		current->setPtrToNext(new Node(newItem, nullptr));
	}

	++count;
}

//Declaration function search
bool AnyList::search(int data) const
{
	// include empty case
	if (count == 0)
	{
		cerr << "The list is empty.";
		return false;
	}

	bool found = false;
	Node *current = ptrToFirst;

	while (!found && current != nullptr)
	{
		if (data == current->getData())
			found = true;
		else
		{
			current = current->getPtrToNext();
		}
	}

	return found; // found can be true or false
}

//Definition function commonEnds
bool AnyList::commonEnds(const AnyList& paramObj) const
{
	// If either Node is empty
	if (count == 0 || paramObj.count == 0)
		return false;

	// First Check: ptrToFirst is the same?
	if (ptrToFirst->getData() != paramObj.ptrToFirst->getData())
		return false;

	Node *callingCurrent = ptrToFirst;
	Node *paramCurrent = paramObj.ptrToFirst;


	// calling obj
	while (callingCurrent->getPtrToNext() != nullptr)
	{
		callingCurrent = callingCurrent->getPtrToNext();
	}

	while (paramCurrent->getPtrToNext() != nullptr)
	{
		paramCurrent = paramCurrent->getPtrToNext();
	}

	return (callingCurrent->getData() == paramCurrent->getData());

}