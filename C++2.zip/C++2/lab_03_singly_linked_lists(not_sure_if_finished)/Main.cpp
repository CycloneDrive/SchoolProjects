#include "AnyList.h"
#include "Testing.h" //	NEED TO ADD FOR TESTING

#include <iostream>
using namespace std;

int main()
{
	cout << "*********************************\n"
		<< "*                               *\n"
		<< "*     TESTING insertBack...     *\n"
		<< "*                               *\n"
		<< "*********************************\n\n";

	test_insertBack();

	cout << "*********************************\n"
		<< "*                               *\n"
		<< "*   TESTING getNumOfItems...    *\n"
		<< "*                               *\n"
		<< "*********************************\n\n";

	test_getNumOfItems();

	cout << "*********************************\n"
		<< "*                               *\n"
		<< "*       TESTING search...       *\n"
		<< "*                               *\n"
		<< "*********************************\n\n";

	test_search();

	cout << "*********************************\n"
		<< "*                               *\n"
		<< "*     TESTING commonEnds...     *\n"
		<< "*                               *\n"
		<< "*********************************\n\n";

	test_commonEnds();
	
	cout << endl;
	system("Pause");
	return 0;
}

