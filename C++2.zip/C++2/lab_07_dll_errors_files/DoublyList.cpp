/*
	Tran, Dan

	CS A250
	March 7, 2019

	Lab 7
*/

#include "DoublyList.h"

DoublyList::DoublyList()
{
	first = nullptr;
	last = nullptr;
	count = 0;	
}

void DoublyList::insertBack(int newData)
{
	Node *newNode = new Node(newData, nullptr, nullptr);

	if (first == nullptr)
	{
		first = newNode;
		last = newNode;
	}
	else
	{
		last->setNext(newNode);
		newNode->setPrev(last);
		last = newNode;
	}
	++count;
}

bool DoublyList::search(int searchData) const
{
	Node *current = first;

	// Takes care of all cases
		// 1) First Node
		// 2) Middle (somewhere)
		// 3) Last
		// 4) Not Found
		// 5) List is empty
	while (current != nullptr 
		&& current->getData() != searchData)
	{
			current = current->getNext();
	}
	return (current != nullptr);
}

void DoublyList::deleteNode(int deleteData)
{
	// Empty Case
	if (first == nullptr)
	{
		cerr << "Cannot delete from an empty list." << endl;
	}
	else
	{
		Node *current = first;

		// First Node Case
		if (current->getData() == deleteData)
		{
			first = first->getNext();

			// One Node Case
			if (first == nullptr)
				last = nullptr;
			// Two Node Case
			else
				first->setPrev(nullptr);

			delete current;
			current = nullptr;
			--count;
		}
		else
		{
			bool found = false;

			while (current != nullptr && !found)
			{
				if (current->getData() == deleteData)
					found = true;
				else
					current = current->getNext();
			}

			if (current == nullptr)
				cerr << "The item to be deleted is not in the list." << endl;
			else
			{
				// Middle Case
				if (current != last)
				{
					current->getPrev()->setNext(current->getNext());
					current->getNext()->setPrev(current->getPrev());
				}
				// Case at the very end
				else
				{
					last = current->getPrev();
					last->setNext(nullptr);
				}

				delete current;
				current = nullptr;
				--count;
			}
		}
		//--count;
	}
}

void DoublyList::print() const
{
	if (count == 0)
		cerr << "List is empty. Cannot print." << endl;
	else
	{
		Node *temp = first;

		while (temp != nullptr)		
		{
			cout << temp->getData() << " ";
			temp = temp->getNext();
		}
		cout << endl;
	}
}

void DoublyList::reversePrint() const
{
	if (count == 0)
		cerr << "List is empty. Cannot print." << endl;
	else 
	{
		Node *temp = last;

		while (temp != nullptr)
		{
			cout << temp->getData() << " ";
			temp = temp->getPrev();
		}
		cout << endl;
	}
}

void DoublyList::destroyList()
{
	Node *temp = first;

	while (temp != nullptr)
	{			
		first = first->getNext();
		delete temp;
		temp = first;
	}

	count = 0;
	last = nullptr;
}

DoublyList::~DoublyList()
{
	destroyList();
}