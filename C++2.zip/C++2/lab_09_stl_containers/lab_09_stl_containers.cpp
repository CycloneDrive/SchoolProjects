/*
	Tran, Dan

	CS A250
	April 6, 2019

	Lab 9
*/

#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <set>
#include <array>
#include <map>

using namespace std;

// Declaration function printVector.
// The function passes a vector and prints all
// the elements on one line, separated by a space.
// Use an iterator and a FOR loop.
void printVector(const vector<int>& iVec);

// Declaration function printList.
// The function passes a list and prints all
// the elements on one line, separated by a space.
// Use an iterator and a WHILE loop.
void printList(const list<int>& myList);

// Declaration function printSet.
// The function passes a list and prints all
// the elements on one line, separated by a space.
// Use a range-based FOR loop. If you do not know
// what this means, search the Web.
void printSet(const set<int>& mySet);


int main()
{

	/***************************************************************************
			VECTORS
	***************************************************************************/
	cout << "  ***  STL VECTOR CLASS  ***  \n\n";

	// Use the default constructor to declare an integer vector v1.
	vector<int> v1;

	// void push_back (const value_type& val);
	// Use function push_back to insert the following values in v1: 12, 73, 41,
	// 38, 25, 56, an 63 in this order.
	v1.push_back(12);
	v1.push_back(73);
	v1.push_back(41);
	v1.push_back(38);
	v1.push_back(25);
	v1.push_back(56);
	v1.push_back(63);

	// size_type size() const noexcept;
	// Create a variable of type int named sizeV1 and store the size of the vector.
	// Use function size to retrieve the size of the vector. 
	// Make sure you cast the return value of the function size to the appropriate type.
	int sizeV1 = static_cast<int>(v1.size());

	// Use a FOR loop to print out the vector.
	// Do NOT use an iterator.
	for (int i = 0; i < sizeV1; ++i)
	{
		cout << v1.at(i) << " ";
	}
	
	cout << "calling v1" << endl;

	//void clear() noexcept;
	// Call the function clear on vector v1.
	v1.clear();

	// size_type size() const noexcept;
	// Call function size to print the size of v1.
	cout << v1.size() << endl;

	// size_type capacity() const noexcept;
	// Call function capacity to output the capacity of v1.
	cout << v1.capacity() << endl; 

	// Create an array of integers containing: 10,11,12,13,14,15,16,17,18,19
	array <int, 10> a = { 10,11,12,13,14,15,16,17,18,19 };

	// Use the default constructor to declare an integer vector v2.
	vector<int> v2;

	// void assign (InputIterator first, InputIterator last);
	// Use function assign to copy elements 12, 13, 14, 15, and 16 in v2.
	// One statement only.
	v2.assign(a.begin() + 2, a.begin() + 7);

	// Call the function printVector to print v2.
	printVector(v2);

	// const_reference back() const;
	// Use the function back output the last element in the vector
	// (Notice that the back function returns a reference.)
	cout << v2.back() << endl;
		
	// Use the default constructor to declare an integer vector v3.
	vector<int> v3;

	// void assign (size_type n, const value_type& val);
	// Use function assign to insert the values 7, 7, 7, 7, and 7.
	// One statement only.
	v3.assign(5, 7);

	// Call the function printVector  to print v3.
	printVector(v3);

	// const_reference at(size_type n) const;
	// Use function at to replace the middle element with 100.
	// (Notice that the at function returns a reference.)
	v3.at(v3.size() / 2) = 100;

	// Call the function printVector to print v3.
	printVector(v3);

	// vector (const vector& x);
	// Use the copy constructor to create a new vector v4 with the 
	// same elements of v3.
	vector<int> v4(v3);

	// Call the function printVector to print v4.
	printVector(v4);

	// Create an iterator iterVector4 to point to the first element of v4.
	vector<int>::const_iterator iterVector4 = v4.begin();

	// Create an iterator iterVector2 to point to the second element of v2.
	vector<int>::const_iterator iterVector2 = v2.begin() + 1;

	// iterator insert (const_iterator position, InputIterator first, InputIterator last);
	// Use function insert to insert the second, third, and fourth element
	// of v2 as the first, second, and third element of v4.
	// (Notice that the insert function returns an iterator, 
	//   but if we do not intend to use it, we can ignore it.)
	v4.insert(iterVector4, iterVector2, iterVector2 + 3);

	// Call the function printVector to print v4.
	printVector(v4);

	// iterator insert (const_iterator position, size_type n, const value_type& val);
	// Use the function insert to insert three 0s at the end of v4.
	// (Notice that the insert function returns an iterator, 
	//   but if we do not intend to use it, we can ignore it.)
	v4.insert(v4.end(), 3, 0);

	// Call the function printVector to print v4.
	printVector(v4);

	// bool empty() const noexcept;
	// const_reference back() const;
	// void pop_back();
	// Use a WHILE loop to remove and output each element of v2 backwards.
	// Use function empty for the loop condition, function back to output 
	// the last element, and function pop_back to remove elements.
	// (Notice that the insert function returns an iterator, 
	//   but if we do not intend to use it, we can ignore it.)
	while (!v2.empty())
	{
		cout << v2.back() << " ";
		v2.pop_back();
	}

	// void resize (size_type n, const value_type& val);
	// Use function resize to insert three times number 4 in v2.
	v2.resize(3, 4);

	// Call the function printVector to print v2.
	printVector(v2);

	// const_reference front() const;
	// Use function front to output the first element in v4.
	// (Notice that the front function returns a reference.)
	cout << v4.front() << endl;

	// void swap (vector& x);
	// Use function swap to swap v2 with v4.
	v2.swap(v4);

	// Call the function printVector to print v2.
	printVector(v2);
	cout << "\nI am here" << endl;
	// Create a new vector v5;
	vector<int> v5;

	// Use the overloaded assignment operator to copy all the elements of v2
	// into v5.
	v5 = v2;

	// void resize (size_type n);
	// size_type size() const noexcept;
	// Delete the last element of v5 by using the functions resize and size
	v5.resize(v5.size() - 1); // double check

	// Call the function printVector to print v5.
	printVector(v5);
	// Create an iterator iterVector5 to point to the first element of v5.
	vector<int>::iterator iterVector5 = v5.begin();

	// iterator erase (const_iterator first, const_iterator last);
	// size_type size() const noexcept;
	// Call the function erase to delete the second half of v5.
	// Use function size to get the range.
	// (Notice that the insert function returns an iterator, 
	//   but if we do not intend to use it, we can ignore it.)
	v5.erase(iterVector5 + (v5.size() / 2), v5.end());

	// Call the function printVector to print v5 again.
	printVector(v5);

	// iterator erase (const_iterator position);
	// Call the function erase to delete the first element of the vector.
	// (Notice that the insert function returns an iterator, 
	//   but if we do not intend to use it, we can ignore it.)
	v5.erase(iterVector5);

	// Call the function printVector to print v5 again.
	printVector(v5);

	// Create a vector of integers named v6 containing numbers from 100 to 105.
	// Using the copy constructor, create a vector named v7, a copy of v6.
	vector<int> v6 = { 100, 101, 102, 103, 104, 105 };
	vector<int> v7(v6);

	// iterator erase (const_iterator position);
	// iterator insert (const_iterator position, const value_type& val);
	// Erase element 103 from v7 and insert element 333 in its plase, 
	// by using an iterator.
	// Note that the function erase returns an iterator that can be used
	// to insert 333 in the right position.
	vector<int>::iterator iterVector7 = v7.erase(v7.begin() + 3);

	v7.insert(iterVector7, 333);

	// Using a range-based FOR loop, print v7.
	for (auto x : v7)
	{
		cout << x << " ";
	}

	/***************************************************************************
			LISTS
	***************************************************************************/

	cout << "\n\n----------------------------------------------------";
	cout << "\n  ***  STL LIST CLASS  ***  \n\n\n";

	// Use the default constructor to create three lists of integers, intLis1,
	// intList2, and intList3.
	list<int> intList1, 
		intList2, 
		intList3;

	// void push_back (const value_type& val);
	// Use the function push_back to insert the following values in the first list: 
	// 23 58 58 58 36 15 15 93 98 58
	intList1.push_back(23);
	intList1.push_back(58);
	intList1.push_back(58);
	intList1.push_back(58);
	intList1.push_back(36);
	intList1.push_back(15);
	intList1.push_back(15);
	intList1.push_back(93);
	intList1.push_back(98);
	intList1.push_back(58);

	// Call function printList to print intList1.
	printList(intList1);

	// Using the overloaded assignment operator, copy elements of intList1 into intList2.
	intList2 = intList1;

	// Call function printList to print intList2.
	printList(intList2);

	// void sort();
	// Using function sort, sort all elements in the second list.
	intList2.sort();

	// Call function printList to print intList2.
	printList(intList2);

	// void unique();
	// Using function unique, removes all consecutive duplicates in the list.
	intList2.unique();

	// Call function printList to print intList2.
	printList(intList2);
			
	// void push_back (const value_type& val);
	//Insert the following elements in the third list:
	//  13 23 25 136 198
	intList3.push_back(13);
	intList3.push_back(23);
	intList3.push_back(25);
	intList3.push_back(136);
	intList3.push_back(198);

	// Call function printList to print intList3.
	printList(intList3);

	// void merge (list& x);
	// Add to the second list all elements of the third list(browse the  
	//  list of functions in cplusplus.com to figure out which function  
	//  you need to use).
	// --> This is ONE statement only.
	intList2.merge(intList3);

	// Call function printList to print intList2.
	printList(intList2);

	/*
	/***************************************************************************
			SETS
	***************************************************************************/
	cout << "\n\n----------------------------------------------------";
	cout << "\n  ***  STL SET CLASS  ***  \n\n";

	// Create a set of ints named set1 using the initializer list to insert the 
	// following integers in this order: 2, 7, 5, 6, 9, 1 and 3.
	set<int> set1 = { 2, 7, 5, 6, 9, 1, 3 };

	// Print the set using the printSet function you implemented.
	printSet(set1);

	// What do you notice in the printout?

	// size_type  erase (const value_type& val);
	// Use the function erase integer 9 from set1.
	// Print out set1.
	set1.erase(9);

	printSet(set1);

	// size_type  erase (const value_type& val);
	// Use the function erase integer 2 from set1, but
	// this time use cout to print the return value.
	// What is the return value?	
	cout << set1.erase(2);

	// If you do not know what the return value is, then
	// check set::erase in cplusplus.com
	cout << endl;

	// Print set1.
	printSet(set1);

	// iterator  erase (const_iterator position);
	// This function is different from the previous one,
	// because instead of passing a value, it passes a 
	// position indicated by an iterator.
	// Delete the second element in the set without creating
	// an iterator variable and using the prefix increment
	// operator.
	set1.erase(++set1.begin());

	// Print set1.
	printSet(set1);

	// pair<iterator,bool> insert (const value_type& val);
	// Use the function insert to insert 4 and 8 in set1.
	set1.insert(4);
	set1.insert(8);

	// Print set1.
	printSet(set1);
	
	// //set<int>::iterator first = set1.begin();
	// //set<int>::iterator second = ++set1.begin();
	// iterator  erase(const_iterator first, const_iterator last);
	// Use function erase to delete the first and second element
	// in set1. Use the given iterators created above.
	// Note that you should write one statement only.
	set<int>::iterator first = set1.begin();
	set<int>::iterator second = ++set1.begin();

	set1.erase(first, ++second);

	// Print set1.
	printSet(set1);

	// Your output should be: 5 6 7 8
	// If it is not, you need to carefully view the function erase
	// to understand how it works.

	cout << "\n\n----------------------------------------------------";
	cout << "\n\nThe output for the next sections depends on your implementation.";

	/***************************************************************************
	MAPS
	***************************************************************************/
	cout << "\n\n----------------------------------------------------";
	cout << "\n  ***  STL MAP CLASS  ***  \n\n";

	// Create a few maps using the different constructors shown in the slides.
	// Use the following functions to manipulate the maps:

	// pair<iterator,bool> insert (const value_type& val);
	// void insert (InputIterator first, InputIterator last);
	// iterator  erase(const_iterator position);
	// size_type erase(const key_type& k);
	// iterator  erase(const_iterator first, const_iterator last);

	// Print each map without creating a print function, but by using
	// a loop.
	
	// (1) Using the default constructor
	map<int, string> map1;
	map1[25] = "Aurora Borealis";
	map1[75] = "Citadel";
	map1[50] = "Italy";

	cout << "\nmap1 = ";
	for (auto i : map1)
		cout << "(" << i.first << ", " << i.second << ") ";
	cout << endl;

	// =================================================
	// (2) Using the copy constructor
	map<int, string> map2(map1);
	
	map2.insert(make_pair(100 ,"Germany"));

	map<int, string>::const_iterator map2Iter = map2.begin();
	++map2Iter;

	map2.erase(map2Iter);

	cout << "\nmap2 = ";
	for (auto i : map2)
		cout << "(" << i.first << ", " << i.second << ") ";
	cout << endl;

	// =================================================
	// (3) Using the initializer list constructor

	map<int, string> map3
	{
		{1, "Russia"},
		{2, "Austrailia"},
		{3, "France"}
	};

	map2Iter = map2.begin(); // Why does this statement need to be here to work?
	map<int, string>::const_iterator map2End = map2.end();
	map3.insert(map2Iter, map2End);

	cout << "\nmap3 = ";
	for (auto i : map3)
		cout << "(" << i.first << ", " << i.second << ") ";
	cout << endl;


	// =================================================
	// (4) Using the range constructor
	map<int, string> map4(++map3.begin(), map3.end());

	cout << "\nmap4 = ";
	for (auto i : map4)
		cout << "(" << i.first << ", " << i.second << ") ";
	cout << endl;



	// =================================================
	// (5) Using the make_pair function

	map<int, string> map5;

	for (int i = 10; i <= 40; i += 10)
		map5.insert(make_pair(i, "apple"));

	cout << "\nmap5 = ";
	for (auto i : map5)
		cout << "(" << i.first << ", " << i.second << ") ";
	cout << endl;


	/*************************************************************************
	*		Create statements using the functions below.
	*       You might need to create new containers.
	*		Is the output what you expected?
	*************************************************************************/
	cout << "\n\n----------------------------------------------------";
	cout << "\n  ***  OTHER FUNCTIONS  ***  \n\n";

	// list: void assign (size_type n, const value_type& val);
	list<int> myList;
	myList.assign(4, 10);
	printList(myList);

	// vector: void assign (InputIterator first, InputIterator last);	
	vector<int> myVector;
	myVector.assign(10, 4);
	printVector(myVector);


	// list: const_reference back() const;
	// (Notice that this back function returns a reference.)
	cout << myList.back() << endl;

	// list: void clear() noexcept;
	myList.clear();
	cout << "myList after clear() is: ";
	printList(myList);

	// list: bool empty() const noexcept;
	if (myList.empty())
		cout << "myList is currently empty";
	else
		cout << "myList is currently NOT empty";

	// vector: const_reference front() const;
	cout << "Front of myVector is currently: " << myVector.front() << endl;

	// list: iterator insert (const_iterator position, const value_type& val);
	// (Notice that the insert function returns an iterator.)
	myList.insert(myList.begin(), 25); // list is currently empty
	
	for (int i = 0; i < 5; ++i)
		myList.insert(++myList.begin(), i + 1);

	cerr << "Testing list insert: ";
	printList(myList);

	// list: void pop_back();
	myList.pop_back();
	printList(myList);

	// list: void pop_front();
	myList.pop_front();

	cout << "Testing list::pop_front(): ";
	printList(myList);

	// list: void push_front (const value_type& val);
	myList.push_front(42);

	cout << "Testing myList::push_front: ";
	printList(myList);

	// list: void remove (const value_type& val);
	cout << "Pushing 2 to the front.." << endl;
	myList.push_front(2);
	cout << "Before | myList::remove testing: ";
	printList(myList);

	cout << "Testing multiple of the same element case" << endl;

	myList.remove(2);
	cout << "After | myList::remove testing: ";
	printList(myList);

	// list: void reverse() noexcept;
	myList.reverse();
	cout << "myList::reverse testing: ";
	printList(myList);

	// list: void splice (const_iterator position, list& x);
	cout << "myList is currently: ";
	printList(myList);

	list<int> myList2{1, 3, 5, 7, 9 };
	cout << "myList2 is currently: ";
	printList(myList2);

	cout << "list::splice Testing -- Transfering elements from myList into myList2 " 
		<< endl;

	list<int>::iterator myList2iter = ++myList2.begin();
	++myList2iter;
	++myList2iter;

	myList2.splice(myList2iter, myList);

	cout << "myList is currently: ";
	printList(myList);

	cout << "myList2 is currently: ";
	printList(myList2);

	// list: void splice (const_iterator position, list& x, const_iterator i);

	list<int>::iterator myList2Iter = myList2.begin();
	list<int>::iterator myList2IterCustom = ++myList2.begin();

	for (int i = 0; i < 3; ++i)
	{
		++myList2IterCustom;
	}

	list<int> myList3(myList2Iter, myList2IterCustom);

	cout << "myList3 is currently: ";
	printList(myList3);

	myList3.splice(myList3.end(), myList2, myList2.begin());

	cout << "myList3 is now: ";
	printList(myList3);

	// list: void splice (const_iterator position, list& x, const_iterator first, const_iterator last);
	list<int> myList4 = { 2, 4, 6 };

	list<int>::const_iterator myList3Iter = ++myList3.begin();
	list<int>::const_iterator myList3IterCustomEnd = myList3.end();

	myList4.splice(myList4.begin(), myList3, myList3Iter, myList3IterCustomEnd);

	cout << "After splice, myList 4 is now: ";
	printList(myList4);

	// set: void swap (set& x);

	set<int> mySet;

	for (int i = 0; i < 5; ++i)
		mySet.insert( (i + 1) * 25);

	set<int>::const_iterator mySetIterBegin = mySet.begin();
	set<int>::const_iterator mySetIterCustomEnd = ++mySet.begin();
	++mySetIterCustomEnd; // should point to index 2, but go up to index 1 (i.e. 50)

	set<int> mySet2(mySetIterBegin, mySetIterCustomEnd);

	cout << "mySet is currently: ";
	printSet(mySet);
	cout << "mySet2 is currently: ";
	printSet(mySet2);

	cout << "~Using function set::swap..." << endl;

	mySet2.swap(mySet);

	cout << "mySet is now: ";
	printSet(mySet);
	cout << "mySet2 is now: ";
	printSet(mySet2);

	// set: const_iterator find (const value_type& val) const;
	
	set<int>::const_iterator newInsertIter = mySet.find(25);

	mySet.insert(newInsertIter, 33);
	
	cout << "~After set::find and set::insert, mySet is now: ";
	printSet(mySet);

	cout << "~Messing around with the returned iterator find provided: ";
	mySet.erase(++newInsertIter);
	printSet(mySet);

	cout << "\n\n----------------------------------------------------";

	cout << endl;
	system("Pause");
	return 0;
}

// Definition function printVector
void printVector(const vector<int>& iVec)
{
	vector<int>::const_iterator iter = iVec.cbegin();
	vector<int>::const_iterator iterEnd = iVec.cend();

	for (iter; iter != iterEnd; ++iter)
		cout << *iter << " ";

	cout << endl;
}

// Definition function printList
void printList(const list<int>& myList)
{
	list<int>::const_iterator iter = myList.cbegin();
	list<int>::const_iterator iterEnd = myList.cend();

	for (iter; iter != iterEnd; ++iter)
		cout << *iter << " ";

	cout << endl;
}

// Definition function printSet
void printSet(const set<int>& mySet)
{
	set<int>::const_iterator iter = mySet.cbegin();
	set<int>::const_iterator iterEnd = mySet.cend();

	for (iter; iter != iterEnd; ++iter)
		cout << *iter << " ";

	cout << endl;
}