/***********************************************

	Class DoublyList

************************************************/

#include "DoublyList.h"

#include <iostream>
using namespace std;

int main()
{
	DoublyList dList;

	dList.createAList();

	cout << endl << endl;
	system("Pause");
	return 0;
}
