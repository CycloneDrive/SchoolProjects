/*
	Tran, Dan

	CS A250
	April 19, 2019

	Lab 10: Static Member Variables
*/

#include "Fundraising.h"


//static variable initialized 
double Fundraising::totalBalance = -1 * (COST_PER_BOX * TOTAL_BOXES_TO_SELL);
int Fundraising::totalBoxesSold = 0;
int Fundraising::totalBoxesInStorage = TOTAL_BOXES_TO_SELL;

// Default constructor
Fundraising::Fundraising()
{
	boxesSold = 0;
	boxesToSell = 10;
	id = 0;

	// Static Variables
	totalBoxesInStorage -= 10;
}

// Definition of function setID
void Fundraising::setID(string newName, int newID)
{
	name = newName;
	id = newID;
}

// Definition of function requestBoxes
void Fundraising::requestBoxes(int moreBoxes)
{
	if (moreBoxes > totalBoxesInStorage)
	{
		cerr << "\n*** Not able to fulfill request. There are only "
			<< totalBoxesInStorage << " boxes left.";
	}
	else
	{
		boxesToSell += moreBoxes;
		totalBoxesInStorage -= moreBoxes;
	}
}

// Definition of function justSold
void Fundraising::justSold(int boxesSoldToday)
{
	// Member Variables
	boxesSold = boxesSoldToday;

	// Static Variables
	totalBoxesSold += boxesSoldToday;
	totalBalance += (boxesSold * 5.0);
}

// Definition of function getTotalBalance
double Fundraising::getTotalBalance() 
{
	return totalBalance;
}

// Definition of function getTotalBoxesSold
int Fundraising::getTotalBoxesSold()
{
	return totalBoxesSold;
}

// Definition of function getTotalBoxesInStorage
int Fundraising::getTotalBoxesInStorage() 
{
	return totalBoxesInStorage;
}

// Destructor
Fundraising::~Fundraising()
{}




