/*
Tran, Dan
CS A250
February 1, 2019
Lab 1
*/
#include <iostream> 
using namespace std;

// Definition function deleteDuplicates
void deleteDuplicates(int a[], int& numOfElements)
{
	for (int i = 0; i < numOfElements - 1; ++i)
	{
		for (int j = i + 1; j < numOfElements; ++j)
		{
			if (a[i] == a[j])
			{
				int k = 0;
				while (k < numOfElements)
				{
					k++;
				}

				/*
				for (unsigned int k = j; k < numOfElements; ++k)
				{
					a[k] = a[k + 1];
				}
				--j;
				--numOfElements;
				*/
			}
			else
				--numOfElements;
		}
	}
}
// Definition function printArray
void printArray(int a[], int numOfElements)
{
	cout << a[0];
	for (int i = 1; i < numOfElements; ++i)
	{
		cout << " " << a[i];
	}
}