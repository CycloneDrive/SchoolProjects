import java.util.Scanner;
import java.util.Timer;

class Character {
	public static int TABLESIZE = 9;
	private String firstName;
	private String lastName;
	private int age;

	// Constructor: Do not touch
	public Character(String fn, String ln) {
		firstName = fn;
		lastName = ln;
	}

	// Function key()
	// Should return the proper index to place the specific Character
	// into the hash table
	// Use the first letter of the last name and modulus to find the proper index
	public int key() {
		// for now, returns the ascii value of first character of last name
		int k = lastName.charAt(0);

		return k % 9;
	}

	// the details of the specific Character when you print it. Do not touch
	public String toString() {
		String str = "Last name: " + lastName;
		str += "\nFirst name: " + firstName;
		str += "\nHash Table Key: " + key();
		return str;
	}

	public String getLastName() {
		return lastName;
	}

	public static void main(String[] args) {
		Character[] hashtable = new Character[TABLESIZE]; // empty hashtable
		Scanner input = new Scanner(System.in);
		int tilNine = 0;
		// use this to test part 2!!! If it works, comment or delete

		while (tilNine < TABLESIZE) {
			System.out.print("Last name: ");
			String ln = input.nextLine();
			System.out.print("First name: ");
			String fn = input.nextLine();

			Character newChar = new Character(fn, ln);
			int key = newChar.key();

			if (hashtable[key] == null) {
				hashtable[key] = newChar;
				System.out.println("Inserted into the hash table, it is");
			} else {
				tilNine--;
				System.out.println("Error: Filled that spot you aleady have");
			}
			System.out.println("------------------------------------------");
			tilNine++;
		}
		System.out.println("Finished Filling Hash Table!");
		boolean found = false;
		while (!found) {
			
			System.out.print("Last name: ");
			String lnSearch = input.nextLine();
			System.out.println();

			// Hash Search
			long start = System.nanoTime();
			int key = lnSearch.charAt(0) % 9;
			if(lnSearch.equals(hashtable[key].getLastName()))
			{
				found = true;
			}
			long end = System.nanoTime();
			long elapsedTime = end - start;

			// Brute Start
			long bStart = System.nanoTime();
			int i = 0;
			for (; i < TABLESIZE; i++) {
				Character current = hashtable[i];
				if (current.lastName.equals(lnSearch)) {
					found = true;
					break;
				}
			}
			long bEnd = System.nanoTime();
			long bElapsedTime = bEnd - bStart;

			if (!found) {
				System.out.println("Not Found type in another last name: ");
			} else {
				System.out.println("Using Hash\n" + "Index: " + key + "\nTime: " + (elapsedTime) + "ns");
				System.out.println();

				System.out.println();
				System.out.println("Using Brute Force");
				System.out.println("Index: " + i);
				System.out.println("Time: " + (bElapsedTime) + "ns");
			}
		}
	}

}
