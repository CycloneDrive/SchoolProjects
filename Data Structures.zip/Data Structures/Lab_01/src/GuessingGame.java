/*
 *Author: Dan Tran
 *Date: 1/28/2020
 *Description: Generate a random number and have the user guess the number until it is correct.
 */
public class GuessingGame 
{
	public static void main(String[] args) 
	{
		int input = 0;
		int rand = (int)((Math.random()*100)+1);
		boolean isValid = false;
		int count = 0;
		System.out.print("I'm thinking of a number. Guess a value (1-100): ");
		
		while(!isValid) 
		{
			input = CheckInput.getIntRange(1, 100);
			count++;
			
			if(input == rand)
			{
				isValid = true;
			}
			else if(input < rand)
			{
				System.out.print("Too Low.  Guess again: ");
			}
			else 
			{
				System.out.print("Too High. Guess again: ");
			}
		}
		System.out.print("Correct!  You got it in " + count + " tries.");
	}
}