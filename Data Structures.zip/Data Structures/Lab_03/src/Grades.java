/*
 *Author: Dan Tran
 *Date: 02/012/2020
 *Description: Read from a file and input the information into an Arraylist. 
 *Afterwards, prompt the user to select options for the array.
 */
import java.util.ArrayList;
import java.io.*;
import java.text.DecimalFormat;
import java.util.Scanner;

public class Grades 
{
	/**
	 * Read grades from a file and add the grades into an array list.
	 * Try and catches any file not found.
	 * @return a list of grades.
	 */
	public static ArrayList<Integer> populateGrades() 
	{
		ArrayList<Integer> list = new ArrayList<Integer>();
		try 
		{
			Scanner read = new Scanner(new File("grades.txt"));
			while (read.hasNextInt()) 
			{
				int line = read.nextInt();
				list.add(line);
			}
			read.close();
		} 
		catch (FileNotFoundException e) 
		{
			System.out.println("File was not found");
		}
		return list;
	}
	/**
	 * Prints out the list of grades in rows of 10 numbers
	 * @param list array of grades.
	 */
	public static void displayGrades(ArrayList<Integer> list) 
	{
		int count = 0;

		for (Integer index : list) 
		{
			count++;
			System.out.print(index + " ");

			if (count % 10 == 0) 
			{
				System.out.println();
			}
		}
	}
	/**
	 * Sorts the list of grades using bubble sort in ascending order.
	 * @param list array of grades
	 */
	public static void sortList(ArrayList<Integer> list) {
		int size = list.size();
		int temp;
		for (int i = 0; i < size; i++) 
		{
			for (int j = i + 1; j < size; j++) 
			{
				if (list.get(i) > list.get(j)) 
				{
					temp = list.get(i);
					list.set(i, list.get(j));
					list.set(j, temp);
				}
			}
		}
	}
	/**
	 * Adds all the grades from the list
	 * @param list array of grades
	 * @return a sum of all the grades.
	 */
	public static double displaySum(ArrayList<Integer> list) 
	{
		int sum = 0;
		for (int i = 0; i < list.size(); i++) 
		{
			sum += list.get(i);
		}
		return sum;
	}
	/**
	 * Sorts through the list and finding the median from the middle of the list
	 * if the list is even, average the two
	 * @param list array of grades
	 * @return the median of the list.
	 */
	public static double displayMedian(ArrayList<Integer> list)
	{
		sortList(list);
		int size = list.size();
		double median = 0;
		if (size % 2 == 0) {
			median = list.get(size / 2) + list.get(size / 2 - 1);
			median /= 2;
		} 
		else 
		{
			median = (list.get(size / 2));
		}
		return median;
	}
	/*
	 * Displays menu 
	 */
	public static void displayMenu() 
	{
		System.out.println("1. Display Sorted Grades");
		System.out.println("2. Display Average Grades");
		System.out.println("3. Display Maximum Grades");
		System.out.println("4. Display Minimum Grades");
		System.out.println("5. Display Median Grades");
		System.out.println("6. Quit");
		System.out.print("Enter choice: ");
	}
	public static void main(String[] args) 
	{
		ArrayList<Integer> list = new ArrayList<Integer>();
		DecimalFormat df = new DecimalFormat("0.0");
		list = populateGrades();
		int menuNumber = 0;
		while (menuNumber != 6) 
		{
			displayMenu();
			menuNumber = CheckInput.getIntRange(1, 6);
			
			switch (menuNumber) 
			{
				case 1: 
				{
					System.out.println("Sorted Grades: ");
					System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
					sortList(list);
					displayGrades(list);
					System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				}
				break;
				case 2:
				{
					System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
					System.out.println("Average Grade: " + df.format(displaySum(list) / list.size()));
					System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				}
				break;
				case 3: 
				{
					sortList(list);
					int max = list.get(list.size()-1);
					System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
					System.out.println("Maximum Grade: " + max);
					System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				}
				break;
				case 4:
				{
					sortList(list);
					int min = list.get(0);
					System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
					System.out.println("Minimum Grade: " + min);
					System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				}
				break;
				case 5:
				{
					sortList(list);
					System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
					System.out.println("Median Grade: " + df.format(displayMedian(list)));
					System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				}
				case 6: System.out.println("You have left the menu.");		
			}
		}
	}
}
