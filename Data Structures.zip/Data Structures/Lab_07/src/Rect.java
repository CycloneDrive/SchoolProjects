public class Rect 
{
private int width;
private int height;

	/*
	 * Default Constructor  
	 */
	public Rect()
	{
		width = 0;
		height = 0;
	}
	/*
	 * Constructor
	 * @param num length of width and height
	 */	
	public Rect(int num)
	{
		if(num<0)
		{
			width = 0;
			height = 0;
		}
		else
		{
			width = num;
			height = num;
		}
	}
	/*
	 * Constructor
	 * @param num length of width and height
	 */		
	public Rect(int w, int h)
	{
		if(w < 0)
		{
			width = 0;
		}
		else
		{
			width = w;
		}
		if(h < 0)
		{
			height = 0;
		}
		else
		{
			width = w;
			height = h;
		}
	}
	/*
	 * Copy Constructor
	 * @param o object of type rectangle to copy
	 */	
	public Rect(Rect o)
	{
		width = o.width;
		height = o.height;
	}
	/*
	 * Accessor method for width
	 * @return width
	 */	
	public int getWidth()
	{
		return width;
	}
	/*
	 * Accessor method for height
	 * @return height
	 */	
	public int getHeight()
	{
		return height;
	}
	/*
	 * Compares if current object equals to compared object
	 * @return true if object is equals and false if not
	 */	
	@Override
	public boolean equals(Object o) 
	{
		if(this == o)
		{
			return true;
		}
		if(o == null)
		{
			return false;
		}
		if(!(o instanceof Rect))
		{
			return false;
		}
		Rect other = (Rect)o;
		if(other.width != width || other.height != height)
		{
			return false;
		}
	return true;
	}
	/*
	 * Compares height and if it isn't equal to each other compares width
	 * @return return the difference of height and/or width
	 */	
	public int compareTo(Rect o)
	{
		if(height == o.height)
		{
			return width - o.width;
		}
		else return height - o.height;
	}
	/*
	 * Multiples the height and width by value
	 * @param val is the multiplier to the instance variables
	 * @return rectangle
	 */	
	public Rect scale(int val)
	{
		if(val>1)
		{
			this.height*=val;
			this.width*=val;
		}
		return this;
	}
	/*
	 * Multiplies the height and width by value
	 * @param wVal multiplies into width
	 * @param hVal multiples into height
	 * @return rectangle
	 */	
	public Rect scale(int wVal, int hVal)
	{
		if(hVal>1)
		{
			this.height*=hVal;
		}
		if(wVal>1)
		{
			this.width*=wVal;
		}
		return this;
	}
	/*
	 * Adds argument Rectangle into calling rectangle
	 * @return rectangle
	 */
	public Rect scale(Rect o)
	{
		this.height+=o.height;
		this.width+=o.width;
		return this;
	}	
}
