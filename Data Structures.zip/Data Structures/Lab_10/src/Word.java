
public class Word {
	private String word;
	private int frequency = 1;
	/*
	 * Constructor for Word
	 * @param w representing the word
	 */
	public Word(String w) {
		word = w;
	}
	/*
	 * increases frequency of the word
	 */
	public void incFrequency() {
		frequency++;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Word other = (Word) obj;
		if (word == null) {
			if (other.word != null)
				return false;
		} else if (!word.equals(other.word))
			return false;
		return true;
	}
	/*
	 * Compares current word to w
	 * @param w representing the word
	 */
	public int compareTo(Word w) {
		return word.compareTo(w.word);
	}
	/*
	 * toString of class
	 * @return String representing class
	 */
	public String toString() {
		return word + " => " + frequency;
	}
}