import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BST list = new BST();
		try {
			Scanner read = new Scanner(new File("words.txt"));
			while (read.hasNext()) {
				String word = read.nextLine();
				Word w = new Word(word);
				list.add(w);
			}
			read.close();
		}catch(FileNotFoundException e) {
			System.out.println("File Not Found");
		}
		
		int choice;
		do {
			System.out.println("Please select options for your BST list: ");
			System.out.println("1. Display \n" + "2. Search \n" + "3. Exit");
			choice = CheckInput.getIntRange(1, 3);
			switch(choice) {
				case 1:{
					list.printBST();
				}
				break;
				case 2:{
					System.out.println("Please type in word to search for: ");
					String search = CheckInput.getString();
					Word sWord = new Word(search);
					if(list.contains(sWord) == null) {
						System.out.println("frequency => 0");
					}else {
						System.out.println(list.contains(sWord));
					}
					
				}
				break;
			}
		} while (choice != 3);

	}

}
