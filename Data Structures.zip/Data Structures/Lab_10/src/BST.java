
public class BST {
	private static class Node{
		private Word data;
		private Node left;
		private Node right;
		
		public Node(Word d) {
			data = d;
			left = null;
			right = null;
		}
		
		public String toString() {
			return "" + data;
		}
	}
	private Node root;
	/*
	 * Constructor of Node with two parameters
	 */
	public BST() {
		root = null;
	}
	/*
	 * Checks if list is empty
	 * @return true if empty and false otherwise
	 */
	public boolean isEmpty() {
		return root == null;
	}
	/*
	 * Adds word to list
	 */
	public void add(Word d) {
		root = add(d, root);
	}
	/*
	 * Helper to the add function
	 * @param d word object being added
	 * @param n if found in node n, increase frequency
	 */
	private Node add(Word d, Node n) {
		if(n == null) {
			return new Node(d);
		} else {
			if(d.compareTo(n.data) == 0) {
				n.data.incFrequency();
			}
			else if(d.compareTo(n.data) < 0) {
				n.left = add(d,n.left);
			} else {
				n.right = add(d, n.right);
			}
			return n;
		}
	}
	/*
	 * Checks if word is found
	 * @param d word object being found
	 * @return found word if not return null
	 */
	public Word contains(Word d) {
		if(root == null) {
			return d;
		} else {
			return contains(d,root);
		}
	}
	/*
	 * Helper to the contains function
	 * @param d word object being found
	 * @param n node in the list
	 * @return found word if not return null
	 */
	private Word contains(Word d, Node n) {
		if(d.compareTo(n.data) == 0) {
			return n.data;
		}
		if(d.compareTo(n.data) < 0) {
			if(n.left == null) {
				return null;
			} else {
				return contains(d,n.left);
			}
		} else {
			if(n.right == null) {
				return null;
			} else {
				return contains(d,n.right);
			}	
		}
	}
	/*
	 * Print list
	 */
	public void printBST() {
		if(isEmpty()) {
			System.out.println("Tree is empty");
		} else {
			printBST(root);
		}
	}
	/*
	 * Helper words to print our functions
	 * @param n Node being iterated
	 */
	private void printBST(Node n) {
		if(n.left != null) {
			printBST(n.left);
		}
		System.out.println(n.data + " ");
		if(n.right != null) {
			printBST(n.right);
		}
	}
}

