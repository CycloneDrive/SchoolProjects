import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;

public class Memory 
{
	/*
	 * Display menu option for the video game
	 * @return choice from the menu
	 */
	public static int getFileChoice()
	{
		System.out.println("Memory Game");
		System.out.println("1. Letters");
		System.out.println("2. Numbers");
		System.out.println("3. Animals");
		System.out.println("4. Objects");
		System.out.print("Enter Choice: ");
		int choice = CheckInput.getIntRange(1,4);
		
		return choice;
	}
	/*
	 * Reads file and puts the contents in an array.
	 * @param selection from getFileChoice()
	 * @param arr[][] double array to place two of each file words 
	 */
	public static void readFile(int selection, String arr[][])
	{
		String fileName = "";
		switch(selection)
		{
			case 1: fileName = "letters";
			break;
			case 2: fileName = "numbers";
			break;
			case 3: fileName = "animals";
			break;
			case 4: fileName = "objects";
			break;
		}
		
		try 
		{
			Scanner read = new Scanner(new File(fileName));
			
			for(int i = 0; i < 4; i++)
			{
				for(int j = 0; j < 4; j+=2)
				{
					arr[i][j] = read.nextLine();
					arr[i][j+1] = arr[i][j];
				}
			}
		} 
		catch (FileNotFoundException e) 
		{
			System.out.println("File not found");
		}
	}

	/*
	 * Shuffles the double array
	 */
	public static void shuffle(String arr[][])
	{
		for(int i = 0; i < 100; i++)
		{
			int randRow = (int) (Math.random()*4);
			int randCol = (int) (Math.random()*4);
			int randRow2 = (int) (Math.random()*4);
			int randCol2 = (int) (Math.random()*4);
			
			//if swapping with the same position randomize again
			while(randRow != randRow2 && randCol != randCol2)
			{
				randRow = (int) (Math.random()*4);
				randCol = (int) (Math.random()*4);
				randRow2 = (int) (Math.random()*4);
				randCol2 = (int) (Math.random()*4);
			}
			
			String temp = arr[randRow][randCol];
			arr[randRow][randCol] = arr[randRow2][randCol2];
			arr[randRow2][randCol2] = temp;
		}
	}
	/*
	 * Prints out the double array if the flipArr is true
	 * If flipArr is false prints out the card location
	 * @param flipArr[][] boolean Array indicating if card is faced up
	 * @param arr[][] card value
	 */
	public static void displayBoard(boolean flipArr[][], String arr[][])
	{
		int pos = 1; 
		
		for(int i = 0; i < 4; i++)
		{
			for(int j = 0; j < 4; j+=4)
			{
				System.out.println("+----+  +----+  +----+  +----+");
				System.out.println("|    |  |    |  |    |  |    |");
				
				for(int z = 0; z < 4; z++)
				{
					if(flipArr[i][(z)] == false)
					{
						System.out.print("|"+" "+String.format("%1$-3s", pos+z)+"|");			
					}
					else
					{
						System.out.print("|" + arr[i][z] + "|");
					}
					System.out.print("  ");
				}
				System.out.println();
				System.out.println("|    |  |    |  |    |  |    |");
				System.out.println("+----+  +----+  +----+  +----+");
				pos+=4;
			}
		}	
	}
	/*
	 * Asks the user for choice making sure it is within range.
	 * @return choice
	 */
	public static int getChoice()
	{
		int choice;
		System.out.print("Please enter choice: ");
		choice = CheckInput.getIntRange(1, 16);
		return choice;
	}
	/*
	 * Flips the card up or down
	 * @param choice is the card location
	 * @param flipArr[][] indicates if the card is up or down
	 */
	public static void flipChoice(int choice, boolean flipArr[][])
	{
		int row = (choice-1)/4; 
		int col = (choice-1)%4;
		flipArr[row][col] = !flipArr[row][col];
	}
	/*
	 * Indiciate if the two inputs are equal to each other
	 * @param input1 user input
	 * @param input2 user input
	 * @param arr is array representing the deck
	 * @return true if matched false if not
	 */
	public static boolean isMatch(int input1, int input2, String arr[][])
	{
		int inputRow1 = (input1-1)/4;
		int inputCol1 = (input1-1)%4;
		int inputRow2 = (input2-1)/4;
		int inputCol2 = (input2-1)%4;
		if(arr[inputRow1][inputCol1] == arr[inputRow2][inputCol2])
		{
			return true;
		}
		else 
		{ 
			return false;
		}
	}
	/*
	 * checks if the location is face up
	 * @param choice location of card
	 * @param flipArr set of cards
	 * @return true if it is flipped up
	 */
	public static boolean checkFlipped(int choice, boolean flipArr[][]) 
	{
		int row = (choice-1)/4; 
		int col = (choice-1)%4;
		
		if(flipArr[row][col] == true)
		{
			return true;
		}
		else return false;
	}
	public static void main(String[] args) 
	{
		
		boolean again = true;
		int count = 0;
		do 	
		{
			String arr[][] = new String[4][4];
			boolean flipArr[][] = new boolean[4][4];
			int fileChoice = getFileChoice();
			readFile(fileChoice, arr);
			shuffle(arr);
			boolean done = false;
			displayBoard(flipArr,arr);

			while(count<8)
			{
				int choice = getChoice();
				while(checkFlipped(choice,flipArr))
				{
					System.out.println("Location already entered.");
					System.out.println();
					choice = getChoice();
				}
				flipChoice(choice, flipArr);
				displayBoard(flipArr,arr);
				
				int choice2 = getChoice();
				while(checkFlipped(choice2,flipArr))
				{
					System.out.println("Location already entered.");
					System.out.println();
					choice2 = getChoice();
				}
				flipChoice(choice2, flipArr);
				displayBoard(flipArr,arr);
				
				if(!isMatch(choice,choice2,arr))
				{
					flipChoice(choice,flipArr);
					flipChoice(choice2,flipArr);
					System.out.println("Not A Match");
				}
				else
				{
					System.out.println("Match Found");
					count++;
				}
			}
			System.out.print("You Won! Play Again? (Y/N): ");
			again = CheckInput.getYesNo();
			if(again == false)
			{
				System.out.println("Game Over");
			}
			else
			{
				count = 0;
			}
		}
		while(again == true);
	}
}

