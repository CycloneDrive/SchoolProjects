
public class Circle 
{
	private int x;
	private int y;
	private int radius;
	/*
	 * Constructor of a circle
	 * @param x is x coordinate
	 * @param y is y coordinate
	 */
	public Circle(int x, int y, int radius) 
	{
		super();
		this.x = x;
		this.y = y;
		this.radius = radius;
	}
	/*
	 * Equals method comparing current object to parameter object
	 * @param o object comparing to
	 * @return true if equal and false if otherwise
	 */
	public boolean equals(Object o)
	{
		// self check
		if(this == o)
		{
			return true;
		}
		// null check
		if(o == null)
		{
			return false;
		}
		//type check
		if(this.getClass() != o.getClass())
		{
			return false;
		}
		//component check
		Circle other = (Circle) o;
		if (radius != other.radius)
		{
			return false;
		}
		if (x != other.x)
		{
			return false;
		}
		if (y != other.y)
		{
			return false;
		}
		return true;
	}
	/*
	 * Prints out string of the Class
	 * @return string of class
	 */
	@Override
	public String toString() {
		return  "(" + x + "," + y + ") " + "R = " + radius;
	}

}
