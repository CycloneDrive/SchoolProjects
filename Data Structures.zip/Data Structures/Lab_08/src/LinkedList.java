
public class LinkedList
{
	
	
	private static class Node
	{
		private Circle data;
		private Node next;
		/*
		 * Constructor of a Node
		 * @param s is a object of Circle class
		 */
		public Node(Circle s){
			data = s;
			next = null;
		}
		/*
		 * Constructor of Node with two parameters
		 * @param s is an object of Circle class
		 * @param n is a node
		 */
		public Node(Circle s, Node n){
			data = s;
			next = n;
		}
		/*
		 * Prints out string of the Class
		 * @return string of class
		 */
		@Override
		public String toString(){
			return data.toString();
		}
	}	
	
	private Node first;
	private Node last;
	/*
	 * Default Constructor of linkedlist
	 */
	public LinkedList()
	{
		first = null;
		last = null;
	}
	/*
	 * Boolean function determining if function is empty
	 * @return true if empty false if otherwise
	 */
	public boolean isEmpty()
	{
		if(first == null)
		{
			return true;
		}
		else return false;
	}
	/*
	 * Function that adds a node that contains a circle onto th end of a list
	 * @param s is an object of Circle
	 */
	public void add( Circle s ) 
	{
		if( first == null ) 
		{
			first = new Node( s );
			last = first;
		} 
		else 
		{
			Node n = new Node( s );
			last.next = n;
			last = n;
		}
	}
	/*
	 * Function that adds a node that contains a circle onto the index location of a list and pushes the rest forward
	 * @param i is an index
	 * @param s is an object of Circle
	 */
	public void add( int i, Circle s ) 
	{
		if( i < 0 ) 
		{
			throw new IndexOutOfBoundsException();
		}
		if( i == 0 ) 
		{
			first = new Node( s, first );
			if( last == null ) 
			{
				last = first;
			}
		} 
		else 
		{
			Node n = first;
			if( n == null ) 
			{
				throw new IndexOutOfBoundsException();
			}
			for( int j = 1; j < i; j++ ) 
			{
				n = n.next;
				if( n == null ) 
				{
					throw new IndexOutOfBoundsException();
				}
			}
			n.next = new Node( s, n.next );
			if( n.next.next == null ) 
			{
				last = n.next;
			}
		}
	}
	/*
	 * Function that accesses a circle object from the linked list at a specific index
	 * @param i is an index
	 * @param s is an object of Circle
	 */
	public Circle get( int i ) 
	{
		if( first == null || i < 0 ) 
		{
			throw new IndexOutOfBoundsException();
		}
		Node n = first;
		for( int j = 0; j < i; j++) 
		{
			n = n.next;
			if( n == null ) 	
			{
				throw new IndexOutOfBoundsException();
			}
		}
			return n.data;
	}
	/*
	 * Function that sets the node at a specific linked list to something else
	 * @param i is an index 
	 * @param s is an object of Circle
	 */
	public void set( int i, Circle s ) 
	{
		if( first == null || i < 0 ) 
		{
			throw new IndexOutOfBoundsException();
		}
		Node n = first;
		for( int j = 0; j < i; j++ ) 
		{
			n = n.next;
			if( n == null ) 
			{
				throw new IndexOutOfBoundsException();
			}
		}
		n.data = s;
	}
	/*
	 * Function that that returns the size of the list;
	 * @return integer that represents the size of the list
	 */
	public int size() 
	{
		int count = 0;
		Node n = first;
		while( n != null ) 
		{
			count++;
			n = n.next;
		}
	return count;
	}
	/*
	 * Removes node from a certain index in the linked list
	 * @param i is the index where the node will be removed
	 * @return the removed node containing a circle
	 */
	public Circle remove( int i )
	{
		Circle rem = null;
		if( first == null || i < 0 ) 
		{
			throw new IndexOutOfBoundsException();
		}
		if( i == 0 ) 
		{
			rem = first.data;
			first = first.next;
			if( first == null )
			{
				last = null;
			}
		} 
		else 
		{
			Node n = first;
			for( int j = 1; j < i; j++ ) 
			{
				n = n.next;
				if( n == null ) 
				{
					throw new IndexOutOfBoundsException();
				}
			}
			if( n.next == null ) 
			{
				throw new IndexOutOfBoundsException();
			}
			rem = n.next.data;
			n.next = n.next.next;
			if( n.next == null ) 
			{
				last = n;
			}
		}
		return rem;
	}
	/*
	 * Iterates through the linked list and if a Circle is found remove the circle
	 * @param s is an object of circle that will be removed
	 * @return if the circle is found then return true and false if otherwise
	 */
	public boolean remove( Circle s ) 
	{
		if( first != null ) 
		{
			if( s.equals( first.data ) ) 
			{
				first = first.next;
				if( first == null ) 
				{
					last = null;
				}
				return true;
			} 
			else 
			{
				Node n = first;
				while(n.next!=null && !n.next.data.equals(s))
				{
					n = n.next;
				}
				if( n.next != null ) 
				{
					n.next = n.next.next;
					if( n.next == null ) 
					{
						last = n;
					}
				return true;
				}
			}
		}
		return false;
	}
	/*
	 * Prints out string of the Class
	 * @return string of class
	 */
	@Override
	public String toString( ) 
	{
		String str = "";
		Node n = first;
		while( n != null ) 
		{
			str = str + n.data + "\n";
			n = n.next;
		}
	return str;
	}
}
