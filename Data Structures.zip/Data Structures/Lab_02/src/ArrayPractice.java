/*
 *Author: Dan Tran
 *Date: 02/05/2020
 *Description: Place 10 values into an array and display a repeating
 *menu that will allow the user to choose different options
 */
public class ArrayPractice 
{
	/**
	 * Prompts the user to input 10 integer values into an array
	 * @return an array of 10 integers.
	 */
	public static int[] populateArray()
	{
		int[] input = new int[10];
		System.out.println("Input 10 values: ");
		
		for (int i = 0; i < 10; i++)
		{
			input[i] = CheckInput.getInt();
		}
		return input;
	}
	/**
	 * Displays the values of an array of ten integers.
	 * @param input[] array of ten integers
	 */
	public static void displayValues(int[] input)
	{
		for(int i = 0; i <= 9; i++)
		{
			System.out.print(input[i] + " ");
		}
	}
	/**
	 * Displays the values of an array of ten integers in reverse
	 * @param input[] array of ten integers
	 */
	public static void displayReversed(int[] input)
	{
		for(int i = 9; i >= 0; i--)
		{
			System.out.print(input[i] + " ");
		}
	}
	/**
	 * Searches an array and returns its location if found
	 * If not found, return -1
	 * @param input[] array of ten integers
	 * @param element value of element to find
	 * @return an integer representing the location of the element found.
	 */
	public static int searchValue(int[] input, int element)
	{
		for(int i = 0; i <= 9; i++)
		{
			if(input[i] == element)
			{
				return i;
			}
		}
		return -1;
	}
	/**
	 * Replaces a value in the array with given index
	 * @param input[] array of ten integers
	 * @param index location in the array
	 * @param replaceWith    value to replace the index with
	 */
	public static void insertValue(int[] input, int index, int replaceWith)
	{
		input[index] = replaceWith;
	}
	/**
	 * Searches array for the largest value
	 * @param input[] array of ten integers
	 * @return an int representing the largest number.
	 */
	public static int maxValue(int[] input)
	{
		int max = 0;
		for(int i = 0; i <= 9; i++)
		{
			if(input[i] > max)
			{
				max = input[i];
			}
		}
		return max;
	}
	/**
	 * Loops through an array and adds the values into a sum
	 * @param input[] array of ten integers
	 * @return an int representing the sum.
	 */
	public static int computeSum(int[] input)
	{
		int sum = 0;
		for(int i = 0; i <= 9; i++)
		{
			sum += input[i];
		}
		return sum;
	}
	/**
	 * Displays menu
	 */
	public static void displayMenu()
	{
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("1. Display Values");
		System.out.println("2. Display Reversed");
		System.out.println("3. Display Sum");
		System.out.println("4. Display Maximum");
		System.out.println("5. Search for a Value");
		System.out.println("6. Insert new Value");
		System.out.println("7. Reset Values");
		System.out.println("8. Quit");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~");
	}
	public static void main(String[] args) 
	{

		int menuNumber = 0;
		int[] input = new int[10];
		
		input = populateArray();

		while(menuNumber != 8)
		{
			displayMenu();
			menuNumber = CheckInput.getIntRange(1, 9);
			
			switch(menuNumber)
			{
				case 1: System.out.print("Displaying: "); displayValues(input);
				break;
				case 2: System.out.print("Displaying Reverse: "); displayReversed(input);
				break;
				case 3: System.out.print("Sum is: " + computeSum(input));
				break;
				case 4: System.out.print("Max value: " + maxValue(input));
				break;
				case 5: 
				{
					System.out.print("What number are you searching for: ");
					int element = CheckInput.getInt() ;
					int location = searchValue(input,element);
					
					if(location == -1)
					{
						System.out.print("not found");
					}
					else
					{
					System.out.print("It is located at: " + (location + 1));
					}
				}
				break;
				case 6:
				{
					System.out.println("Input new number value: ");
					int element = CheckInput.getInt();
					System.out.print("Which index do you want to place the new value: ");
					int index = CheckInput.getIntRange(1, 10);
					insertValue(input, index-1, element);
				}
				break;
				case 7: input = populateArray();
				break;
				case 8: System.out.println("You have exited out of the program. Thank you!");
				break;
			}
			System.out.println();
			System.out.println();
		}
	}
}
