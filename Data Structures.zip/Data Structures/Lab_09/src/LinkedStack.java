

public class LinkedStack {
	private static class Node {
		private String data;
		private Node next;
		/*
		 * Constructor of Node with two parameters
		 * @param s is an object of String class
		 * @param n is a node
		 */
		public Node(String d, Node n) {
			data = d;
			next = n;
		}
		/*
		 * Prints out string of the Class
		 * @return string of class
		 */
		@Override
		public String toString() {
			return data.toString();
		}
	}

	private Node top;
	/*
	 * Default Constructor of linkedstack
	 */
	public LinkedStack() {
		top = null;
	}
	/*
	 * Boolean function determining if function is empty
	 * @return true if empty false if otherwise
	 */
	public boolean isEmpty() {
		return top == null;
	}
	public String peek()
	{
		return top.data;
	}
	/*
	 * Function that adds a node that contains a circle onto the end of a list
	 * @param s is an object of String
	 */
	public void push(String s) {
		top = new Node(s, top);
	}
	/*
	 * Returns the top of the stack and moves down the stack
	 */
	public String pop() {
		String String = null;
		if (!isEmpty()) {
			String = top.data;
			top = top.next;
		}
		return String;
	}
	/*
	 * Prints out string of the Class
	 * @return string of class
	 */
	public String toString() {
		String s = "";
		Node n = top;
		while (n != null) {
			s = s + n.data + " ";
			n = n.next;
		}
		return s;
	}
	/*
	 * @return string of class
	 */
	public int size() {
		int count = 0;
		Node n = top;
		while (n != null) {
			count++;
			n = n.next;
		}
		return count;
	}
}
