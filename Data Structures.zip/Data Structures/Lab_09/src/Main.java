import java.awt.Point;


public class Main {
	public static void main(String[] args) {
		LinkedStack stack = new LinkedStack();
		stack.push("A");
		stack.push("B");
		stack.push("C");
		System.out.println(stack);
		System.out.println(stack.peek());
		stack.pop();
		stack.push("D");
		System.out.println(stack.size());
		stack.pop();
		System.out.println(stack.pop());
		System.out.println(stack.isEmpty());
		
	}
}
