
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Player p = new Player();
		boolean gameOn = true;
		while(gameOn)
		{
			p.takeTurn();
			System.out.print("Play again? (Y/N) ");
			gameOn = CheckInput.getXY();
			System.out.println();
		}
		System.out.println("Game Over.");
		System.out.println("Final Score = " + p.getPoints() + " points");
	}
}
