/** This class is a Player that uses a Die object */
public class Player 
{
	private Die d[] = new Die[3];
	private int points;

	/*
	 * Loop through the array and initialize with new Dice.
	 */
	public Player() 
	{
		for(int i = 0; i < 3; i++)
		{
			d[i] = new Die(6);
		}
		points = 0;
	}
	/*
	 * Sorts the array in ascending order
	 */
	public void sort()
	{
		for(int i = 0; i < 2; i++)
		{
			for(int j = 0; j < 2 - i ; j++)
			{
				if(d[j].compareTo(d[j+1])>0)
				{
					Die temp = d[j+1];
					d[j+1] = d[j];
					d[j] = temp;
				}
			}
		}
	}
	/*
	 * Checks if it is a two of a kind
	 * @return true if two of a kind
	 */
	public boolean twoOfAKind()
	{
		if(d[0].equals(d[1]) && d[1].equals(d[2]))
		{
			return false;
		}
		if(d[0].equals(d[1]) || d[1].equals(d[2]))
			return true;
		else 
		{ 
			return false;
		}
	}
	/*
	 * Checks if it is a three of a kind
	 * @return true if three of a kind
	 */
	public boolean threeOfAKind()
	{
		if(d[0].equals(d[1]) && d[1].equals(d[2]))
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
	/*
	 * Checks if it is a series
	 * @return true if series
	 */
	public boolean series()
	{
		Player p = this;
		p.sort();
		if (p.d[2].compareTo(d[0]) == 2 && p.d[2].compareTo(d[1]) == 1)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	/**
	 * Re-rolls the dice. 
	 * Prints the set
	 * Checks how many points to earn from the set of dice
	 * If no points received, then prints "TooBad"
	 * Prints Points
	 */
	public void takeTurn() 
	{
		for(int i = 0; i < 3; i++)
		{
			d[i].setDiceVal(d[i].roll());
		}
		System.out.print(this);
		if(this.threeOfAKind())
		{
			points+=3;
		}
		else if(this.twoOfAKind())
		{
			points+=1;
		}
		else if(this.series())
		{
			points+=2;
		}
		else
		{
			System.out.println("Awww. Too Bad.");
		}
		System.out.println("Score = " + points + " points");
	}
	/**
	 * Sorts the array and prints it out
	 * @return a String of array output
	 */
	public String toString()
	{
		this.sort();
		return "Rolling Dice... D1=" + d[0].getDieVal() + 
							  ",D2=" + d[1].getDieVal() + 
							  ",D3=" + d[2].getDieVal() + "\n";
	}
	/**
	 * Retreives the points value
	 * @return player�s points
	 */
	public int getPoints() {
		return points;
	}
}