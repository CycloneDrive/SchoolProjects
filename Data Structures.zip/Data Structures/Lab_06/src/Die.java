
public class Die implements Comparable
{
	private int sides;
	private int dieVal;
	
	
	/** Constructor * 
	 * @param s The number of sides this die has */
	public Die(int s) 
	{
		sides = s;
		dieVal = roll();
	}
	
	/*
	 * Compares the value of dieVal
	 * @param obj Object being compared
	 * @return an integer 1 -1 and 0
	 */
	public int compareTo(Object obj) 
	{
		Die other = (Die)obj;
		return dieVal - other.dieVal;
	}
	/*
	 * Compares if the value of the object is equal
	 * @param obj Object being compared
	 * @return an true if equals and false if not
	 */
	public boolean equals(Object obj) 
	{
		if (this == obj) 
		{
			return true;
		}
		if (obj == null) 
		{
			return false;
		}
		if (getClass() != obj.getClass()) 
		{
			return false;
		}
		Die other = (Die) obj;
		if (dieVal != other.dieVal) 
		{
			return false;
		}
		if (sides != other.sides)
		{
			return false;
		}
		return true;
	}

	/** Rolls the die and returns the result
	 * @return result of die roll */
	public int roll( ) 
	{
		dieVal = (int)( Math.random() * sides ) + 1;
		return dieVal;
	}
	
	/** Retrieves the value of the die
	 * @return value of the die */
	public int getDieVal( ) 
	{
	return dieVal;
	}
	/** Sets the die to the parameter value
	 * @param value value to set die to
	 * @return value of the die
	 */
	public boolean setDiceVal( int value ) 
	{
	if ( value > 0 && value <= sides ) 
		{
			dieVal = value;
			return true; 
		}
	return false; 
	}
	
	
}
